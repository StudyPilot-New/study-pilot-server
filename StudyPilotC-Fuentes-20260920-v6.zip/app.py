from __future__ import annotations
import argparse
import asyncio
import hashlib
import time
from dataclasses import replace
from pathlib import Path
from typing import Dict
from weakref import WeakKeyDictionary

_question_epochs = WeakKeyDictionary()
_pacers = WeakKeyDictionary()
_solve_retries = WeakKeyDictionary()
_blank_since = WeakKeyDictionary()
from pacing import SessionPacer
from live_pacing import watch_updates
from learning_adapter import extract_learning_questions
from canvas_navigation import CanvasNavigation
_canvas_navigation=CanvasNavigation()


def apply_live_pacing(data):
    global settings
    settings=replace(settings,pacing_minutes=data['minutes'],pacing_questions=data['questions'])
    for pacer in list(_pacers.values()):pacer.reconfigure(data['minutes'],data['questions'])
    print(f"Ritmo actualizado: {data['minutes']*60/data['questions']:g} s/pregunta",flush=True)

from playwright.async_api import async_playwright

from config import settings
from dom import (
    extract_questions,
    screenshot_question,
    fill_answer,
    highlight_answer,
    debug_dom,
)
from llm import Solver
from text_alternative import has_text_alternative
from visual_question import solve_with_visual_evidence
from visual_capture import capture_visual, enrich_visual_identity
from matcher import best_choice
from overlay import update_overlay
from mcgraw_actions import (fill_mcgraw_answer, submit_confidence, advance_pending,
                            allowed_mcgraw, clear_navigation, handle_feedback, matching_complete)
from mcgraw_actions import confidence_wait_message, resume_interactions
from local_navigation import auto_submit, next_question, is_local_page
from site_policy import identify_site
from mcgraw_adapter import extract_mcgraw_question, annotate_matching, annotate_fill_blanks

def signature(q) -> str:
    choice_texts = [c.text for c in q.choices]
    if q.kind == "ordering":
        choice_texts.sort()
    raw = q.kind + "|" + q.text + "|" + "|".join(choice_texts) + "|" + q.html_hint
    return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()


async def collect_questions_from_frames(page, is_study_platform=False):
    collected = []

    for index, frame in enumerate(page.frames):
        try:
            if is_study_platform:
                # McGraw only: use the dedicated visible-question extractor.
                # Do NOT fall back to the generic detector, because McGraw can keep
                # unrelated/stale controls in the DOM between question transitions.
                questions = await extract_mcgraw_question(frame)
            else:
                questions = await extract_learning_questions(frame)
                if not questions and is_local_page(page):
                    questions = await extract_questions(frame)
        except Exception:
            continue

        for q in questions:
            await enrich_visual_identity(frame, q)
            collected.append((index, frame, q))

    # Prefer dedicated current-question results on McGraw.
    if is_study_platform:
        dedicated = [
            item for item in collected
            if getattr(item[2], "html_hint", "").startswith("mcgraw-dedicated")
        ]
        if dedicated:
            # If multiple frames expose the same question, keep the first unique text.
            unique = []
            seen = set()
            for item in dedicated:
                key = (item[2].text, tuple(c.text for c in item[2].choices))
                if key in seen:
                    continue
                seen.add(key)
                unique.append(item)
            return unique

    unique = []
    used = set()
    for index, frame, q in collected:
        sig = signature(q)
        if sig in used:
            continue
        used.add(sig)
        unique.append((index, frame, q))
    return unique


async def choose_target_page(context):
    """
    Prefer the actual McGraw/Connect page over the Canvas launcher page.
    McGraw often opens as a popup/new tab, while the original Canvas page remains
    as context.pages[0].
    """
    pages = [p for p in context.pages if not p.is_closed()]
    if not pages:
        return None
    # A newly opened LMS activity must not lose focus to an older McGraw tab.
    from site_policy import platform_from_url
    for candidate in reversed(pages):
        if platform_from_url(candidate.url):
            try:
                if await candidate.locator('.question,.que,[data-question-id],[data-testid="question"],fieldset').count():return candidate
            except Exception:pass

    # Strong URL preference.
    preferred_hosts = (
        "learning.mheducation.com",
        "mheducation.com",
        "mcgrawhill.com",
        "connect.mheducation.com",
        "aleks.com",
    )

    for p in reversed(pages):
        url = (p.url or "").lower()
        if any(host in url for host in preferred_hosts):
            return p

    # Content/title fallback in case the URL is unusual.
    for p in reversed(pages):
        try:
            title = (await p.title()).lower()
        except Exception:
            title = ""

        try:
            body = (
                await p.locator("body").inner_text(timeout=800)
            ).lower()[:4000]
        except Exception:
            body = ""

        combined = title + "\n" + body
        if (
            "mcgraw" in combined
            or "multiple select question" in combined
            or "multiple choice question" in combined
            or "concepts completed" in combined
        ):
            return p

    # Otherwise use the newest nonblank page.
    for p in reversed(pages):
        if (p.url or "") != "about:blank":
            return p

    return pages[-1]


async def print_open_pages(context):
    pages = [p for p in context.pages if not p.is_closed()]
    print("\nOpen browser pages")
    print("------------------")
    for i, p in enumerate(pages):
        try:
            title = await p.title()
        except Exception:
            title = ""
        print(f"[{i}] {p.url}")
        if title:
            print(f"    {title}")


def session_pacer(page):
    if not settings.pacing_minutes:
        return None
    pacer=_pacers.get(page)
    if pacer is None or (pacer.minutes,pacer.questions)!=(settings.pacing_minutes,settings.pacing_questions):
        pacer=SessionPacer(settings.pacing_minutes,settings.pacing_questions)
        _pacers[page]=pacer
    return pacer


async def submit_paced_confidence(page, level, fingerprint):
    pacer=session_pacer(page)
    if pacer is not None and pacer.remaining()>0:
        return False
    result=await submit_confidence(page,level,fingerprint)
    if result and pacer is not None:
        pacer.submitted()
    return result


ANSWER_FORMAT_ERRORS = (
    'Single-choice requires exactly one answer', 'Answer count must match field count',
    'Dropdown requires one answer', 'Answer is missing or ambiguous:', 'Duplicate answer',
    'Matching requires TARGET => MATCH', 'All matching targets must have one answer',
    'Unknown or ambiguous matching target:', 'Matching formula is missing or ambiguous:',
    'Ordering requires every item exactly once', 'Duplicate ordering item',
)


def schedule_answer_recovery(page, cache_key, answer, reason=''):
    failures=_solve_retries.setdefault(page,{})
    attempts=failures.get(cache_key,{}).get('attempts',0)+1
    delay=(2,5,10,20,30)[min(attempts-1,4)]
    issue='La respuesta no coincide con los campos u opciones.' if reason else 'No se pudo analizar con confianza suficiente.'
    message=(f'{issue} Revisión automática '
             f'{attempts} en {delay} s; la respuesta rechazada no se enviará otra vez.')
    previous=failures.get(cache_key,{})
    previous.pop('candidate',None)
    failures[cache_key]={**previous,'attempts':attempts,'at':time.monotonic()+delay,
                         'message':message,'hint':' | '.join(answer.answers)+(' | '+reason if reason else '')}
    print(message)
    return message


async def analyze_page(page, solver: Solver, seen: Dict[str, str]):
    site_name, is_study_platform = await identify_site(page)
    if is_study_platform:
        from question_resources import restore_question_resource
        if not await restore_question_resource(page):
            await update_overlay(page, site_name, 'Volviendo del recurso a la pregunta para continuar automáticamente.', [])
            return 0
    if is_study_platform and getattr(solver,'memory',None) is not None:
        if await solver.memory.observe(page):seen.clear()
    if is_study_platform and settings.mcgraw_auto and settings.mode == "fill":
        feedback = await handle_feedback(page)
        if feedback:
            await update_overlay(page, site_name, feedback, [])
            seen.clear()
            return 0
    found = await collect_questions_from_frames(page, is_study_platform=is_study_platform)

    fingerprint = tuple((i, q.qid, signature(q)) for i, _, q in found)
    canvas_auto=site_name=='Canvas' and settings.mode=='fill'
    if canvas_auto:
        _canvas_navigation.observe(page,fingerprint,session_pacer(page))
    if fingerprint and _question_epochs.get(page)!=fingerprint:
        # Failed or uncertain intervening questions may never update `seen`.
        # A new screen must not inherit the processed marker of an older visit.
        seen.clear()
        _question_epochs[page]=fingerprint
        _solve_retries.pop(page,None)
    if is_study_platform and settings.mcgraw_auto and settings.mode == "fill":
        if await advance_pending(page, fingerprint):
            return 0

    if not found:
        if is_study_platform and page in _question_epochs:
            from mcgraw_actions import screen_state
            screen=await screen_state(page)
            if screen['textLength']<30 and not screen['feedback'] and not screen['required']:
                since=_blank_since.setdefault(page,time.monotonic())
                if time.monotonic()-since>=8:
                    from recovery import recover_page
                    if await recover_page(page,('blank',_question_epochs.get(page))):
                        seen.clear();_blank_since.pop(page,None)
            else:_blank_since.pop(page,None)
        await update_overlay(
            page,
            site_name,
            "No visible question controls detected yet.",
            []
        )
        print("No visible questions detected.")
        return 0

    _blank_since.pop(page,None)
    if canvas_auto:
        navigation=await _canvas_navigation.advance(page,found,signature,session_pacer(page))
        if navigation:
            await update_overlay(page,site_name,navigation,[])
            return 0
    if is_study_platform and settings.mode=='fill' and settings.mcgraw_auto:
        pacer=session_pacer(page)
        if pacer is not None and pacer.remaining()>0:
            message=pacer.message()
            if pacer.last_display!=message:
                if pacer.last_display is None:
                    print('Pacing: '+message)
                await update_overlay(page,site_name,message,[])
                pacer.last_display=message
            return 0

    # Run before answer-cache skips: the user may have placed the final tile.
    if (is_study_platform and settings.mode=='fill' and settings.mcgraw_auto and
            all(q.kind=='matching' for _,_,q in found)):
        completed=True
        for _,frame,_ in found:
            if not await matching_complete(frame):
                completed=False
                break
        if completed:
            submitted=await submit_paced_confidence(page,settings.mcgraw_confidence,fingerprint)
            if submitted:
                await update_overlay(page,site_name,'All matching rows filled. Confidence submitted; waiting for Next Question.',[])
            else:
                await update_overlay(page,site_name,confidence_wait_message(page),[])
            return 0

    overlay_items = []
    handled = 0
    filled_count = 0

    for frame_index, frame, q in found:
        sig = signature(q)
        cache_key = f"{frame_index}:{q.qid}"

        if seen.get(cache_key) == sig:
            continue

        retry=_solve_retries.get(page,{}).get(cache_key)
        recalled=getattr(solver,'memory',None) is not None and solver.memory.recalled(q)
        if retry and not recalled and time.monotonic()<retry['at']:
            overlay_items.append({'type':q.kind.replace('_',' '),'question':q.text,
                                  'answer':'Esperando un nuevo intento','confidence':0,
                                  'explanation':retry['message']})
            continue
        has_alternative = await has_text_alternative(frame)
        use_image = (
            settings.use_vision == "always" or
            (settings.use_vision == "auto" and (q.has_visual or has_alternative))
        )

        image = None
        alternative = ""
        image_failed = False
        if use_image:
            try:
                image = await capture_visual(frame, q.qid)
            except Exception as e:
                print(f"[{q.qid}] screenshot failed: {e}; trying Text Alternative")
                image_failed = True

        print(f"\n[{site_name} | frame {frame_index} | {q.qid}] {q.kind}")
        print(f"  Q: {q.text[:500]}")

        if q.choices:
            for c in q.choices:
                if c.text:
                    print(f"     - {c.text[:220]}")

        try:
            candidate=retry.get('candidate') if retry else None
            memory=getattr(solver,'memory',None)
            if candidate and not recalled and not (memory and memory.is_rejected(q,candidate.answers)):
                answer=candidate
            else:
                if is_study_platform and retry and not recalled and not retry.get('resource_checked'):
                    from question_resources import read_question_resource, consume_question_resource
                    retry['resource_context']=await read_question_resource(page)
                    if not await restore_question_resource(page):
                        await update_overlay(page, site_name, 'Volviendo del recurso a la pregunta para continuar automáticamente.', [])
                        return 0
                    if not retry['resource_context']:
                        retry['resource_context']=await consume_question_resource(page)
                    retry['resource_checked']=True
                answer, alternative = await solve_with_visual_evidence(
                    page, frame, q, solver, image, image_failed, has_alternative, settings.min_confidence,
                    recovery_attempt=retry['attempts'] if retry else 0,
                    recovery_hint=retry.get('hint','') if retry else '',
                    resource_context=retry.get('resource_context','') if retry else '')
            if answer is None:
                raise ValueError('La imagen o su descripción todavía no está disponible.')
        except Exception as e:
            failures=_solve_retries.setdefault(page,{})
            attempts=failures.get(cache_key,{}).get('attempts',0)+1
            delay=min(30,2*2**min(attempts-1,4))
            message=f'No se pudo analizar: {str(e)[:260]}. Nuevo intento en {delay} s.'
            failures[cache_key]={**failures.get(cache_key,{}),'attempts':attempts,'at':time.monotonic()+delay,'message':message}
            print(message)
            overlay_items.append({'type':q.kind.replace('_',' '),'question':q.text,
                                  'answer':'Reintentando análisis','confidence':0,'explanation':message})
            continue
        printable = " | ".join(answer.answers) if answer.answers else "(no answer)"
        print(f"  => {printable}  [confidence={answer.confidence:.2f}]")

        if settings.show_explanation and answer.explanation:
            print(f"     {answer.explanation[:400]}")

        action_note = ""
        overlay_items.append({
            "type": q.kind.replace("_", " "),
            "question": q.text,
            "answer": printable,
            "confidence": answer.confidence,
            "explanation": answer.explanation if (alternative or image) else ("" if settings.fast_mode else (answer.explanation if settings.show_explanation else "")),
        })

        if answer.answers and answer.confidence >= settings.min_confidence:
            if (is_study_platform and settings.mode == "fill" and settings.mcgraw_auto
                    and allowed_mcgraw(page)):
                current = await extract_mcgraw_question(frame)
                for item in current:
                    await enrich_visual_identity(frame, item)
                if not any(item.qid == q.qid and signature(item) == sig for item in current):
                    print("     Question changed while solving; rescanning before applying.")
                    continue
                result = await fill_mcgraw_answer(page, frame, q, answer.answers)
                print(f"     McGraw fill: {result['filled']} - {result['details']}")
                if result['filled']:
                    filled_count += 1
                    if getattr(solver,'memory',None) is not None:
                        solver.memory.stage(page,q,answer)
                else:
                    overlay_items[-1]['explanation'] = result['details']
                    if result.get('recover'):
                        from recovery import recover_page
                        if await recover_page(page,sig):
                            seen.clear()
                            await update_overlay(page,site_name,'Recuperando la actividad y conservando lo aprendido.',[])
                            return 0
                    if result['details'].startswith(ANSWER_FORMAT_ERRORS):
                        overlay_items[-1]['explanation']=schedule_answer_recovery(page,cache_key,answer,result['details'])
                    else:
                        # A failed control/gesture is not a reason to pay for the
                        # same accepted analysis on every watch iteration.
                        failures=_solve_retries.setdefault(page,{})
                        failures[cache_key]={**failures.get(cache_key,{}),'candidate':answer,
                                             'attempts':retry['attempts'] if retry else 0,'at':0}
                    continue
            elif is_study_platform:
                if q.kind == "fill_blank":
                    try:
                        applied = await annotate_fill_blanks(frame, answer.answers)
                        if applied:
                            print("     fill-in recommendations:")
                            for item in applied:
                                print("       " + item)
                    except Exception as e:
                        print(f"     fill-in annotation error: {e}")
                elif q.kind == "matching":
                    try:
                        applied = await annotate_matching(frame, answer.answers)
                        if applied:
                            print("     matching recommendations:")
                            for item in applied:
                                print("       " + item)
                    except Exception as e:
                        print(f"     matching annotation error: {e}")
                elif settings.highlight_recommendations and q.choices:
                    try:
                        matched = await highlight_answer(
                            frame, q, answer.answers, best_choice
                        )
                        if matched:
                            print("     highlighted: " + ", ".join(x.text for x in matched))
                    except Exception as e:
                        print(f"     highlight error: {e}")
            elif settings.mode == "fill":
                try:
                    result = await fill_answer(
                        frame, q, answer.answers, best_choice
                    )
                    if result["filled"]:
                        filled_count += 1
                        if canvas_auto:
                            _canvas_navigation.remember(page,frame_index,q,sig,answer.answers)
                    print(
                        f"     fill: {result['filled']} — "
                        f"{result['details'][:220]}"
                    )
                except Exception as e:
                    print(f"     fill error: {e}")
        else:
            if is_study_platform and settings.mode=='fill' and settings.mcgraw_auto:
                overlay_items[-1]['explanation']=schedule_answer_recovery(page,cache_key,answer)
                seen.pop(cache_key,None)
                handled+=1
                continue
            action_note = f"Paused on this question: confidence {answer.confidence:.0%} is below {settings.min_confidence:.0%}. Review manually."
            print(
                f"     below confidence threshold "
                f"({settings.min_confidence:.2f})"
            )

        if action_note:
            overlay_items[-1]["explanation"] = action_note
        _solve_retries.get(page,{}).pop(cache_key,None)
        seen[cache_key] = sig
        handled += 1

    if is_study_platform:
        status = (
            f"Analyzed {handled} new/changed question(s). "
            + ("Verified McGraw answer application enabled."
             if settings.mode == "fill" and settings.mcgraw_auto
             else "Study mode: recommendations are highlighted, never selected.")
        )
    else:
        status = (
            f"Analyzed {handled} new/changed question(s). "
            + (
                f"Applied answers to {filled_count} question(s) in this scan."
                if settings.mode == "fill"
                else "Suggestion mode."
            )
        )

    if handled or overlay_items:
        await update_overlay(page, site_name, status, overlay_items)
    if canvas_auto:
        navigation=await _canvas_navigation.advance(page,found,signature,session_pacer(page))
        if navigation:await update_overlay(page,site_name,navigation,overlay_items)
    if (is_study_platform and settings.mode == "fill" and settings.mcgraw_auto
            and filled_count == len(found)):
        if not await submit_paced_confidence(page, settings.mcgraw_confidence, fingerprint):
            # Retry a missing confidence button next scan, without another API call.
            for frame_index, _, q in found:
                seen.pop(f"{frame_index}:{q.qid}", None)
    # Submit once, only when every detected question was filled this cycle.
    if (settings.mode == "fill" and not is_study_platform
            and is_local_page(page) and filled_count == len(found)):
        if await auto_submit(page):
            await next_question(page)
    return handled


async def print_dom_diagnostics(page, context=None):
    if context is not None:
        await print_open_pages(context)
    print("\nDOM diagnostics")
    print("---------------")
    for i, frame in enumerate(page.frames):
        try:
            info = await debug_dom(frame)
        except Exception as e:
            print(f"\nFrame {i}: diagnostic error: {e}")
            continue

        print(f"\nFrame {i}")
        print(f"URL: {info.get('url','')}")
        print(f"Title: {info.get('title','')}")
        print(
            "shadowRoots={shadowRoots} inputs={inputs} radios={radios} "
            "checkboxes={checkboxes} buttons={buttons}".format(**info)
        )
        print("Visible text sample:")
        print(info.get("bodyText", "")[:2200])

        sample = info.get("sample", [])
        if sample:
            print("\nControl samples:")
            for x in sample[:40]:
                print(
                    f"  <{x.get('tag')}> role={x.get('role')!r} "
                    f"type={x.get('type')!r} aria-checked={x.get('ariaChecked')!r} "
                    f"class={x.get('cls')!r} text={x.get('text')!r}"
                )


async def run(args):
    if settings.mode not in {"assist", "fill"}:
        raise SystemExit("MODE must be 'assist' or 'fill'.")

    if settings.mcgraw_confidence not in {"High", "Medium", "Low"}:
        raise SystemExit("MCGRAW_CONFIDENCE must be High, Medium, or Low.")

    SessionPacer(settings.pacing_minutes, settings.pacing_questions)  # Validate before opening a browser.

    solver = Solver(
        settings.api_key,
        settings.model,
        fast_mode=settings.fast_mode,
        reasoning_effort=settings.fast_reasoning,
        max_output_tokens=settings.fast_max_output_tokens,
        book_path=settings.book_index if settings.book_reference else None,
    )
    seen: Dict[str, str] = {}
    last_recovery_command=''

    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(settings.profile_dir),
            headless=settings.headless,
            channel=settings.browser_channel or None,
            viewport=None,
            args=["--start-maximized","--disable-gpu"] if settings.compatibility_mode else ["--start-maximized"],
        )

        page = context.pages[0] if context.pages else await context.new_page()
        context.set_default_timeout(5000)

        if args.url:
            await page.goto(args.url, wait_until="domcontentloaded")
        elif settings.start_url != "about:blank":
            await page.goto(settings.start_url, wait_until="domcontentloaded")
        elif page.url in ('about:blank', ''):
            from browser_welcome import WELCOME_HTML
            await page.set_content(WELCOME_HTML, wait_until='domcontentloaded')
            print('Chrome listo: pega el enlace de tu actividad en la barra de direcciones de la nueva ventana.')

        print("\nWeb QA Study Assistant — McGraw adapter v9 FAST")
        print("---------------------------------------")
        print(f"Generic-page mode: {settings.mode}")
        print(f"Model: {settings.model}")
        print(f"Vision: {settings.use_vision}")
        print(f"FAST mode: {settings.fast_mode} | reasoning={settings.fast_reasoning} | poll={settings.poll_seconds:.2f}s")
        print(f"McGraw automation: {settings.mcgraw_auto} | confidence: {settings.mcgraw_confidence} | requires MODE=fill")
        print("Canvas: Next automático tras verificar respuestas y ritmo; envío final manual. Submit genérico: solo entorno local.")
        print("\nCommands: [Enter]=scan, w=watch, p=list pages, d=DOM diagnostic, c=clear cache, q=quit")
        print("McGraw popups/new tabs, matching, and fill-in-the-blank questions are detected automatically in v8.")

        watch = args.watch
        was_paused = False
        pacing_task=asyncio.create_task(watch_updates(args.control_file,apply_live_pacing)) if args.control_file else None

        try:
            while True:
                if args.control_file:
                    try:
                        command = Path(args.control_file).read_text(encoding="utf-8").strip()
                    except OSError:
                        command = "run"
                    if command == "stop":
                        break
                    if command == "pause":
                        for pacer in list(_pacers.values()):
                            pacer.pause()
                        was_paused = True
                        await asyncio.sleep(0.25)
                        continue
                    if was_paused:
                        for pacer in list(_pacers.values()):
                            pacer.resume()
                        for open_page in context.pages:
                            resume_interactions(open_page)
                            _canvas_navigation.resume(open_page)
                        was_paused = False
                    if command.startswith('recover:') and command!=last_recovery_command:
                        last_recovery_command=command
                        target=await choose_target_page(context)
                        if target:
                            from recovery import recover_page
                            from question_resources import restore_question_resource
                            await restore_question_resource(target)
                            await recover_page(target,manual=True)
                            seen.clear()
                            _solve_retries.pop(target,None)
                            _canvas_navigation.reset(target)
                if watch:
                    try:
                        target_page = await choose_target_page(context)
                        if target_page is None:
                            print("No open browser page found.")
                        else:
                            handled = await analyze_page(target_page, solver, seen)
                            if handled:
                                print(
                                    f"\nWatching {target_page.url} ... "
                                    f"{handled} question(s) handled."
                                )
                    except Exception as e:
                        print(f"Watch cycle error: {e}")

                    await asyncio.sleep(settings.poll_seconds)
                    continue

                cmd = (
                    await asyncio.to_thread(input, "\ncommand> ")
                ).strip().lower()

                if cmd in {"q", "quit", "exit"}:
                    break

                if cmd in {"p", "pages"}:
                    await print_open_pages(context)
                    continue

                if cmd in {"d", "debug", "diagnostic"}:
                    target_page = await choose_target_page(context)
                    if target_page is None:
                        print("No open browser page found.")
                    else:
                        print(f"Diagnostic target: {target_page.url}")
                        await print_dom_diagnostics(target_page, context=context)
                    continue

                if cmd in {"c", "clear"}:
                    seen.clear()
                    for open_page in context.pages:
                        clear_navigation(open_page)
                    print("Question cache cleared.")
                    continue

                if cmd in {"w", "watch"}:
                    watch = True
                    print(
                        "Watch mode enabled. "
                        "The assistant will update when the visible question changes."
                    )
                    continue

                target_page = await choose_target_page(context)
                if target_page is None:
                    print("No open browser page found.")
                else:
                    print(f"Scanning: {target_page.url}")
                    await analyze_page(target_page, solver, seen)

        except KeyboardInterrupt:
            print("\nStopping.")
        finally:
            if pacing_task:
                pacing_task.cancel()
                try:await pacing_task
                except asyncio.CancelledError:pass
            await context.close()

def main():
    parser = argparse.ArgumentParser(
        description="AI browser study assistant with McGraw adapter"
    )
    parser.add_argument("--url", help="Page to open")
    parser.add_argument("--control-file", help=argparse.SUPPRESS)
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Continuously detect new/changed questions",
    )
    args = parser.parse_args()
    asyncio.run(run(args))

if __name__ == "__main__":
    main()
