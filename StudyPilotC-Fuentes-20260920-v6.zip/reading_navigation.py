"""Bounded return to the exact page from which this app opened Reading."""
import time

RETURN_NAMES=('To Questions','Back to Questions','Return to Questions','Back to Question',
              'Return to Question','Back to assignment','Return to assignment',
              'Back to activity','Return to activity','Back to practice','Back')


async def checkpoint(page):
    state={'url':page.url,'started':time.monotonic(),'back_used':False,'reload_used':False}
    try: state['history']=await page.evaluate('history.length')
    except Exception: state['history']=0
    return state


async def return_control(page):
    from mcgraw_actions import named_control,allowed_mcgraw
    result=await named_control(page,RETURN_NAMES)
    if result is not None:return result
    # Icon-only return controls sometimes have a title but no accessible name.
    matches=[]
    for frame in page.frames:
        if not allowed_mcgraw(frame):continue
        controls=frame.locator('button[title],a[title],[role="button"][title]')
        for i in range(await controls.count()):
            item=controls.nth(i)
            title=(await item.get_attribute('title') or '').strip().casefold()
            if title in {s.casefold() for s in RETURN_NAMES} and await item.is_visible() and await item.is_enabled():
                matches.append(item)
    return matches[0] if len(matches)==1 else None


async def fallback_return(page,state):
    """Try history once, then the captured URL once; never a back/reload loop."""
    from mcgraw_actions import allowed_mcgraw
    from types import SimpleNamespace
    if not state or not allowed_mcgraw(page) or not allowed_mcgraw(SimpleNamespace(url=state.get('url',''))):return False
    elapsed=time.monotonic()-state['started']
    if elapsed<3:return False
    if not state['back_used']:
        state['back_used']=True
        try:
            if await page.evaluate('history.length')>state.get('history',0):
                await page.go_back(wait_until='domcontentloaded',timeout=8000)
                return True
        except Exception:pass
    if elapsed>=6 and not state['reload_used']:
        state['reload_used']=True
        try:
            await page.goto(state['url'],wait_until='domcontentloaded',timeout=8000)
            return True
        except Exception:pass
    return False
