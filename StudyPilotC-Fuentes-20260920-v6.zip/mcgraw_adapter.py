from __future__ import annotations
from models import Choice, Question

MCGRAW_EXTRACT_JS = r"""
() => {
  const clean = s => (s || '').replace(/\s+/g, ' ').trim();

  // Question controls can be below the fold or above it after a previous click.
  // Rendered content remains part of the question even when scrolling hides it.
  const rendered = el => {
    if (!el || !el.getBoundingClientRect || el.closest?.('#webqa-overlay,[data-webqa-fill-badge],[data-webqa-match-badge]')) return false;
    const st=getComputedStyle(el), r=el.getBoundingClientRect();
    return st.display!=='none' && st.visibility!=='hidden' && Number(st.opacity||1)>0 && r.width>2 && r.height>2;
  };
  const floating = el => {
    for(let node=el;node;node=node.parentElement) {
      if(/^(fixed|sticky)$/.test(getComputedStyle(node).position)) return true;
    }
    return false;
  };

  const visible = el => {
    if (!el || !el.getBoundingClientRect || el.closest?.('#webqa-overlay,[data-webqa-fill-badge],[data-webqa-match-badge]')) return false;
    const st = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    const vw = window.innerWidth || document.documentElement.clientWidth;
    const vh = window.innerHeight || document.documentElement.clientHeight;

    return st.display !== 'none' &&
           st.visibility !== 'hidden' &&
           Number(st.opacity || 1) > 0 &&
           r.width > 2 && r.height > 2 &&
           r.bottom > 0 && r.top < vh &&
           r.right > 0 && r.left < vw;
  };

  const textOf = el => clean(el?.innerText || el?.textContent || '');
  const semanticMathText = el => {
    const clone=el.cloneNode(true);
    // MathJax keeps its original MathML as text inside script/template nodes.
    // textContent includes that source even though it is never displayed.
    clone.querySelectorAll('script,style,template').forEach(x=>x.remove());
    let replaced=false;
    for(const renderer of clone.querySelectorAll('mjx-container,.MathJax,.katex')) {
      const math=renderer.querySelector('math');
      if(!math) continue;
      const m=math.cloneNode(true);
      m.querySelectorAll('annotation,annotation-xml').forEach(x=>x.remove());
      renderer.replaceWith(document.createTextNode(m.textContent));
      replaced=true;
    }
    clone.querySelectorAll('annotation,annotation-xml,[aria-live],[role="status"],.sr-only,.visually-hidden').forEach(x=>x.remove());
    if(!replaced && clone.querySelectorAll('math').length===1) {
      const math=clone.querySelector('math');
      const key=s=>clean(s).normalize('NFKC').replace(/[−–—]/g,'-').replace(/\s/g,'');
      const single=key(math.textContent),whole=key(clone.textContent);
      // MathJax v2 may put assistive MathML beside its visual renderer.
      if(single && (whole===single || whole===single+single)) return clean(math.textContent);
    }
    return replaced ? clean(clone.textContent) : '';
  };
  // Drag widgets change aria-label to navigation announcements while moving.
  // Those labels describe position, not the answer printed on the tile.
  const tileText = el => {
    const mathText=semanticMathText(el);
    if(mathText) return mathText;
    const clone=el.cloneNode(true);
    clone.querySelectorAll('[aria-live],[role="status"],.sr-only,.visually-hidden').forEach(x=>x.remove());
    let text=el.innerText || clone.textContent || '';
    el.querySelectorAll('[aria-live],[role="status"],.sr-only,.visually-hidden').forEach(x=>{
      if(x.textContent) text=text.replace(x.textContent,'');
    });
    text=clean(text);
    if(text && !/^position\s+\d+\s+of\s+\d+/i.test(text)) return text;
    const label=clean(el.getAttribute('aria-label') || '');
    return /^position\s+\d+\s+of\s+\d+/i.test(label) ? '' : label;
  };

  const allRoots = () => {
    const roots = [document];
    const queue = [document.documentElement];

    while (queue.length) {
      const n = queue.shift();
      if (!n || !n.querySelectorAll) continue;

      for (const el of n.querySelectorAll('*')) {
        if (el.shadowRoot) {
          roots.push(el.shadowRoot);
          queue.push(el.shadowRoot);
        }
      }
    }
    return roots;
  };

  const roots = allRoots();
  // Feedback contains the submitted controls, not an unanswered question.
  let feedbackText = document.body?.innerText || '';
  const assistantPanel = document.getElementById('webqa-overlay');
  if (assistantPanel) feedbackText = feedbackText.replace(assistantPanel.innerText, '');
  feedbackText = clean(feedbackText);
  if (/your\s+answer\s*(incorrect|correct)/i.test(feedbackText) ||
      /before moving on,? you must review a resource/i.test(feedbackText)) return [];


  const qsa = sel => {
    const out = [];
    for (const root of roots) {
      try { out.push(...root.querySelectorAll(sel)); } catch (_) {}
    }
    return [...new Set(out)].filter(el => !el.closest?.('#webqa-overlay,[data-webqa-fill-badge],[data-webqa-match-badge]'));
  };

  // Retired or rearranged controls must not retain identifiers used for clicks.
  for (const attr of ['data-webqa-cid','data-webqa-qid','data-webqa-fill-index','data-webqa-match-target','data-webqa-match-option-text','data-webqa-select','data-webqa-order-item']) {
    for (const el of qsa(`[${attr}]`)) el.removeAttribute(attr);
  }

  // Clear recommendations from the previous question every cycle.
  for (const root of roots) {
    try {
      for (const el of root.querySelectorAll('[data-webqa-highlight="1"]')) {
        el.style.removeProperty('outline');
        el.style.removeProperty('outline-offset');
        el.style.removeProperty('box-shadow');
        el.style.removeProperty('border-radius');
        el.removeAttribute('data-webqa-highlight');
      }
    } catch (_) {}
  }



  // ---------- FILL IN THE BLANK ----------
  const fillHeadingCandidates = qsa(
    'h1,h2,h3,h4,h5,h6,[role="heading"],div,span,p'
  ).filter(el => {
    if (!visible(el)) return false;
    const t = textOf(el);
    return /^fill\s+in\s+the\s+blank\s+question$/i.test(t);
  });

  if (fillHeadingCandidates.length) {
    fillHeadingCandidates.sort((a,b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();
      return ar.top - br.top || ar.left - br.left;
    });

    const heading = fillHeadingCandidates[0];
    const hr = heading.getBoundingClientRect();

    // Locate visible text inputs below the heading and above footer controls.
    const textInputs = qsa(
      'input[type="text"],input:not([type]),textarea'
    ).filter(el => {
      if (!visible(el)) return false;
      const r = el.getBoundingClientRect();
      return r.top > hr.bottom &&
             !el.disabled && !el.readOnly &&
             r.left < window.innerWidth * 0.95;
    });

    if (textInputs.length) {
      // Clear old suggestion badges.
      for (const root of roots) {
        try {
          for (const el of root.querySelectorAll('[data-webqa-fill-badge="1"]')) {
            el.remove();
          }
        } catch (_) {}
      }

      // Find a prompt container around all blanks.
      let container = textInputs[0];
      let node = textInputs[0];

      for (let depth = 0; depth < 8 && node; depth++, node = node.parentElement) {
        if (!visible(node)) continue;
        const t = textOf(node);
        const r = node.getBoundingClientRect();

        const containedInputs = [...node.querySelectorAll?.(
          'input[type="text"],input:not([type]),textarea'
        ) || []].filter(visible);

        if (
          containedInputs.length >= textInputs.length &&
          t.length >= 8 &&
          t.length < 6000 &&
          r.top <= hr.bottom + 120 &&
          r.bottom < window.innerHeight * 0.88
        ) {
          container = node;
          break;
        }
      }

      // Mark inputs so Python can annotate each one later.
      const choices = [];
      textInputs.forEach((input, idx) => {
        const cid = `mcgraw-fill-${idx + 1}`;
        input.setAttribute('data-webqa-cid', cid);
        input.setAttribute('data-webqa-fill-index', String(idx + 1));

        choices.push({
          cid,
          text: `Blank ${idx + 1}`,
          control_type: 'text',
          checked: false,
          value: clean(input.value || '')
        });
      });

      // Reconstruct the visible sentence/prompt.
      // Prefer the nearest text-bearing container and remove heading/footer text.
      let prompt = textOf(container);

      prompt = prompt
        .replace(/fill\s+in\s+the\s+blank\s+question/ig, '')
        .replace(/rate\s+your\s+confidence.*$/i, '')
        .replace(/need\s+help.*$/i, '')
        .trim();

      // If innerText loses blank positions, build a readable template by walking
      // the container's direct text/element nodes and replacing inputs with [Blank N].
      try {
        const buildTemplate = root => {
          let out = '';

          const walk = node => {
            if (node.nodeType === Node.TEXT_NODE) {
              out += node.nodeValue || '';
              return;
            }

            if (node.nodeType !== Node.ELEMENT_NODE) return;
            const el = node;

            if (el.matches?.('input[type="text"],input:not([type]),textarea')) {
              const idx = el.getAttribute('data-webqa-fill-index') || '?';
              out += ` [Blank ${idx}] `;
              return;
            }

            const style=getComputedStyle(el);
            if(style.display==='none'||style.visibility==='hidden'||el.closest('#webqa-overlay')) return;

            for (const ch of el.childNodes) walk(ch);
          };

          walk(root);
          return clean(out);
        };

        const templated = buildTemplate(container);
        if (templated && templated.length >= 8) {
          prompt = templated
            .replace(/fill\s+in\s+the\s+blank\s+question/ig, '')
            .trim();
        }
      } catch (_) {}

      try {
        container.setAttribute('data-webqa-qid', 'mcgraw-current-fillin');
      } catch (_) {}

      return [{
        qid: 'mcgraw-current-fillin',
        text: prompt,
        kind: 'fill_blank',
        choices,
        has_visual: !!container.querySelector?.('img,canvas,svg,math,mjx-container'),
        html_hint: 'mcgraw-dedicated-fillin-v8'
      }];
    }
  }



  // ---------- ORDERING ----------
  const orderHeading = qsa('h1,h2,h3,h4,[role="heading"],div,span').find(el => rendered(el) && /^ordering question$/i.test(textOf(el)));
  if (orderHeading) {
    const rendered = el => {
      const r=el.getBoundingClientRect(), st=getComputedStyle(el);
      return st.display!=='none' && st.visibility!=='hidden' && r.width>2 && r.height>2;
    };
    const top=orderHeading.getBoundingClientRect().bottom;
    const footer=qsa('p,div,span').filter(el=>rendered(el)&&!floating(el)&&/^(need help|rate your confidence)/i.test(textOf(el))&&el.getBoundingClientRect().top>top);
    const bottom=Math.min(Infinity,...footer.map(el=>el.getBoundingClientRect().top));
    let items=qsa('[draggable="true"],[aria-grabbed],[role="option"],[role="listitem"],[tabindex="0"],[tabindex="-1"]').filter(el=>{
      const r=el.getBoundingClientRect(),t=textOf(el);
      return rendered(el)&&r.top>top&&r.bottom<bottom&&r.width>100&&t.length>0&&t.length<350&& !/instructions|click and drag/i.test(t);
    });
    items=items.filter(el=>!items.some(other=>other!==el&&other.contains(el)));
    items.sort((a,b)=>a.getBoundingClientRect().top-b.getBoundingClientRect().top);
    if(items.length<2)return [];
    const first=items[0].getBoundingClientRect().top;
    const prompts=qsa('p,div,span').filter(el=>{
      const r=el.getBoundingClientRect(),t=textOf(el);
      return rendered(el)&&r.top>=top&&r.bottom<first&&t.length>15&&t.length<2000&&
        !/^(click and drag|instructions)/i.test(t)&&!el.querySelector('[draggable],[role="option"]');
    });
    const prompt=[...new Set(prompts.map(textOf))].sort((a,b)=>b.length-a.length)[0];
    if(!prompt)return [];
    const choices=items.map((el,i)=>{
      const cid=`mcgraw-order-${i}`;
      el.setAttribute('data-webqa-cid',cid);el.setAttribute('data-webqa-order-item','1');
      // McGraw's accessibility helper repeats the label in innerText:
      // "Choice 3 of 3. Glycogen toggle button Glycogen".
      const announced=clean(el.getAttribute('aria-label')||'').match(/^Choice\s+\d+\s+of\s+\d+\.\s*(.+)$/i);
      return {cid,text:announced ? announced[1] : tileText(el),control_type:'ordering',checked:false,value:''};
    });
    orderHeading.parentElement.setAttribute('data-webqa-qid','mcgraw-ordering');
    return [{qid:'mcgraw-ordering',kind:'ordering',text:prompt,choices,has_visual:false,html_hint:'mcgraw-dedicated-ordering-v1'}];
  }

  // ---------- MATCHING / DRAG-AND-DROP ----------
  // McGraw uses a different component for matching questions. It often exposes
  // accessible phrases such as "Drag and drop application" and
  // "<target> drop zone empty." even when there are no radio/checkbox controls.
  const pageText = clean(document.body?.innerText || document.body?.textContent || '');

  const matchingVisible = el => {
    if (!el || el.closest?.('#webqa-overlay')) return false;
    const st = getComputedStyle(el), r = el.getBoundingClientRect();
    return st.display !== 'none' && st.visibility !== 'hidden' && Number(st.opacity || 1) > 0 && r.width > 2 && r.height > 2;
  };
  const matchingPage = /matching question/i.test(pageText) ||
    /drag\s+and\s+drop\s+application/i.test(pageText) ||
    /drop\s+zone\s+empty/i.test(pageText);

  if (matchingPage) {
    // Remove badges/highlights left by the previous matching question.
    for (const root of roots) {
      try {
        for (const el of root.querySelectorAll('[data-webqa-match-badge="1"]')) {
          el.remove();
        }
        for (const el of root.querySelectorAll('[data-webqa-match-option-highlight="1"]')) {
          el.style.removeProperty('outline');
          el.style.removeProperty('outline-offset');
          el.style.removeProperty('box-shadow');
          el.removeAttribute('data-webqa-match-option-highlight');
        }
      } catch (_) {}
    }

    const viewportH = window.innerHeight || document.documentElement.clientHeight;
    const viewportW = window.innerWidth || document.documentElement.clientWidth;

    // Find visible drop zones.
    const dropCandidates = qsa(
      '[aria-label*="drop zone" i],' +
      '[aria-describedby*="drop" i],' +
      '[class*="dropzone" i],' +
      '[class*="drop-zone" i],' +
      '[class*="drop_zone" i],' +
      '[data-testid*="drop" i]'
    ).filter(matchingVisible);

    const targets = [];
    const targetKey = text => clean(text).normalize('NFKC').toLowerCase()
      .replace(/[−–—]/g,'-').replace(/[\s\u200b-\u200f\u2060\ufeff^_{}]/g,'');

    const addTarget = (name, el) => {
      name = clean(name)
        .replace(/\s+drop\s+zone.*$/i, '')
        .replace(/\s+empty\.?$/i, '')
        .trim();

      if (!name || name.length > 100) return;
      if (/^(drop|drop zone|empty)$/i.test(name)) return;

      const key = targetKey(name);
      // After a drop the placed button announces "... drop zone has choice".
      // It is inside an already discovered destination, not an extra row.
      const previous=targets.find(t=>targetKey(t.name)===key &&
        (t.el===el || t.el.contains(el) || el.contains(t.el)));
      if(previous) {
        if(el!==previous.el && el.contains(previous.el)) {
          previous.el.removeAttribute('data-webqa-match-target');
          previous.el=el;previous.rect=el.getBoundingClientRect();
          el.setAttribute('data-webqa-match-target',previous.name);
        }
        return;
      }

      try {
        el.setAttribute('data-webqa-match-target', name);
      } catch (_) {}

      targets.push({
        name,
        el,
        rect: el.getBoundingClientRect()
      });
    };

    for (const candidate of dropCandidates) {
      let dz=candidate;
      const cr=candidate.getBoundingClientRect();
      if(cr.width<40) {
        // Some classes matching "drop-zone" belong only to the 5px brace.
        // Bind the wide answer rectangle on this row, never the decoration.
        let parent=candidate.parentElement;
        let resolved=null;
        for(let depth=0;parent && depth<3 && !resolved;depth++,parent=parent.parentElement) {
          const pr=parent.getBoundingClientRect();
          if(pr.width>100 && pr.left>=cr.left-20 && Math.abs(pr.top-cr.top)<20 && pr.height<=cr.height+30) {
            resolved=parent;break;
          }
          resolved=[...parent.querySelectorAll('div,[role="button"],[role="listbox"]')].find(el=>{
            const r=el.getBoundingClientRect();return el!==candidate && matchingVisible(el) &&
              r.width>100 && r.left>=cr.right-5 && r.left<=cr.right+45 &&
              Math.abs(r.top-cr.top)<20 && Math.abs(r.height-cr.height)<30;
          });
        }
        if(!resolved) continue;
        dz=resolved;
      }
      let raw = clean(
        candidate.getAttribute?.('aria-label') || dz.getAttribute?.('aria-label') ||
        dz.getAttribute?.('title') ||
        dz.textContent ||
        ''
      );

      let name = raw.replace(/\s+drop\s+zone.*$/i, '').trim();
      if (!dz.getAttribute('aria-label') && dz.querySelector('[draggable], [data-webqa-cid]')) name = '';

      // If the drop zone itself doesn't contain the target name, find a nearby
      // short label to its left on the same row.
      {
        const dr = dz.getBoundingClientRect();

        const rowLabels = qsa('div,span,p,label,li,button').filter(el => {
          if (!matchingVisible(el) || el === dz) return false;
          const t = tileText(el);
          if (!t || t.length > 90) return false;

          const r = el.getBoundingClientRect();
          const verticalOverlap =
            Math.min(r.bottom, dr.bottom) - Math.max(r.top, dr.top);

          return verticalOverlap > Math.min(r.height, dr.height) * 0.25 &&
                 r.right <= dr.left + 20 &&
                 r.left < dr.left &&
                 r.left < viewportW * 0.55;
        });

        rowLabels.sort((a,b) => {
          const ar = a.getBoundingClientRect();
          const br = b.getBoundingClientRect();
          return Math.abs(dr.left - ar.right) - Math.abs(dr.left - br.right);
        });

        if (rowLabels.length && (candidate!==dz || !name || /^(empty|drop zone)$/i.test(name) ||
            rowLabels[0].querySelector('math,mjx-container,.MathJax,.katex'))) {
          name = tileText(rowLabels[0]);
        }
      }

      addTarget(name, dz);
    }

    // Fallback: parse the accessible text McGraw exposes, e.g.
    // "Amino group Amino group drop zone empty."
    if (!targets.length) {
      const re = /([A-Za-z][A-Za-z0-9()\\/+\\-\s]{1,70}?)\s+\1\s+drop\s+zone\s+empty\.?/gi;
      let m;
      while ((m = re.exec(pageText)) !== null) {
        const name = clean(m[1]);
        if (!name) continue;

        // Find a visible element whose text is exactly this target.
        const el = qsa('div,span,p,label,li,button').find(x =>
          matchingVisible(x) && clean(x.innerText || x.textContent || '').toLowerCase() === name.toLowerCase()
        );

        if (el) addTarget(name, el);
      }
    }

    if (targets.length >= 2) {
      const lastTargetBottom = Math.max(...targets.map(t => t.rect.bottom));

      // Determine where the help/confidence footer starts.
      let endY = Infinity;

      for (const el of qsa('div,span,p,button,a').filter(matchingVisible)) {
        const t = clean(el.innerText || el.textContent || '');
        const r = el.getBoundingClientRect();
        // The confidence bar is pinned to the viewport, not the end of
        // the answer bank. Its Y coordinate must not truncate lower tiles.
        let floating=false;
        for(let parent=el;parent;parent=parent.parentElement) {
          if(['fixed','sticky'].includes(getComputedStyle(parent).position)) {
            floating=true;break;
          }
        }
        if(floating) continue;

        if (
          r.top > lastTargetBottom &&
          (
            /^need\s+help/i.test(t) ||
            /^rate\s+your\s+confidence/i.test(t)
          )
        ) {
          endY = Math.min(endY, r.top - 5);
        }
      }

      const options = [];
      const seenOptions = new Set();
      const seenElements = new WeakSet();

      const isBadOption = t => {
        t = clean(t);
        if (!t || t.length > 600) return true;
        if (/^position\s+\d+\s+of\s+\d+/i.test(t)) return true;
        if (/^instructions?$/i.test(t)) return true;
        if (/^reading$/i.test(t)) return true;
        if (/^(high|medium|low)$/i.test(t)) return true;
        if (/^need\s+help/i.test(t)) return true;
        if (/^rate\s+your\s+confidence/i.test(t)) return true;
        if (/drop\s+zone/i.test(t)) return true;
        if (targets.some(x => x.name.toLowerCase() === t.toLowerCase())) return true;
        return false;
      };

      const addOption = (text, el) => {
        el = el.closest('[draggable="true"],[aria-grabbed]') ||
          el.closest('[class*="draggable" i],[class*="drag-item" i]') || el;
        if(seenElements.has(el)) return;
        // The container and its nested accessible labels can all be returned
        // by the candidate selector. Bind exactly one answer to the real tile.
        text = tileText(el) || clean(text);
        if (isBadOption(text)) return;

        const key = text.toLowerCase();
        if (seenOptions.has(key)) return;
        seenElements.add(el);
        seenOptions.add(key);

        const cid = `mcgraw-match-option-${options.length + 1}`;

        try {
          el.setAttribute('data-webqa-cid', cid);
          el.setAttribute('data-webqa-match-option-text', text);
        } catch (_) {}

        options.push({
          cid,
          text,
          control_type: 'drag-option',
          checked: false,
          value: ''
        });
      };

      // Prefer actual draggable elements / buttons in the answer bank.
      const draggable = qsa(
        '[draggable="true"],' +
        '[aria-grabbed],' +
        '[class*="draggable" i],' +
        '[class*="drag-item" i],' +
        '[data-testid*="drag" i]'
      ).filter(el => {
        if (!matchingVisible(el)) return false;
        const r = el.getBoundingClientRect();
        return (r.top > lastTargetBottom + 10 && r.top < endY) || targets.some(t => t.el.contains(el));
      });

      for (const el of draggable) {
        // A whole answer bank is not itself an answer tile.
        const nested=[...el.querySelectorAll('[draggable="true"],[aria-grabbed]')];
        if(nested.some(a=>nested.some(b=>a!==b && !a.contains(b) && !b.contains(a)))) continue;
        const t = tileText(el);
        addOption(t, el);
      }
      // A committed answer may be rendered as plain text, no longer draggable.
      // Keep it in the question so a partial retry can recognize completed rows.
      for(const target of targets) {
        const text=tileText(target.el);
        if(text && !isBadOption(text)) addOption(text,target.el);
      }

      // Visual fallback: formula/answer tiles are short leaf elements below
      // the drop zones and above the Help area.
      if (options.length < 2) {
        const leaves = qsa(
          'button,div,span,p,label,li,[role="button"],[role="option"]'
        ).filter(el => {
          if (!matchingVisible(el)) return false;
          const t = clean(el.innerText || el.textContent || '');
          if (isBadOption(t)) return false;

          const r = el.getBoundingClientRect();

          if (r.top <= lastTargetBottom + 10 || r.top >= endY) return false;
          if (r.left > viewportW * 0.98) return false;

          // Keep leaf-like elements to avoid parent duplicates.
          const duplicateChild = [...el.children].some(
            ch => matchingVisible(ch) && clean(ch.innerText || ch.textContent || '') === t
          );

          return !duplicateChild;
        });

        leaves.sort((a,b) => {
          const ar = a.getBoundingClientRect();
          const br = b.getBoundingClientRect();
          return ar.top - br.top || ar.left - br.left;
        });

        let lastKey = '';
        for (const el of leaves) {
          const t = clean(el.innerText || el.textContent || '');

          // Matching options are normally very short formulas/terms. Avoid
          // collecting whole sentences from the footer.
          if (t.length > 600) continue;

          const key = t.toLowerCase();
          if (key === lastKey) continue;

          addOption(t, el);
          lastKey = key;

          if (options.length >= 12) break;
        }
      }

      if (options.length >= 1) {
        // Find the question instruction from accessible page text.
        let prompt = 'Match each item with the correct option.';

        const promptMatch = pageText.match(
          /(Match\s+each[^.?!]{5,220}[.?!])/i
        );

        if (promptMatch) {
          prompt = clean(promptMatch[1]);
        }

        const targetNames = targets.map(t => t.name);

        // Mark a reasonable visible container for debugging / future screenshots.
        let qContainer = targets[0].el;
        let node = qContainer;

        for (let depth = 0; depth < 6 && node; depth++, node = node.parentElement) {
          const txt = clean(node.innerText || node.textContent || '');
          const r = node.getBoundingClientRect();

          if (
            txt.length < 12000 &&
            r.height < viewportH * 1.8 &&
            targetNames.every(name => txt.toLowerCase().includes(name.toLowerCase()))
          ) {
            qContainer = node;
          }
        }

        try {
          qContainer.setAttribute('data-webqa-qid', 'mcgraw-current-matching');
        } catch (_) {}

        return [{
          qid: 'mcgraw-current-matching',
          text:
            prompt +
            ' Targets: ' +
            targetNames.join('; '),
          kind: 'matching',
          choices: options,
          // Text/MathML exposed by McGraw is enough for this matching format.
          // Avoid screenshotting an oversized drag/drop container.
          has_visual: !!qContainer.querySelector?.('img,canvas,svg,math,mjx-container'),
          html_hint: 'mcgraw-dedicated-matching-v8-full-bank'
        }];
      }
    }
  }


  const TYPE_RE =
    /^(multiple\s+select\s+question|multiple\s+choice\s+question|true\s*(?:\/|or)?\s*false\s+question)$/i;

  const instructionRe =
    /^(select\s+all\s+that\s+apply|choose\s+the\s+(best|correct)\s+answer|select\s+one)\.?$/i;

  const utilityPatterns = [
    TYPE_RE,
    instructionRe,
    /^show by$/i,
    /^show by date$/i,
    /^show by type$/i,
    /^search for assignment$/i,
    /^search assignments/i,
    /^need\s+help.*$/i,
    /^rate\s+your\s+confidence.*$/i,
    /^(high|medium|low)$/i,
    /^reading$/i,
    /^exit\s+assignment$/i,
    /^privacy\s+center$/i,
    /^terms\s+of\s+use$/i,
    /^\d+\s+of\s+\d+\s+concepts?\s+completed$/i,
  ];

  const isUtility = t => {
    t = clean(t);
    if (!t) return true;
    if (utilityPatterns.some(re => re.test(t))) return true;
    if (/copyright|all rights reserved/i.test(t)) return true;
    return false;
  };

  const leafEls = qsa(
    'h1,h2,h3,h4,h5,h6,[role="heading"],p,div,span,label,li'
  ).filter(el => {
    if (!rendered(el)) return false;

    const t = textOf(el);
    if (!t || t.length > 700) return false;

    // Avoid parent/child duplicate text nodes.
    const duplicateChild = [...el.children].some(
      ch => rendered(ch) && textOf(ch) === t
    );
    return !duplicateChild;
  });

  // Sort in visual order.
  leafEls.sort((a, b) => {
    const ar = a.getBoundingClientRect();
    const br = b.getBoundingClientRect();
    return ar.top - br.top || ar.left - br.left;
  });

  // ---------- 1. Locate the CURRENT question type heading ----------
  let typeEl = null;

  const typeCandidates = leafEls.filter(el => TYPE_RE.test(textOf(el)));

  if (typeCandidates.length) {
    // Prefer the left-side, upper visible heading.
    typeCandidates.sort((a,b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();

      const as =
        (ar.left < window.innerWidth * 0.55 ? 100 : 0) -
        Math.abs(ar.top - window.innerHeight * 0.18);

      const bs =
        (br.left < window.innerWidth * 0.55 ? 100 : 0) -
        Math.abs(br.top - window.innerHeight * 0.18);

      return bs - as;
    });

    typeEl = typeCandidates[0];
  }

  if (!typeEl) {
    // Additional semantic SmartBook input types. Scope to a recognized heading;
    // never collect page-wide search/login fields as questions.
    const heading = leafEls.find(el => /^(numeric( response)?|short answer|essay|dropdown|drop down|fill in the blank) question$/i.test(textOf(el)));
    if (!heading) return [];
    let container = heading.parentElement;
    while (container && !container.querySelector('input[type="number"],input[type="text"],textarea,select')) {
      container = container.parentElement;
    }
    if (!container || container === document.body || container === document.documentElement) return [];
    const fields = [...container.querySelectorAll('input[type="number"],input[type="text"],textarea,select')].filter(visible);
    if (!fields.length) return [];
    const qid = 'mcgraw-current-semantic';
    container.setAttribute('data-webqa-qid', qid);
    const prompt = textOf(container).replace(textOf(heading), '').replace(/rate\s+your\s+confidence.*$/i, '').trim();
    const has_visual = !!container.querySelector('img,canvas,svg,math,mjx-container');
    if (fields.length === 1 && fields[0].tagName === 'SELECT') {
      fields[0].setAttribute('data-webqa-select', qid);
      return [{qid, text: prompt, kind: 'select', has_visual,
        choices: [...fields[0].options].filter(o => !o.disabled && o.value !== '').map((o,i) => ({cid: `mcgraw-select-${i}`, text: clean(o.text), value: o.value, control_type: 'select'})),
        html_hint: 'mcgraw-dedicated-semantic'}];
    }
    if (fields.some(el => el.tagName === 'SELECT')) return [];
    const choices = fields.map((el,i) => {
      const cid = `mcgraw-input-${i}`;
      el.setAttribute('data-webqa-cid', cid);
      return {cid, text: `Blank ${i+1}`, value: el.value, control_type: 'text'};
    });
    return [{qid, text: prompt, kind: fields.length > 1 ? 'fill_blank' : 'text',
      choices, has_visual, html_hint: 'mcgraw-dedicated-semantic'}];
  }

  const typeText = textOf(typeEl);
  const typeRect = typeEl.getBoundingClientRect();

  // ---------- 2. Locate optional instruction ----------
  let instructionEl = null;

  for (const el of leafEls) {
    const r = el.getBoundingClientRect();

    if (
      r.top > typeRect.bottom &&
      r.top < typeRect.bottom + 150 &&
      r.left < window.innerWidth * 0.65 &&
      instructionRe.test(textOf(el))
    ) {
      instructionEl = el;
      break;
    }
  }

  const contentStartY = instructionEl
    ? instructionEl.getBoundingClientRect().bottom
    : typeRect.bottom;

  // Bottom of question area: help/resources, confidence area, or viewport bottom.
  let contentEndY = Infinity;

  for (const el of leafEls) {
    const t = textOf(el);
    const r = el.getBoundingClientRect();

    if (
      r.top > contentStartY && !floating(el) &&
      (
        /^need\s+help/i.test(t) ||
        /^rate\s+your\s+confidence/i.test(t)
      )
    ) {
      contentEndY = Math.min(contentEndY, r.top - 8);
    }
  }

  // ---------- 3. Locate question stem ----------
  // No requirement for a trailing '?'.
  const stemCandidates = leafEls.filter(el => {
    const t = textOf(el);
    const r = el.getBoundingClientRect();

    if (isUtility(t)) return false;
    if (r.top < contentStartY - 2) return false;
    if (r.top >= contentEndY) return false;

    // Sentence/prompt-like text.
    if (t.length < 8 || t.length > 550) return false;

    return true;
  });

  if (!stemCandidates.length) return [];

  // Find semantic controls first so their Y positions can help separate stem from choices.
  const semanticSelector = [
    'input[type="checkbox"]',
    'input[type="radio"]',
    '[role="checkbox"]',
    '[role="radio"]'
  ].join(',');

  const controlLabel = el => el.closest?.('label') || (el.id ? el.getRootNode().querySelector(`label[for="${CSS.escape(el.id)}"]`) : null);
  const controlRect = el => (rendered(el) ? el : controlLabel(el))?.getBoundingClientRect();
  let semanticControls = qsa(semanticSelector).filter(el => {
    if (!rendered(el) && !rendered(controlLabel(el))) return false;
    if (floating(el)) return false;
    const r = controlRect(el);
    return r.top > contentStartY &&
           r.top < contentEndY;
  });

  // Without semantic controls we cannot reliably distinguish options from a stem.
  if (!semanticControls.length) return [];
  let firstControlY = Infinity;
  for (const c of semanticControls) {
    firstControlY = Math.min(firstControlY, controlRect(c).top);
  }

  // Stem should normally be before first answer control.
  let likelyStems = stemCandidates.filter(el => {
    const r = el.getBoundingClientRect();
    if (el.closest('label,[role="radio"],[role="checkbox"]')) return false;
    if (el.querySelector(semanticSelector)) return false;
    if (semanticControls.some(c => controlLabel(c)?.contains(el))) return false;
    return r.bottom <= firstControlY + 2;
  });

  if (!likelyStems.length) {
    return []; // Never promote an answer choice to the question prompt.
  }

  // Prefer a sentence ending in punctuation, then closest to instruction.
  likelyStems.sort((a,b) => {
    const at = textOf(a), bt = textOf(b);
    const ar = a.getBoundingClientRect();
    const br = b.getBoundingClientRect();

    const as =
      (/[?.:]$/.test(at) ? 40 : 0) +
      (at.length >= 20 ? 10 : 0) - Math.abs(ar.left - typeRect.left) / 4 -
      Math.max(0, ar.top - contentStartY) / 8;

    const bs =
      (/[?.:]$/.test(bt) ? 40 : 0) +
      (bt.length >= 20 ? 10 : 0) - Math.abs(br.left - typeRect.left) / 4 -
      Math.max(0, br.top - contentStartY) / 8;

    return bs - as;
  });

  const stemEl = likelyStems[0];
  const stemText = textOf(stemEl);
  if (stemText.split(/\s+/).length < 3) return [];
  const stemRect = stemEl.getBoundingClientRect();

  // ---------- 4. Find a nearby container ----------
  let container = stemEl;
  let node = stemEl;

  for (let depth = 0; depth < 8 && node; depth++, node = node.parentElement) {
    if (!visible(node)) continue;

    const t = textOf(node);
    const r = node.getBoundingClientRect();

    if (
      t.includes(stemText) &&
      t.length < 10000 &&
      r.top <= typeRect.top + 30 &&
      r.bottom >= Math.min(contentEndY, stemRect.bottom + 100) &&
      r.height < window.innerHeight * 1.25
    ) {
      container = node;
      break;
    }
  }

  try {
    container.setAttribute('data-webqa-qid', 'mcgraw-current-question');
  } catch (_) {
    stemEl.setAttribute('data-webqa-qid', 'mcgraw-current-question');
    container = stemEl;
  }

  // ---------- 5. Extract choices ----------
  const choices = [];
  const seenChoiceText = new Set();
  let n = 0;

  const isBadChoice = t => {
    t = clean(t);
    if (!t || t.length > 220) return true;
    if (isUtility(t)) return true;
    if (t === stemText) return true;
    return false;
  };

  const labelFor = el => {
    if (!el) return '';

    if (el.id) {
      try {
        const root = el.getRootNode?.() || document;
        const lbl = root.querySelector?.(
          `label[for="${CSS.escape(el.id)}"]`
        );

        if (lbl && rendered(lbl)) {
          const t = tileText(lbl);
          if (t) return t;
        }
      } catch (_) {}
    }

    const aria = clean(
      el.getAttribute?.('aria-label') ||
      el.getAttribute?.('data-label') ||
      ''
    );

    if (aria) return aria;

    const wrap = el.closest?.('label');
    if (wrap && rendered(wrap)) {
      const t = tileText(wrap);
      if (t) return t;
    }

    let p = el.parentElement;

    for (let i = 0; i < 5 && p; i++, p = p.parentElement) {
      if (!rendered(p)) continue;

      const t = tileText(p);
      const r = p.getBoundingClientRect();

      if (
        t &&
        t.length <= 180 &&
        r.top >= stemRect.bottom &&
        r.top < contentEndY &&
        !isBadChoice(t)
      ) {
        return t;
      }
    }

    return '';
  };

  const addChoice = (target, text, type='custom') => {
    target = target.matches?.(semanticSelector) ? target : (target.querySelector?.(semanticSelector) || target);
    text = clean(text)
      .replace(/^[☐☑✓✔□■●○◯]\s*/, '')
      .trim();

    if (isBadChoice(text)) return;

    const key = text.toLowerCase();
    if (seenChoiceText.has(key)) return;

    seenChoiceText.add(key);

    const cid = `mcgraw-c-${++n}`;

    try {
      target.setAttribute('data-webqa-cid', cid);
    } catch (_) {}

    choices.push({
      cid,
      text,
      control_type: type,
      checked:
        target.checked === true ||
        target.getAttribute?.('aria-checked') === 'true',
      value: clean(
        target.value ||
        target.getAttribute?.('data-value') ||
        ''
      )
    });
  };

  // Re-filter semantic controls relative to the actual stem.
  semanticControls = semanticControls.filter(c => {
    const r = controlRect(c);
    return r.top > stemRect.bottom + 5 &&
           r.top < contentEndY;
  });

  for (const c of semanticControls) {
    addChoice(
      c,
      labelFor(c),
      c.getAttribute?.('role') ||
      c.getAttribute?.('type') ||
      'semantic'
    );
  }

  // Visual fallback if McGraw uses custom squares/rows.
  if (choices.length < 2) {
    const optionCandidates = leafEls.filter(el => {
      const t = tileText(el);
      const r = el.getBoundingClientRect();

      if (isBadChoice(t)) return false;
      if (r.top <= stemRect.bottom + 15) return false;
      if (r.top >= contentEndY) return false;
      if (t.length > 120) return false;

      return true;
    });

    // Cluster by row and take short option-like items.
    let lastTop = -999;

    for (const el of optionCandidates) {
      const t = tileText(el);
      const r = el.getBoundingClientRect();

      if (Math.abs(r.top - lastTop) < 5) continue;

      // Reject obvious sentence-sized support text.
      if (t.length > 90 && /[.!?]$/.test(t)) continue;

      let target = el;

      // Prefer a small row wrapper around the label.
      let p = el.parentElement;

      for (let i = 0; i < 3 && p; i++, p = p.parentElement) {
        if (!visible(p)) continue;

        const pt = tileText(p);
        const pr = p.getBoundingClientRect();

        if (
          pt === t &&
          pr.height < 90 &&
          pr.width < window.innerWidth * 0.75
        ) {
          target = p;
        }
      }

      addChoice(target, t, 'visual-option');
      lastTop = r.top;

      if (choices.length >= 10) break;
    }
  }

  // ---------- 6. Determine question type ----------
  let kind = 'single_choice';

  if (
    /multiple\s+select/i.test(typeText) ||
    instructionEl && /select\s+all\s+that\s+apply/i.test(textOf(instructionEl))
  ) {
    kind = 'multiple_choice';
  }

  const questionMedia = el => {
    if (!visible(el)) return false;
    const r = el.getBoundingClientRect();
    return el.matches('math,mjx-container') || (r.width >= 80 && r.height >= 60);
  };
  let visualParent = container;
  for (let depth = 0; depth < 5 && visualParent; depth++, visualParent = visualParent.parentElement) {
    if (visualParent === document.documentElement) break;
    const media = [...visualParent.querySelectorAll('img,canvas,svg,math,mjx-container')].filter(questionMedia);
    if (media.length && visualParent.contains(typeEl)) {
      container.removeAttribute('data-webqa-qid');
      container = visualParent;
      container.setAttribute('data-webqa-qid', 'mcgraw-current-question');
      break;
    }
  }
  const mediaKey = [...container.querySelectorAll('img,canvas,svg,math,mjx-container')]
    .filter(questionMedia).map(el => el.currentSrc || el.src || el.textContent || '').join('|');
  let mediaHash = 0;
  for (const ch of mediaKey) mediaHash = ((mediaHash * 31) + ch.charCodeAt(0)) | 0;
  const hasVisual = !!container.querySelector?.(
    'img,canvas,svg,video,math,mjx-container,' +
    '[class*="math" i],[class*="diagram" i],[class*="figure" i]'
  );

  return [{
    qid: 'mcgraw-current-question',
    text: stemText,
    kind,
    choices,
    has_visual: hasVisual,
    html_hint: 'mcgraw-dedicated-feedback-v11:' + mediaHash
  }];
}
"""

async def extract_mcgraw_question(frame):
    raw = await frame.evaluate(MCGRAW_EXTRACT_JS)
    out = []

    for q in raw:
        choices = [Choice(**c) for c in q.get("choices", [])]

        if not q.get("text"):
            continue

        out.append(
            Question(
                qid=q["qid"],
                text=q.get("text", ""),
                kind=q.get("kind", "unknown"),
                choices=choices,
                has_visual=bool(q.get("has_visual")),
                html_hint=q.get("html_hint", ""),
            )
        )

    return out


async def annotate_matching(frame, answers: list[str]):
    """
    Add non-interactive recommendation badges next to each matching target.
    Does not drag, drop, click, or submit anything.
    """
    mappings = []

    for raw in answers:
        raw = str(raw).strip()
        if not raw:
            continue

        parts = None
        for sep in ("=>", "→", "->", ":"):
            if sep in raw:
                left, right = raw.split(sep, 1)
                parts = (left.strip(), right.strip())
                break

        if parts and parts[0] and parts[1]:
            mappings.append({
                "target": parts[0],
                "answer": parts[1],
            })

    if not mappings:
        return []

    result = await frame.evaluate(
        r"""
        (mappings) => {
          const clean = s => String(s || '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();

          // Remove old badges.
          for (const el of document.querySelectorAll('[data-webqa-match-badge="1"]')) {
            el.remove();
          }

          const targets = [
            ...document.querySelectorAll('[data-webqa-match-target]')
          ];

          const applied = [];

          for (const m of mappings) {
            const wanted = clean(m.target);

            let targetEl = targets.find(el =>
              clean(el.getAttribute('data-webqa-match-target')) === wanted
            );

            // Mild containment fallback for model punctuation differences.
            if (!targetEl) {
              targetEl = targets.find(el => {
                const t = clean(el.getAttribute('data-webqa-match-target'));
                return t.includes(wanted) || wanted.includes(t);
              });
            }

            if (!targetEl) continue;

            const badge = document.createElement('span');
            badge.setAttribute('data-webqa-match-badge', '1');
            badge.textContent = `  →  ${m.answer}`;

            Object.assign(badge.style, {
              display: 'inline-block',
              marginLeft: '10px',
              padding: '4px 8px',
              borderRadius: '6px',
              background: 'rgba(20,20,24,.92)',
              color: 'white',
              font: '600 13px/1.3 system-ui, sans-serif',
              verticalAlign: 'middle',
              pointerEvents: 'none',
              zIndex: '2147483646'
            });

            // Prefer putting the badge beside a visible label in the same row.
            let anchor = targetEl;

            const r = targetEl.getBoundingClientRect();
            const candidates = [
              ...document.querySelectorAll('div,span,p,label,li,button')
            ].filter(el => {
              if (el === targetEl) return false;
              const txt = clean(el.innerText || el.textContent || '');
              if (txt !== wanted) return false;

              const er = el.getBoundingClientRect();
              const overlap =
                Math.min(er.bottom, r.bottom) - Math.max(er.top, r.top);

              return overlap > 0;
            });

            if (candidates.length) anchor = candidates[0];

            try {
              anchor.insertAdjacentElement('afterend', badge);
            } catch (_) {
              targetEl.parentElement?.appendChild(badge);
            }

            applied.push(`${m.target} => ${m.answer}`);
          }

          return applied;
        }
        """,
        mappings
    )

    return result


async def annotate_fill_blanks(frame, answers: list[str]):
    """
    Show a non-interactive recommendation badge beside each blank.
    Never types into the field or submits anything.
    """
    if not answers:
        return []

    result = await frame.evaluate(
        r"""
        (answers) => {
          const inputs = [
            ...document.querySelectorAll('[data-webqa-fill-index]')
          ].sort((a,b) =>
            Number(a.getAttribute('data-webqa-fill-index')) -
            Number(b.getAttribute('data-webqa-fill-index'))
          );

          for (const el of document.querySelectorAll('[data-webqa-fill-badge="1"]')) {
            el.remove();
          }

          const applied = [];

          inputs.forEach((input, idx) => {
            const ans = String(answers[idx] ?? '').trim();
            if (!ans) return;

            const badge = document.createElement('span');
            badge.setAttribute('data-webqa-fill-badge', '1');
            badge.textContent = `Blank ${idx + 1}: ${ans}`;

            Object.assign(badge.style, {
              display: 'inline-block',
              marginLeft: '8px',
              marginTop: '4px',
              padding: '4px 8px',
              borderRadius: '6px',
              background: 'rgba(20,20,24,.92)',
              color: 'white',
              font: '600 13px/1.3 system-ui, sans-serif',
              pointerEvents: 'none',
              verticalAlign: 'middle',
              zIndex: '2147483646'
            });

            input.insertAdjacentElement('afterend', badge);
            applied.push(`Blank ${idx + 1}: ${ans}`);
          });

          return applied;
        }
        """,
        answers
    )

    return result
