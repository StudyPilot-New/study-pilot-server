"""Advance Canvas question pages only after verifying the applied answer set."""
import re
import time
from weakref import WeakKeyDictionary
from matcher import best_choice
from learning_adapter import extract_learning_questions


async def answer_is_selected(frame, question, answers):
    if not answers:
        return False
    current=await extract_learning_questions(frame)
    if not any(q.qid==question.qid and q.text==question.text and q.kind==question.kind and
               [c.text for c in q.choices]==[c.text for c in question.choices] for q in current):return False
    root=frame.locator(f'[data-webqa-qid="{question.qid}"]')
    if await root.count()!=1:
        return False
    if question.kind in ('single_choice','multiple_choice'):
        matches=[best_choice(a,question.choices) for a in answers]
        if any(c is None for c in matches):return False
        expected={c.cid for c in matches}
        if len(expected)!=len(answers) or (question.kind=='single_choice' and len(expected)!=1):return False
        selected=await root.locator('input[type=radio],input[type=checkbox],[role=radio],[role=checkbox]').evaluate_all(
            "els=>els.filter(e=>e.checked===true||e.getAttribute('aria-checked')==='true').map(e=>e.dataset.webqaCid)")
        return set(selected)==expected
    if question.kind=='text':
        values=await root.locator('textarea,input[type=text],input[type=number],input:not([type])').evaluate_all('els=>els.map(e=>e.value.trim())')
        return values==[a.strip() for a in answers]
    if question.kind=='select' and len(answers)==1:
        choice=best_choice(answers[0],question.choices)
        selects=root.locator('select')
        return bool(choice and await selects.count()==1 and await selects.input_value()==choice.value)
    return False


class CanvasNavigation:
    def __init__(self,clock=time.monotonic):
        self.pages=WeakKeyDictionary();self.clock=clock

    def reset(self,page):
        self.pages.pop(page,None)

    def resume(self,page):
        state=self.pages.get(page)
        if state:state.update(attempts=0,clicked_at=None)

    def observe(self,page,fingerprint,pacer=None):
        # Empty intermediate screens are not proof of successful navigation.
        if not fingerprint:return
        previous=self.pages.get(page)
        if previous and previous['fingerprint']==fingerprint:return
        if previous and previous['clicked_at'] is not None and pacer is not None:pacer.submitted()
        self.pages[page]={'fingerprint':fingerprint,'answers':{},'clicked_at':None,'attempts':0}

    def remember(self,page,frame_index,question,signature,answers):
        state=self.pages.get(page)
        if state:state['answers'][(frame_index,question.qid,signature)]=list(answers)

    async def advance(self,page,found,signature,pacer=None):
        state=self.pages.get(page)
        if not state or not found:return ''
        for index,frame,q in found:
            answers=state['answers'].get((index,q.qid,signature(q)))
            if not answers:return ''
            if not await answer_is_selected(frame,q,answers):
                return 'Canvas: la selección cambió o está incompleta. Revisa la respuesta antes de continuar.'
        if state['clicked_at'] is not None:
            if self.clock()-state['clicked_at']<8:return 'Canvas: Next pulsado; esperando la siguiente pregunta.'
            if state['attempts']>=2:return 'Canvas no cambió tras pulsar Next. Pulsa Recuperar para volver a intentarlo.'
        if pacer is not None and (pacer.paused_at is not None or pacer.remaining()>0):return pacer.message()
        candidates=[]
        for frame in page.frames:
            for role in ('button','link'):
                for button in await frame.get_by_role(role,name=re.compile(r'^\s*(?:Next(?:\s+Question)?|Siguiente(?:\s+pregunta)?)\s*[▶►›»→]?\s*$',re.I)).all():
                    if await button.is_visible() and await button.is_enabled() and await button.get_attribute('aria-disabled')!='true':
                        candidates.append(button)
        if len(candidates)!=1:
            return 'Canvas: esperando un botón Next disponible y único. El envío final del cuestionario requiere revisión manual.'
        # Recheck after locating Next: never act on a new, unanswered question.
        for index,frame,q in found:
            if not await answer_is_selected(frame,q,state['answers'][(index,q.qid,signature(q))]):return ''
        state['clicked_at']=self.clock();state['attempts']+=1
        try:
            await candidates[0].click(timeout=2500)
        except Exception:
            return 'Canvas: comprobando si Next respondió antes de reintentar.'
        return 'Canvas: Next pulsado; esperando la siguiente pregunta.'
