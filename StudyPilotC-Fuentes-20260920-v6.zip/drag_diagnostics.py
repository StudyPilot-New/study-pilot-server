"""Keep the last failed interaction's controls locally, without page credentials."""
import json
from pathlib import Path


async def save_drag_diagnostic(frame, question, answers, error):
    controls = await frame.locator('[data-webqa-cid],[data-webqa-match-target]').evaluate_all('''els => els.map(el=>({
      cid:el.getAttribute('data-webqa-cid'),target:el.getAttribute('data-webqa-match-target'),
      tag:el.tagName,role:el.getAttribute('role'),label:el.getAttribute('aria-label'),
      text:(el.innerText||'').slice(0,1200),rawText:(el.textContent||'').slice(0,1200),
      draggable:el.getAttribute('draggable'),grabbed:el.getAttribute('aria-grabbed'),
      math:[...el.querySelectorAll('math')].map(m=>m.textContent.slice(0,400)),
      rect:{x:el.getBoundingClientRect().x,y:el.getBoundingClientRect().y,
            width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height}
    })).slice(0,80)''')
    report={'error':str(error),'question':question.text,'answers':answers,
        'choices':[{'cid':c.cid,'text':c.text} for c in question.choices], 'controls':controls}
    path=Path(__file__).with_name('last_drag_failure.json')
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Drag diagnostic saved: {path.name}')
