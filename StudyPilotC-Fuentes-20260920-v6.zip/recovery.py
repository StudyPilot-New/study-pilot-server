"""Recover browser interaction state without discarding learned corrections."""
import asyncio
import time
from weakref import WeakKeyDictionary

_resets=WeakKeyDictionary()


async def release_input(page):
    for action in (lambda:page.mouse.up(),lambda:page.keyboard.press('Escape')):
        try:await action()
        except Exception:pass
    try:
        await page.evaluate("() => {window.getSelection()?.removeAllRanges();}")
    except Exception:pass


async def recover_page(page,identity=None,manual=False):
    from mcgraw_actions import allowed_mcgraw,screen_state,resume_interactions
    if not allowed_mcgraw(page):return False
    await release_input(page)
    screen=await screen_state(page)
    if screen['feedback'] or screen['required']:
        # Let feedback recording/navigation finish; never resubmit by resetting it.
        return False
    record=_resets.get(page)
    if record is None or record['identity']!=identity:
        record={'identity':identity,'count':0,'last':0};_resets[page]=record
    if not manual and (record['count']>=2 or time.monotonic()-record['last']<15):return False
    record['count']+=1;record['last']=time.monotonic()
    try:
        await page.reload(wait_until='domcontentloaded',timeout=10000)
        resume_interactions(page)
        print('Recuperación: página recargada; se conserva la memoria de esta sesión.')
        return True
    except Exception:
        print('Recuperación: el navegador no confirmó la recarga; comprobando su estado.')
        return False
