"""Apply top-to-bottom ordering through the application's keyboard controls."""
import asyncio


async def current_order(frame):
    return await frame.locator('[data-webqa-order-item]').evaluate_all("""els => els
        .map(el=>({id:el.getAttribute('data-webqa-cid'),y:el.getBoundingClientRect().top}))
        .sort((a,b)=>a.y-b.y).map(x=>x.id)""")


async def apply_ordering(page, frame, question, answers, match, refresh=False):
    if len(answers) != len(question.choices):
        raise ValueError('Ordering requires every item exactly once')
    desired=[match(answer,question.choices).cid for answer in answers]
    if len(set(desired)) != len(desired):
        raise ValueError('Duplicate ordering item')
    initial=await current_order(frame)
    if set(initial) != set(desired):
        raise ValueError('Ordering controls changed; rescan required')
    async def reread():
        if not refresh:
            return desired
        from mcgraw_adapter import extract_mcgraw_question
        found=[q for q in await extract_mcgraw_question(frame) if q.kind=='ordering']
        if len(found)!=1 or found[0].text!=question.text or len(found[0].choices)!=len(answers):
            raise ValueError('Ordering question changed while moving; rescan required')
        ids=[match(answer,found[0].choices).cid for answer in answers]
        if len(set(ids))!=len(ids):
            raise ValueError('Ordering choices became ambiguous')
        return ids
    for position in range(len(desired)):
        desired=await reread()
        cid=desired[position]
        current=await current_order(frame)
        index=current.index(cid)
        if index==position: continue
        item=frame.locator('[data-webqa-cid="'+cid+'"]')
        await item.scroll_into_view_if_needed(timeout=3000)
        focused=await item.evaluate("""el=>{const s='[tabindex],button,[role="button"],[role="option"]';const n=(el.matches(s)?el:el.querySelector(s))||el.closest(s)||el;n.focus();return n.getRootNode().activeElement===n;}""")
        if focused:
            await page.keyboard.press('Space')
            await asyncio.sleep(0.2)
            try:
                for _ in range(abs(index-position)):
                    await page.keyboard.press('ArrowUp' if index>position else 'ArrowDown')
                    await asyncio.sleep(0.12)
                await page.keyboard.press('Space')
            except Exception:
                await page.keyboard.press('Escape')
        async def settled():
            nonlocal desired
            stable=0
            for _ in range(15):
                desired=await reread()
                now=await current_order(frame)
                held=await frame.locator('[aria-grabbed="true"]').count()
                if not held and now[:position+1]==desired[:position+1]:
                    stable+=1
                    if stable>=3:return True
                else:stable=0
                await asyncio.sleep(0.1)
            return False
        if not focused or not await settled():
            # Some widgets ignore keyboard pickup. Cancel any unfinished gesture,
            # reread positional IDs, then use actual mouse events on current tiles.
            await page.keyboard.press('Escape')
            desired=await reread()
            current=await current_order(frame)
            cid=desired[position]
            source=frame.locator('[data-webqa-cid="'+cid+'"]')
            target=frame.locator('[data-webqa-cid="'+current[position]+'"]')
            await source.scroll_into_view_if_needed(timeout=3000)
            start=await source.bounding_box()
            if not start:raise ValueError('Ordering source unavailable after rescan')
            x=start['x']+start['width']/2
            y=start['y']+start['height']/2
            print('  Ordering: keyboard did not persist; trying pointer movement.')
            await page.mouse.move(x,y)
            await page.mouse.down()
            try:
                await page.mouse.move(x,y-12,steps=4)
                await asyncio.sleep(0.2)
                # Scrolling the source into view can hide a distant destination.
                # Recompute its viewport coordinates during the active gesture.
                await target.scroll_into_view_if_needed(timeout=3000)
                end=await target.bounding_box()
                if not end:raise ValueError('Ordering destination unavailable after rescan')
                tx=end['x']+end['width']/2
                ty=end['y']+end['height']*(0.2 if current.index(cid)>position else 0.8)
                await page.mouse.move(tx,ty,steps=24)
                await asyncio.sleep(0.3)
            finally:
                await page.mouse.up()
            if not await settled():
                await page.keyboard.press('Escape')
                raise ValueError('Ordering movement did not persist after keyboard and pointer; submission stopped')
    if await current_order(frame)!=desired or await frame.locator('[aria-grabbed="true"]').count():
        raise ValueError('Final ordering does not match requested answer')
