"""Read an existing McGraw concept resource, then restore the active question."""
import asyncio
import time
from types import SimpleNamespace
from weakref import WeakKeyDictionary

from mcgraw_actions import allowed_mcgraw, named_control, screen_state
from mcgraw_adapter import extract_mcgraw_question
from reading_navigation import (checkpoint, return_control, fallback_return,
    finish_checkpoint, owned_popups, reader_surface, return_owned_popup)

READ_TIMEOUT = 5.0
RETURN_TIMEOUT = 0.8
POLL_INTERVAL = 0.2
READ_NAMES = ('Read About the Concept', 'Read about this concept', 'Reading')
RETURN_NAMES = ('To Questions', 'Back to Questions', 'Return to Questions',
                'Back to Question', 'Return to Question')
_pending_returns = WeakKeyDictionary()
# At most one completed, unconsumed reading per live page. Never retain history.
_completed_reads = WeakKeyDictionary()
_disabled_reads = WeakKeyDictionary()


def has_pending_return(page):
    return page in _pending_returns

RESOURCE_TEXT_JS = r"""() => {
    const roots = [...document.querySelectorAll('main,article,[role="main"]')]
      .filter(el => el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden');
    const containers = roots.length ? roots.filter(el => !roots.some(other => other !== el && other.contains(el)))
                                   : [document.body];
    const ignore = '#webqa-overlay,nav,header,footer,[role="navigation"],[role="banner"],'
      + '[role="contentinfo"],button,[role="button"],input,select,textarea,script,style,'
      + '[hidden],[aria-hidden="true"],.sr-only,.visually-hidden';
    const parts = [];
    let length = 0;
    for (const root of containers) {
      if (!root) continue;
      const walker = document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode()) && length < 12000) {
        const parent = node.parentElement;
        const value = (node.textContent || '').replace(/\s+/g,' ').trim();
        if (!value || !parent || parent.closest(ignore)) continue;
        if (/^(To Questions|Back to Questions|Return to Questions|Back to Question|Return to Question)$/i.test(value)) continue;
        const style = getComputedStyle(parent);
        if (style.visibility === 'hidden' || style.display === 'none' || style.opacity === '0') continue;
        const range = document.createRange(); range.selectNodeContents(node);
        const rect = range.getBoundingClientRect();
        if (!rect.width || !rect.height) continue;
        parts.push(value); length += value.length + 1;
      }
      if (length >= 12000) break;
    }
    return parts.join(' ').slice(0,12000);
}"""


def _clean(value):
    return ' '.join(str(value).split()).casefold()


async def _question_signature(page):
    """Use current question content, never positional DOM IDs or answer state."""
    result = []
    if not allowed_mcgraw(page):
        return ()
    for frame in page.frames:
        if not allowed_mcgraw(frame):
            continue
        try:
            for q in await extract_mcgraw_question(frame):
                choices = () if q.kind == 'fill_blank' else tuple(sorted(_clean(c.text) for c in q.choices))
                result.append((q.kind, _clean(q.text), len(q.choices), choices))
        except Exception:
            continue
    return tuple(sorted(result))


async def _resource_text(page):
    parts = []
    for frame in page.frames:
        if not allowed_mcgraw(frame):
            continue
        try:
            text = await frame.evaluate(RESOURCE_TEXT_JS)
            if text and text not in parts:
                parts.append(text)
        except Exception:
            continue
    return '\n\n'.join(parts)[:12000]


async def consume_question_resource(page):
    """Consume a delayed reading once, only for its original active question."""
    completed = _completed_reads.pop(page, None)
    if completed is None or not allowed_mcgraw(page):
        return ''
    try:
        state = await screen_state(page)
        if state['feedback'] or state['required']:
            return ''
        if completed[0] == await _question_signature(page):
            return completed[1]
    except Exception:
        pass
    return ''


async def restore_question_resource(page):
    """True means normal processing can resume; False means a return is pending.

    Safe to call at the start of every watch iteration. It never submits or moves
    to another question, and does not modify McGraw feedback/navigation state.
    """
    pending = _pending_returns.get(page)
    if pending is None:
        return True
    if not allowed_mcgraw(page):
        # A Reading link may navigate this same tab to a publisher host. The
        # checkpoint was taken on McGraw, so return only to that exact URL.
        navigation=pending.get('navigation')
        if not navigation or not allowed_mcgraw(SimpleNamespace(url=navigation.get('url',''))):
            finish_checkpoint(page,navigation)
            _pending_returns.pop(page,None)
            return True
    deadline = time.monotonic() + RETURN_TIMEOUT
    clicked = False
    while time.monotonic() < deadline:
        try:
            navigation=pending.get('navigation') or {}
            if owned_popups(navigation):
                if not await return_owned_popup(page,navigation):
                    await asyncio.sleep(POLL_INTERVAL)
                    continue
            back = await return_control(page)
            if back is None:
                signature = await _question_signature(page)
                if signature:
                    finish_checkpoint(page,navigation)
                    _pending_returns.pop(page, None)
                    if signature == pending['original'] and pending.get('context'):
                        _completed_reads[page] = (signature, pending['context'])
                    else:
                        _completed_reads.pop(page, None)
                    return True
            if back is not None and not clicked and pending.get('return_clicks',0)<2 and time.monotonic()-pending['last_click'] >= 4:
                pending['last_click'] = time.monotonic()
                pending['return_clicks']=pending.get('return_clicks',0)+1
                clicked = True
                await back.click(timeout=2500)
                navigation.update(last_return=time.monotonic(),return_requested=True,reader_seen=True)
        except Exception:
            pass
        await asyncio.sleep(POLL_INTERVAL)
    navigation=pending.get('navigation')
    # A synchronous return can complete near the end of the short polling
    # window. Confirm it once before scheduling a fallback navigation.
    if not owned_popups(navigation) and await return_control(page) is None:
        signature=await _question_signature(page)
        if signature:
            finish_checkpoint(page,navigation)
            _pending_returns.pop(page,None)
            if signature==pending['original'] and pending.get('context'):
                _completed_reads[page]=(signature,pending['context'])
            else:_completed_reads.pop(page,None)
            return True
    if navigation and await fallback_return(page,navigation):
        _disabled_reads[page]=pending['original']
    # A bounded restore must end in rescanning, not an eternal return banner.
    if navigation and navigation['reload_used'] and time.monotonic()-navigation['started']>15:
        _disabled_reads[page]=pending['original']
        finish_checkpoint(page,navigation)
        _pending_returns.pop(page,None)
        print('Reading recovery finished; rescanning the activity. Use Recuperar if the activity did not return.')
        return True
    return False


async def read_question_resource(page):
    """Return <=12k chars of reading only after returning to the same question.

    Recognized McGraw controls only. Empty means no usable resource; any
    unfinished return is resumed by restore_question_resource on the next tick.
    """
    if not allowed_mcgraw(page):
        _completed_reads.pop(page, None)
        return ''
    if not await restore_question_resource(page):
        return ''
    original = ()
    context = ''
    opened = False
    try:
        state = await screen_state(page)
        if state['feedback'] or state['required']:
            _completed_reads.pop(page, None)
            return ''
        if await named_control(page, RETURN_NAMES) is not None:
            return ''
        original = await _question_signature(page)
        if _disabled_reads.get(page)==original:return ''
        completed = _completed_reads.pop(page, None)
        if completed and original and completed[0] == original:
            return completed[1]
        if not original:
            return ''
        control = await named_control(page, READ_NAMES)
        if control is None:
            return ''
        link = await control.evaluate("el => {const a=el.closest('a');return a ? {target:a.target,href:a.href} : null}")
        if link:
            if link['href'].startswith(('http://', 'https://')):
                from types import SimpleNamespace
                if not allowed_mcgraw(SimpleNamespace(url=link['href'])):
                    return ''
        before_text = await _resource_text(page)
        _pending_returns[page] = {'original': original, 'last_click': 0.0, 'context': '',
                                 'navigation':await checkpoint(page)}
        opened = True
        await control.click(timeout=3000)
        deadline = time.monotonic() + READ_TIMEOUT
        previous = ''
        while time.monotonic() < deadline and allowed_mcgraw(page):
            surface=await reader_surface(page,_pending_returns[page]['navigation'])
            if surface is not page or await return_control(page) is not None:
                text = await _resource_text(surface)
                if len(text) >= 80 and text != before_text:
                    if text == previous:
                        context = text
                        _pending_returns[page]['context'] = text
                        break
                    previous = text
            await asyncio.sleep(POLL_INTERVAL)
    except Exception:
        context = ''
    finally:
        if opened:
            returned = await restore_question_resource(page)
            if not returned:
                context = ''
    if context and original == await _question_signature(page):
        _completed_reads.pop(page, None)
        return context
    return ''
