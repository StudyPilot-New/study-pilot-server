import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock,MagicMock,patch
import ordering
import text_alternative as alt
from mcgraw_actions import exact_choice

class Tests(unittest.IsolatedAsyncioTestCase):
    def test_formula_spacing(self):
        choices=[NS(cid='a',text='C₆H₁₂O₆'),NS(cid='b',text='C5H10O5')]
        self.assertEqual(exact_choice('C 6 H 12 O 6',choices).cid,'a')
        with self.assertRaises(ValueError):exact_choice('C6H10O6',choices)
    async def test_ordering_top_to_bottom(self):
        sequence=['a','b','c'];state={'focus':None,'held':False}
        choices=[NS(cid='a',text='Cellulose'),NS(cid='b',text='Glycogen'),NS(cid='c',text='Starch')]
        def locator(selector):
            if selector=='[aria-grabbed="true"]':
                return NS(count=AsyncMock(side_effect=lambda:int(state['held'])))
            cid=selector.split('"')[1]
            control=AsyncMock()
            def focus(*args,**kwargs):state['focus']=cid;return True
            control.evaluate.side_effect=focus
            return control
        async def press(key):
            if key=='Space':state['held']=not state['held']
            elif state['held']:
                i=sequence.index(state['focus']);item=sequence.pop(i)
                sequence.insert(i-1 if key=='ArrowUp' else i+1,item)
        page=NS(keyboard=NS(press=press));frame=NS(locator=locator)
        with patch.object(ordering,'current_order',side_effect=lambda frame:list(sequence)),patch.object(ordering.asyncio,'sleep',new=AsyncMock()):
            await ordering.apply_ordering(page,frame,NS(choices=choices),['Glycogen','Starch','Cellulose'],exact_choice)
        self.assertEqual(sequence,['b','c','a'])
    async def test_duplicate_ordering_rejected(self):
        q=NS(choices=[NS(cid='a',text='one'),NS(cid='b',text='two')])
        with self.assertRaises(ValueError):await ordering.apply_ordering(None,None,q,['one','one'],exact_choice)
    async def test_popup_about_blank_read_and_closed(self):
        callbacks={}
        link=AsyncMock();link.is_visible.return_value=True
        controls=NS(count=AsyncMock(return_value=1),nth=lambda i:link)
        popup=MagicMock();popup.url='about:blank';popup.is_closed.return_value=False
        popup.locator.return_value.inner_text=AsyncMock(return_value='On the left: three carbon atoms, one hydroxyl group. On the right: a different arrangement of the hydroxyl group on the carbon chain.')
        popup.close=AsyncMock()
        page=MagicMock();page.url='https://learning.mheducation.com/question';page.is_closed.return_value=False
        page.on.side_effect=lambda event,fn:callbacks.update({event:fn})
        page.bring_to_front=AsyncMock()
        link.click.side_effect=lambda **kwargs:callbacks['popup'](popup)
        frame=NS(url=page.url,get_by_role=lambda *args,**kwargs:controls)
        result=await alt.read_text_alternative(page,frame)
        self.assertIn('hydroxyl',result)
        popup.close.assert_awaited_once();page.bring_to_front.assert_awaited_once()
        page.remove_listener.assert_called_once()

if __name__=='__main__':unittest.main()
