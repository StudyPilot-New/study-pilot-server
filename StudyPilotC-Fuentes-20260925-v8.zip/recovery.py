"""Recover browser interaction state without discarding learned corrections."""
import asyncio
import time
from weakref import WeakKeyDictionary

_resets=WeakKeyDictionary()
RELOAD_WINDOW=300
MAX_RELOADS=2
RECOVERY_COOLDOWN=15


async def release_input(page):
    for action in (lambda:page.mouse.up(),lambda:page.keyboard.press('Escape')):
        try:await action()
        except Exception:pass
    try:
        await page.evaluate("() => {window.getSelection()?.removeAllRanges();}")
    except Exception:pass


async def recover_page(page,identity=None,manual=False):
    from mcgraw_actions import allowed_mcgraw,screen_state,resume_interactions
    if not allowed_mcgraw(page):return False
    screen=await screen_state(page)
    if screen['feedback'] or screen['required']:
        # Let feedback recording/navigation finish; never resubmit by resetting it.
        return False
    record=_resets.get(page)
    now=time.monotonic()
    # The reload budget belongs to the page, not the changing tile identities.
    # Moving a choice or replacing an iframe must not reset this protection.
    if record is None:
        record={'identity':identity,'count':0,'last':float('-inf'),'window':now};_resets[page]=record
    if not manual and now-record['last']<RECOVERY_COOLDOWN:return False
    if now-record.get('window',now)>=RELOAD_WINDOW:
        record.update(count=0,window=now)
    record.update(identity=identity,last=now)
    await release_input(page)
    if not manual and record['count']>=MAX_RELOADS:
        # Re-arm the gestures without flashing/reloading the whole document.
        # A per-question failure cap used to leave the session blocked forever.
        resume_interactions(page)
        print('Recuperación: controles liberados; nuevo intento sin recargar la página.')
        return True
    record['count']+=1
    try:
        await page.reload(wait_until='domcontentloaded',timeout=10000)
        resume_interactions(page)
        print('Recuperación: página recargada; se conserva la memoria de esta sesión.')
        return True
    except Exception:
        print('Recuperación: el navegador no confirmó la recarga; comprobando su estado.')
        return False
