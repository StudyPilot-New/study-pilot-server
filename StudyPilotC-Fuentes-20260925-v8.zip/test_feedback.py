import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch
import mcgraw_actions as a

class Page:
    url='https://learning.mheducation.com/recharge'
    frames=[]

class Tests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.page=Page()
        self.screen={'feedback':True,'required':False,'textLength':500}
        self.reader=AsyncMock(return_value=self.screen)
        self.screen_patch=patch.object(a,'screen_state',self.reader)
        self.screen_patch.start()
    def tearDown(self): self.screen_patch.stop()
    def expire(self):a._feedback_navigation[self.page]['last']-=3
    async def test_next_without_pending_submission(self):
        button=AsyncMock()
        with patch.object(a,'named_control',return_value=button):
            status=await a.handle_feedback(self.page)
            self.assertIn('Next Question clicked',status)
            await a.handle_feedback(self.page)
        self.assertEqual(button.click.await_count,1)
    async def test_new_question_releases_feedback_state(self):
        with patch.object(a,'named_control',return_value=AsyncMock()):
            await a.handle_feedback(self.page)
        self.expire();self.screen.update(feedback=False)
        self.assertEqual(await a.handle_feedback(self.page),'')
    async def test_required_reading_then_return_then_next(self):
        self.screen['required']=True
        review,back,next_button=AsyncMock(),AsyncMock(),AsyncMock()
        with patch.object(a,'named_control',return_value=review):
            self.assertIn('opening',await a.handle_feedback(self.page))
        self.expire();self.screen.update(feedback=False,required=False)
        with patch.object(a,'named_control',return_value=back):
            self.assertIn('returning',await a.handle_feedback(self.page))
        self.expire();self.screen.update(feedback=True)
        with patch.object(a,'named_control',return_value=next_button):
            self.assertIn('Next Question clicked',await a.handle_feedback(self.page))
        self.assertEqual([b.click.await_count for b in (review,back,next_button)],[1,1,1])
    async def test_reading_not_loaded_does_not_return(self):
        self.screen['required']=True
        with patch.object(a,'named_control',return_value=AsyncMock()):await a.handle_feedback(self.page)
        self.expire();self.screen['textLength']=0
        back=AsyncMock()
        with patch.object(a,'named_control',side_effect=[back,None]):await a.handle_feedback(self.page)
        back.click.assert_not_awaited()
    async def test_unknown_resource_reports_block(self):
        self.screen['required']=True
        with patch.object(a,'named_control',return_value=None):
            self.assertIn('no recognized',await a.handle_feedback(self.page))
    async def test_active_question_not_treated_as_feedback(self):
        self.screen.update(feedback=False,required=False)
        self.assertEqual(await a.handle_feedback(self.page),'')

    async def test_specific_reading_link_wins_over_other_visible_links(self):
        controls={name:AsyncMock() for name in ('Read About the Concept','review a resource','Reading')}
        for c in controls.values():
            c.is_visible.return_value=True;c.is_enabled.return_value=True
        class Collection:
            def __init__(self,items):self.items=items
            async def count(self):return len(self.items)
            def nth(self,i):return self.items[i]
        frame=NS(url=self.page.url,get_by_role=lambda role,name:Collection([c for n,c in controls.items() if role=='link' and name.fullmatch(n)]))
        self.page.frames=[frame]
        found=await a.named_control(self.page,('Read About the Concept','review a resource','Reading'))
        self.assertIs(found,controls['Read About the Concept'])

if __name__=='__main__':unittest.main()
