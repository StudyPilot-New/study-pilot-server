"""Advance Canvas question pages only after verifying the applied answer set."""
import re
import time
from weakref import WeakKeyDictionary
from matcher import best_choice
from learning_adapter import extract_learning_questions


async def current_question(frame, question):
    current=await extract_learning_questions(frame)
    matches=[q for q in current if q.qid==question.qid and q.text==question.text and q.kind==question.kind and
             [c.text for c in q.choices]==[c.text for c in question.choices]]
    if len(matches)!=1:return None
    fresh=matches[0]
    if '|figure:' in question.html_hint:
        from visual_capture import enrich_visual_identity
        await enrich_visual_identity(frame,fresh)
        if fresh.html_hint!=question.html_hint:return None
    return fresh


def expected_choices(question,answers):
    matches=[best_choice(a,question.choices) for a in answers]
    if not matches or any(c is None for c in matches):return None
    expected={c.cid for c in matches}
    if len(expected)!=len(answers) or (question.kind=='single_choice' and len(expected)!=1):return None
    return expected


async def answer_is_selected(frame, question, answers):
    if not answers:return False
    fresh=await current_question(frame,question)
    if fresh is None:return False
    root=frame.locator(f'[data-webqa-qid="{fresh.qid}"]')
    if await root.count()!=1:return False
    if fresh.kind in ('single_choice','multiple_choice'):
        expected=expected_choices(fresh,answers)
        # Only controls belonging to the extracted live answer set count.
        # Hidden checked templates and question flags are not answers.
        return expected is not None and {c.cid for c in fresh.choices if c.checked}==expected
    if fresh.kind=='text':
        values=await root.locator('textarea[data-webqa-cid],input[data-webqa-cid]').evaluate_all('els=>els.map(e=>e.value.trim())')
        return values==[a.strip() for a in answers]
    if fresh.kind=='select' and len(answers)==1:
        choice=best_choice(answers[0],fresh.choices)
        selects=root.locator('select[data-webqa-cid]')
        return bool(choice and await selects.count()==1 and await selects.input_value()==choice.value)
    return False


async def restore_answer(frame,question,answers):
    fresh=await current_question(frame,question)
    if fresh is None:return False
    root=frame.locator(f'[data-webqa-qid="{fresh.qid}"]')
    if fresh.kind in ('single_choice','multiple_choice'):
        expected=expected_choices(fresh,answers)
        if expected is None:return False
        for choice in fresh.choices:
            wanted=choice.cid in expected
            if choice.checked==wanted:continue
            control=root.locator(f'[data-webqa-cid="{choice.cid}"]')
            if fresh.kind=='multiple_choice':
                await control.set_checked(wanted,timeout=1500)
            elif wanted:
                await control.check(timeout=1500)
    elif fresh.kind=='text':
        fields=root.locator('textarea[data-webqa-cid],input[data-webqa-cid]')
        if await fields.count()!=len(answers):return False
        for i,answer in enumerate(answers):await fields.nth(i).fill(answer,timeout=1500)
    elif fresh.kind=='select' and len(answers)==1:
        choice=best_choice(answers[0],fresh.choices)
        if choice is None:return False
        await root.locator('select[data-webqa-cid]').select_option(value=choice.value,timeout=1500)
    else:return False
    return await answer_is_selected(frame,question,answers)


class CanvasNavigation:
    def __init__(self,clock=time.monotonic):
        self.pages=WeakKeyDictionary();self.clock=clock

    def reset(self,page):
        self.pages.pop(page,None)

    def resume(self,page):
        state=self.pages.get(page)
        if state:state.update(attempts=0,clicked_at=None)

    def observe(self,page,fingerprint,pacer=None):
        # Empty intermediate screens are not proof of successful navigation.
        if not fingerprint:return
        previous=self.pages.get(page)
        if previous and previous['fingerprint']==fingerprint:return
        if previous and previous['clicked_at'] is not None and pacer is not None:pacer.submitted()
        self.pages[page]={'fingerprint':fingerprint,'answers':{},'clicked_at':None,'attempts':0,'repairs':{}}

    def remember(self,page,frame_index,question,signature,answers):
        state=self.pages.get(page)
        if state:state['answers'][(frame_index,question.qid,signature)]=list(answers)

    async def advance(self,page,found,signature,pacer=None):
        state=self.pages.get(page)
        if not state or not found:return ''
        if pacer is not None and pacer.paused_at is not None:return pacer.message()
        # Give an in-flight Next time to finish before inspecting old controls.
        if state['clicked_at'] is not None:
            if self.clock()-state['clicked_at']<8:return 'Canvas: Next pulsado; esperando la siguiente pregunta.'
            if state['attempts']>=2:return 'Canvas no cambió tras pulsar Next. Pulsa Recuperar para volver a intentarlo.'
        for index,frame,q in found:
            key=(index,q.qid,signature(q))
            answers=state['answers'].get(key)
            if not answers:return ''
            if not await answer_is_selected(frame,q,answers):
                if await current_question(frame,q) is None:
                    return 'Canvas: la pregunta está cambiando; volviendo a detectar sus controles.'
                repair=state['repairs'].setdefault(key,{'attempts':0,'after':0})
                if self.clock()<repair['after']:
                    return 'Canvas: esperando que se estabilice la selección para reintentar automáticamente.'
                repair['attempts']+=1
                repair['after']=self.clock()+min(10,2**min(repair['attempts']-1,4))
                try:
                    restored=await restore_answer(frame,q,answers)
                except Exception:
                    restored=False
                if restored:return 'Canvas: selección restablecida; verificando antes de continuar.'
                return 'Canvas: recuperando la selección automáticamente, sin volver a consultar la IA.'
            state['repairs'].pop(key,None)
        if pacer is not None and (pacer.paused_at is not None or pacer.remaining()>0):return pacer.message()
        candidates=[]
        for frame in page.frames:
            for role in ('button','link'):
                for button in await frame.get_by_role(role,name=re.compile(r'^\s*(?:Next(?:\s+Question)?|Siguiente(?:\s+pregunta)?)\s*[▶►›»→]?\s*$',re.I)).all():
                    if await button.is_visible() and await button.is_enabled() and await button.get_attribute('aria-disabled')!='true':
                        candidates.append(button)
        if len(candidates)!=1:
            return 'Canvas: esperando un botón Next disponible y único. El envío final del cuestionario requiere revisión manual.'
        # Recheck after locating Next: never act on a new, unanswered question.
        for index,frame,q in found:
            if not await answer_is_selected(frame,q,state['answers'][(index,q.qid,signature(q))]):return ''
        state['clicked_at']=self.clock();state['attempts']+=1
        try:
            await candidates[0].click(timeout=2500)
        except Exception:
            return 'Canvas: comprobando si Next respondió antes de reintentar.'
        return 'Canvas: Next pulsado; esperando la siguiente pregunta.'
