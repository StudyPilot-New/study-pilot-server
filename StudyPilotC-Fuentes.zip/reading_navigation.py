"""Bounded return to the exact page from which this app opened Reading."""
import time
from weakref import WeakKeyDictionary

_popup_owners=WeakKeyDictionary()
_orphan_readers=WeakKeyDictionary()

RETURN_NAMES=('To Questions','Back to Questions','Return to Questions','Back to Question',
              'Return to Question','Back to assignment','Return to assignment',
              'Back to activity','Return to activity','Back to practice','Back')


async def checkpoint(page):
    state={'url':page.url,'started':time.monotonic(),'back_used':False,'reload_used':False}
    try: state['history']=await page.evaluate('history.length')
    except Exception: state['history']=0
    state['frames']=[]
    for frame in page.frames:
        if frame is getattr(page,'main_frame',None):continue
        try:state['frames'].append({'frame':frame,'url':frame.url,'history':await frame.evaluate('history.length')})
        except Exception:pass
    # Only popups explicitly opened by this page after its Reading click belong
    # to this return. Never select/close arbitrary context pages.
    state['popups']=[]
    state['capture_until']=time.monotonic()+5
    def opened(popup):
        if time.monotonic()>state['capture_until']:return
        state['popups'].append(popup)
        _popup_owners[popup]=page
    try:
        page.on('popup',opened)
        state['popup_listener']=opened
    except Exception:pass
    return state


def finish_checkpoint(page,state):
    listener=(state or {}).pop('popup_listener',None)
    if listener:
        try:page.remove_listener('popup',listener)
        except Exception:pass


def owned_popups(state):
    result=[]
    for popup in (state or {}).get('popups',[]):
        try:
            if not popup.is_closed():result.append(popup)
        except Exception:pass
    return result


def reading_owner(page):
    owner=_popup_owners.get(page)
    try:
        if owner is not None and not owner.is_closed():return owner
    except Exception:pass
    return page


async def reader_surface(page,state):
    from mcgraw_actions import allowed_mcgraw
    for popup in reversed(owned_popups(state)):
        if allowed_mcgraw(popup):return popup
    return page


async def return_owned_popup(page,state):
    """Return from a resource popup without touching pre-existing tabs."""
    popups=owned_popups(state)
    if not popups:return False
    for popup in popups:
        # The Reading link may open a publisher-hosted resource. Its ownership
        # comes from the popup event, not its URL; otherwise an external book
        # remains open forever and prevents every return fallback.
        try:
            text_length=await popup.evaluate('document.body?.innerText?.trim().length || 0')
        except Exception:text_length=0
        if text_length<80 and time.monotonic()-state['started']<10:continue
        await popup.close()
        state['reader_seen']=True
        state['return_requested']=True
    if owned_popups(state):return False
    try:await page.bring_to_front()
    except Exception:pass
    return True


async def returned_to_activity(page,state):
    """Require visible activity evidence after an actual return attempt."""
    from mcgraw_actions import screen_state
    if not state or not state.get('return_requested') or owned_popups(state):return False
    screen=await screen_state(page)
    if screen['feedback'] or screen['required']:return True
    from question_resources import _question_signature
    if await _question_signature(page):return True
    return False


async def return_control(page):
    from mcgraw_actions import named_control,allowed_mcgraw
    result=await named_control(page,RETURN_NAMES)
    if result is not None:return result
    # Icon-only return controls sometimes have a title but no accessible name.
    matches=[]
    for frame in page.frames:
        if not allowed_mcgraw(frame):continue
        controls=frame.locator('button[title],a[title],[role="button"][title]')
        for i in range(await controls.count()):
            item=controls.nth(i)
            title=(await item.get_attribute('title') or '').strip().casefold()
            if title in {s.casefold() for s in RETURN_NAMES} and await item.is_visible() and await item.is_enabled():
                matches.append(item)
    return matches[0] if len(matches)==1 else None


async def reader_view(page):
    """Recognize Recharge's full-page concept book, not a blank quiz transition."""
    from mcgraw_actions import allowed_mcgraw
    if not allowed_mcgraw(page) or '/static/awd/' not in page.url.lower():return False
    script="""() => {
      const text=(document.body?.innerText||'').replace(/\\s+/g,' ');
      return /\\bchapter\\s+\\d+\\b/i.test(text) && /\\bpage\\s+\\d+\\b/i.test(text);
    }"""
    for frame in page.frames:
        if not allowed_mcgraw(frame):continue
        try:
            if await frame.evaluate(script):return True
        except Exception:pass
    return False


async def recover_orphan_reader(page):
    """Return from a reader even when its original checkpoint is unavailable."""
    if not await reader_view(page):
        _orphan_readers.pop(page,None)
        return ''
    now=time.monotonic()
    state=_orphan_readers.get(page)
    if state is None:
        state={'started':now,'last':float('-inf'),'control_clicks':0,
               'history_used':False,'soft_used':False,'reload_attempts':0}
        _orphan_readers[page]=state
    if now-state['last']<3:
        return 'McGraw: esperando que termine el regreso desde el libro.'
    if state['control_clicks']<2:
        control=await return_control(page)
        if control is not None:
            state['control_clicks']+=1;state['last']=now
            try:
                await control.click(timeout=2500)
                return 'McGraw: regresando del libro a la pregunta.'
            except Exception:pass
    if not state['history_used'] and now-state['started']>=3:
        state['history_used']=True
        try:
            if await page.evaluate('history.length')>1:
                await page.go_back(wait_until='domcontentloaded',timeout=6000)
                state['last']=now
                return 'McGraw: recuperando la pregunta con el historial del libro.'
        except Exception:pass
    elapsed=now-state['started']
    if elapsed>=10 and not state['soft_used']:
        state['soft_used']=True;state['last']=now
        from recovery import recover_page
        await recover_page(page,('orphan-reader',page.url))
        return 'McGraw: liberando el lector y comprobando la pregunta.'
    if elapsed>=25 and state['reload_attempts']<2 and now-state['last']>=15:
        state['reload_attempts']+=1;state['last']=now
        from recovery import recover_page
        await recover_page(page,('orphan-reader',page.url))
        return 'McGraw: reintentando la recuperación controlada del libro.'
    if elapsed>=55:
        return ('McGraw: el libro sigue abierto tras los intentos de regreso. '
                'Usa Recuperar o vuelve a la pregunta; se continuará al detectar sus controles.')
    return 'McGraw: libro detectado; buscando un regreso seguro a la pregunta.'


async def fallback_return(page,state):
    """Try history once, then the captured URL once, waiting for delayed returns."""
    from mcgraw_actions import allowed_mcgraw
    from types import SimpleNamespace
    if not state or not allowed_mcgraw(SimpleNamespace(url=state.get('url',''))):return False
    elapsed=time.monotonic()-state['started']
    if elapsed<3:return False
    now=time.monotonic()
    # A delayed Back handler often leaves the old Reading DOM on screen briefly.
    # Let it settle before any history/URL fallback; otherwise the page flashes.
    if now-state.get('last_return',float('-inf'))<4:return False
    if await return_owned_popup(page,state):return True
    if owned_popups(state):return False
    for origin in state.get('frames',[]):
        frame=origin['frame']
        try:
            if frame.is_detached():continue
            history=await frame.evaluate('history.length')
            if frame.url==origin['url'] and history<=origin['history']:continue
            if not allowed_mcgraw(SimpleNamespace(url=origin['url'])):continue
            if not origin.get('back_used'):
                origin['back_used']=True
                if history>origin['history']:
                    await frame.evaluate('history.back()')
                    state.update(last_return=now,return_requested=True)
                    return True
            if not origin.get('reload_used'):
                origin['reload_used']=True
                await frame.goto(origin['url'],wait_until='domcontentloaded',timeout=5000)
                state.update(last_return=now,return_requested=True)
                return True
        except Exception:pass
    if not state['back_used']:
        state['back_used']=True
        try:
            if await page.evaluate('history.length')>state.get('history',0):
                await page.go_back(wait_until='domcontentloaded',timeout=8000)
                state.update(last_return=now,return_requested=True)
                return True
        except Exception:pass
    if elapsed>=6 and not state['reload_used']:
        state['reload_used']=True
        try:
            await page.goto(state['url'],wait_until='domcontentloaded',timeout=8000)
            state.update(last_return=now,return_requested=True)
            return True
        except Exception:pass
    return False
