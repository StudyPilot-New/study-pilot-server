import unittest
from dataclasses import replace
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock,patch
from playwright.async_api import async_playwright
import app
from mcgraw_adapter import extract_mcgraw_question
from models import Question,Choice
from session_guard import session_expired,incomplete_blank_prompt

class Incident(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page(viewport={'width':1200,'height':900})
        await self.page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body='<main></main>'))
        await self.page.goto('https://learning.mheducation.com/fixture')

    async def asyncTearDown(self):
        await self.browser.close();await self.pw.stop()

    async def test_expired_session_blocks_ai_feedback_and_resource_navigation(self):
        await self.page.set_content('<main><h1>Fill in the Blank Question</h1><p>The three levels at which metabolic pathways are regulated</p><div><input> regulation, <input> regulation, <input> regulation.</div></main><div role="dialog" style="position:fixed;inset:30%;background:white"><h2>Session expired</h2><p>Due to inactivity, you have been logged out.</p><button>Exit Recharge</button></div>')
        self.assertTrue(await session_expired(self.page))
        with patch.object(app,'collect_questions_from_frames',AsyncMock()) as collect,patch.object(app,'handle_feedback',AsyncMock()) as feedback,patch('question_resources.restore_question_resource',AsyncMock()) as restore,patch.object(app,'update_overlay',AsyncMock()) as overlay:
            for _ in range(4): self.assertEqual(await app.analyze_page(self.page,NS(),{}),0)
            collect.assert_not_awaited();feedback.assert_not_awaited();restore.assert_not_awaited()
            self.assertIn('Sesion expirada',overlay.call_args.args[2])
        await self.page.locator('[role=dialog]').evaluate('(e)=>e.style.display="none"')
        self.assertFalse(await session_expired(self.page))

    async def test_exit_assignment_dialog_is_detected_and_never_reloaded(self):
        import recovery
        await self.page.set_content('<div role="dialog"><h2>Session expired</h2><p>Due to inactivity, you have been logged out.</p><button>Exit Assignment</button></div>')
        self.assertTrue(await session_expired(self.page))
        with patch.object(self.page,'reload',AsyncMock()) as reload,patch.object(app,'update_overlay',AsyncMock()) as overlay:
            self.assertEqual(await app.analyze_page(self.page,NS(),{}),0)
            self.assertFalse(await recovery.recover_page(self.page,manual=True))
            reload.assert_not_awaited()
            self.assertIn('Sesion expirada',overlay.call_args.args[2])

    async def test_parser_includes_stem_before_label_only_container(self):
        await self.page.set_content('''<main><h1>Fill in the Blank Question</h1>
          <p>The three levels at which metabolic pathways are regulated</p>
          <div style="margin-top:15px"><input> regulation, <input> regulation, <input> regulation.</div>
          <p>Rate your confidence to submit your answer</p><button>High</button></main>''')
        question=(await extract_mcgraw_question(self.page.main_frame))[0]
        self.assertIn('three levels at which metabolic pathways are regulated',question.text)
        self.assertEqual(len(question.choices),3)
        self.assertEqual(question.text.count('[Blank '),3)
        self.assertNotIn('Rate your confidence',question.text)
        self.assertFalse(incomplete_blank_prompt(question))

    async def test_fragment_does_not_call_ai_even_after_260_scans(self):
        q=Question('q','[Blank 1] regulation, [Blank 2] regulation, [Blank 3] regulation.','fill_blank',[Choice(str(i),'','text') for i in range(3)])
        self.assertTrue(incomplete_blank_prompt(q))
        with patch.object(app,'settings',replace(app.settings,mode='assist')),patch.object(app,'identify_site',AsyncMock(return_value=('McGraw Hill',True))),patch('question_resources.restore_question_resource',AsyncMock(return_value=True)),patch.object(app,'collect_questions_from_frames',AsyncMock(return_value=[(0,self.page.main_frame,q)])),patch.object(app,'solve_with_visual_evidence',AsyncMock()) as solve,patch.object(app,'update_overlay',AsyncMock()):
            for _ in range(260):await app.analyze_page(self.page,NS(),{})
            solve.assert_not_awaited()

    async def test_low_confidence_without_book_gets_bounded_independent_review(self):
        q=Question('q','Choose the correct option for this complete practice question.','single_choice',[Choice('a','First','radio')])
        answer=NS(answers=['First'],confidence=0,explanation='',answer_type='single_choice')
        with patch.object(app,'settings',replace(app.settings,mode='fill',mcgraw_auto=True,pacing_minutes=0,use_vision='never')),patch.object(app,'identify_site',AsyncMock(return_value=('McGraw Hill',True))),patch('question_resources.restore_question_resource',AsyncMock(return_value=True)),patch('question_resources.read_question_resource',AsyncMock(return_value='')),patch('question_resources.consume_question_resource',AsyncMock(return_value='')),patch.object(app,'collect_questions_from_frames',AsyncMock(return_value=[(0,self.page.main_frame,q)])),patch.object(app,'has_text_alternative',AsyncMock(return_value=False)),patch.object(app,'solve_with_visual_evidence',AsyncMock(return_value=(answer,''))) as solve,patch.object(app,'update_overlay',AsyncMock()):
            seen={};await app.analyze_page(self.page,NS(),seen)
            for _ in range(10):
                for state in app._solve_retries[self.page].values():state['at']=0
                await app.analyze_page(self.page,NS(),seen)
            self.assertEqual(solve.await_count,3)
            self.assertEqual(solve.await_args_list[1].kwargs['recovery_attempt'],1)
            self.assertTrue(next(iter(app._solve_retries[self.page].values()))['blocked'])

    async def test_reauthenticated_same_question_does_not_keep_old_block(self):
        q=Question('q','Choose the correct option for this complete practice question.','single_choice',[Choice('a','First','radio')])
        app._expired_pages[self.page]=True
        app._question_epochs[self.page]=((0,q.qid,app.signature(q)),)
        app._solve_retries[self.page]={'0:q':{'blocked':True,'message':'old'}}
        seen={'0:q':app.signature(q)}
        answer=NS(answers=['First'],confidence=0,explanation='',answer_type='single_choice')
        with patch.object(app,'settings',replace(app.settings,mode='assist',use_vision='never')),patch.object(app,'identify_site',AsyncMock(return_value=('McGraw Hill',True))),patch.object(app,'collect_questions_from_frames',AsyncMock(return_value=[(0,self.page.main_frame,q)])),patch.object(app,'has_text_alternative',AsyncMock(return_value=False)),patch.object(app,'solve_with_visual_evidence',AsyncMock(return_value=(answer,''))) as solve,patch.object(app,'update_overlay',AsyncMock()):
            await app.analyze_page(self.page,NS(),seen)
            solve.assert_awaited_once()
            self.assertNotIn(self.page,app._solve_retries)

class Limits(unittest.TestCase):
    def test_schedule_stops_instead_of_260th_automatic_review(self):
        class Page: pass
        page=Page()
        for _ in range(260):app.schedule_answer_recovery(page,'q',NS(answers=[]))
        self.assertTrue(app._solve_retries[page]['q']['blocked'])
        self.assertNotIn('Revision automatica',app._solve_retries[page]['q']['message'])
