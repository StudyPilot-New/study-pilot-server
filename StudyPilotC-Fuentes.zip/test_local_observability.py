import asyncio,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch, AsyncMock
from local_diagnostics import Diagnostics
from operation_control import supervised_cycle

class Logs(unittest.TestCase):
    def test_incident_survives_fast_healthy_polling_and_api_type_is_exported(self):
        with tempfile.TemporaryDirectory() as d:
            log=Diagnostics(Path(d)/'logs')
            auth_error=type('AuthenticationError',(Exception,),{})('never export private token')
            log.event('analysis','error',error=auth_error)
            log.event('analysis','review_exhausted')
            for _ in range(2000):
                log.event('cycle','start');log.event('analysis','start');log.event('cycle','complete')
            log.event('session','session_expired')
            export=Path(d)/'export.json';log.export(export)
            rows=json.loads(export.read_text())['events']
            self.assertLess(len(rows),10)
            self.assertTrue(any(row['error_type']=='AuthenticationError' for row in rows))
            self.assertTrue(any(row['event']=='session_expired' for row in rows))
            self.assertNotIn('private token',export.read_text())

    def test_privacy_rotation_and_export(self):
        with tempfile.TemporaryDirectory() as d:
            log=Diagnostics(Path(d)/'logs',limit=1024)
            secret='private question answer spc_fake https://private.invalid'
            for _ in range(100): log.event('analysis','error',.1,ValueError(secret))
            self.assertFalse(log.event(secret,'error'))
            files=list(log.directory.glob('*'))
            self.assertLessEqual(len(files),3)
            self.assertTrue(all(p.stat().st_size<=1024 for p in files))
            self.assertNotIn(secret,''.join(p.read_text() for p in files))
            export=Path(d)/'export.json';log.export(export)
            self.assertTrue(json.loads(export.read_text())['events'])
            self.assertNotIn(secret,export.read_text())
            with self.assertRaises(FileExistsError):log.export(export)

    def test_unwritable_logging_does_not_interrupt_session(self):
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/'file';file.write_text('x')
            self.assertFalse(Diagnostics(file).event('cycle','start'))

class Controls(unittest.IsolatedAsyncioTestCase):
    async def test_real_cycle_stop_releases_input_without_reload_or_resubmission(self):
        import app,recovery
        class Page: pass
        page=Page();entered=asyncio.Event();control_events=[]
        async def blocked(*args):
            entered.set();await asyncio.Event().wait()
        with tempfile.TemporaryDirectory() as d:
            control=Path(d)/'control';control.write_text('run')
            with patch.object(app,'choose_target_page',AsyncMock(return_value=page)),patch.object(app,'analyze_page',blocked),patch.object(recovery,'release_input',AsyncMock()) as release,patch.object(recovery,'recover_page',AsyncMock()) as reset,patch('local_diagnostics._instance',Diagnostics(Path(d)/'logs')):
                task=asyncio.create_task(supervised_cycle(app.watch_cycle(object(),object(),{}),control,lambda e,t:control_events.append(e),interval=.005))
                await entered.wait();control.write_text('stop')
                self.assertIsNone(await asyncio.wait_for(task,.5))
                release.assert_awaited_once_with(page);reset.assert_not_awaited()
                self.assertEqual(control_events,['stop_requested','cancelled'])

    async def test_stop_cancels_and_waits_for_cleanup_without_retry(self):
        with tempfile.TemporaryDirectory() as d:
            control=Path(d)/'control';control.write_text('stop');events=[];calls=[]
            async def blocked():
                calls.append('start')
                try: await asyncio.Event().wait()
                finally: await asyncio.sleep(.005);calls.append('cleaned')
            result=await asyncio.wait_for(supervised_cycle(blocked(),control,lambda e,t:events.append(e),interval=.005),.3)
            self.assertIsNone(result);self.assertEqual(calls,['start','cleaned'])
            self.assertEqual(events,['stop_requested','cancelled'])

    async def test_pause_waits_for_safe_boundary_and_reports_slow_work(self):
        with tempfile.TemporaryDirectory() as d:
            control=Path(d)/'control';control.write_text('pause');events=[]
            async def slow(): await asyncio.sleep(.04);return 7
            self.assertEqual(await supervised_cycle(slow(),control,lambda e,t:events.append(e),interval=.005,notice_after=.01),7)
            self.assertEqual(events.count('pause_pending'),1);self.assertIn('waiting',events)
            self.assertNotIn('cancelled',events)

    async def test_external_cancel_leaves_no_orphan_operation(self):
        entered=asyncio.Event();cleaned=asyncio.Event()
        async def blocked():
            entered.set()
            try: await asyncio.Event().wait()
            finally: cleaned.set()
        task=asyncio.create_task(supervised_cycle(blocked(),None,lambda *a:None,interval=.005))
        await entered.wait();task.cancel()
        with self.assertRaises(asyncio.CancelledError):await task
        self.assertTrue(cleaned.is_set())
