"""Conservative adapter for semantic LMS question controls, not vendor internals."""
from models import Choice,Question

EXTRACT = r'''() => {
 const visible=e=>!!e && getComputedStyle(e).visibility!=='hidden' && e.getClientRects().length>0;
 const clean=s=>(s||'').replace(/\s+/g,' ').trim();
 const choiceType=e=>['radio','checkbox'].includes(e.type)?e.type:e.getAttribute('role');
 const labelledText=e=>clean((e.getAttribute('aria-labelledby')||'').split(/\s+/)
   .map(id=>document.getElementById(id)).filter(Boolean).map(label=>label.innerText||label.textContent||'').join(' '));
 const questionSelector='.question,.que,.quiz-item,.quiz-question,.question-container,[data-question-id],[data-testid="question"],[data-testid="quiz-question"],[data-testid="question-container"]';
 const controls='input[type=radio],input[type=checkbox],[role=radio],[role=checkbox],input[type=text],input[type=number],textarea,select';
 const roots=[...document.querySelectorAll(questionSelector+',fieldset')]
   .filter(e=>visible(e)&&!e.closest('#webqa-overlay')&&!e.querySelector('input[type=password],input[type=email]'));
 // Canvas nests the choices in a fieldset whose legend is only a utility label.
 // Keep the enclosing question so its sibling prompt and images are retained.
 const questions=roots.filter(e=>e.matches(questionSelector)&&e.querySelector(controls))
   .filter(e=>e.querySelectorAll('.question,.que,[data-question-id],[data-testid="question"]').length<2);
 const containers=[...questions.filter(e=>!questions.some(other=>other!==e&&other.contains(e))),
   ...roots.filter(e=>e.tagName==='FIELDSET'&&!questions.some(q=>q.contains(e))&&
     !roots.some(other=>other!==e&&other.tagName==='FIELDSET'&&e.contains(other)))];
 const utility=s=>/^(?:group of answer choices|answer choices|answers|question\s*\d+\s*(?:\d+\s*pts?)?)\s*[:.]?$/i.test(clean(s));
 document.querySelectorAll('[data-webqa-qid^="learning-"]').forEach(e=>e.removeAttribute('data-webqa-qid'));
 document.querySelectorAll('[data-webqa-cid^="learning-"]').forEach(e=>e.removeAttribute('data-webqa-cid'));
 const extracted=containers.map((root,index)=>{
   const candidates=[...root.querySelectorAll(controls)]
     .filter(e=>!e.disabled&&(visible(e)||[...e.labels||[]].some(visible)));
   // A styled ARIA wrapper and its native input expose the same answer.
   // Bind the native control once so checked-state verification cannot count
   // one selected answer twice after the framework mirrors its ARIA state.
   const inputs=candidates.filter(e=>!['radio','checkbox'].includes(e.getAttribute('role'))||
     !candidates.some(other=>other!==e&&e.contains(other)&&other.tagName==='INPUT'&&other.type===choiceType(e)));
   if(!inputs.length)return null;
   const qid='learning-'+index;root.dataset.webqaQid=qid;
   let text='';
   for(const selector of ['.question_text','.qtext','[data-testid="question-text"]','legend','h2,h3']){
     const prompt=[...root.querySelectorAll(selector)].find(e=>visible(e)&&clean(e.innerText)&&!utility(e.innerText));
     if(prompt){text=clean(prompt.innerText);break;}
   }
   if(!text){
     const labelled=[root,...root.querySelectorAll('[aria-labelledby]')].map(e=>e.getAttribute('aria-labelledby')||'').join(' ').split(/\s+/);
     text=clean([...new Set(labelled)].map(id=>document.getElementById(id)).filter(e=>visible(e)&&!utility(e.innerText)).map(e=>e.innerText).join(' '));
   }
   if(!text){
     const copy=root.cloneNode(true);
     copy.querySelectorAll(controls+',label,legend,.answers,.answer,[role=radiogroup],[role=group],script,style').forEach(e=>e.remove());
     text=clean(copy.textContent);
   }
   if(text.length<5||utility(text))return null;
   let kind=inputs.some(e=>choiceType(e)==='checkbox')?'multiple_choice':
       inputs.some(e=>choiceType(e)==='radio')?'single_choice':inputs.some(e=>e.tagName==='SELECT')?'select':'text';
   // Mixed control types require a dedicated adapter, never partial completion.
   const choices=[];let blank=0;
   for(let i=0;i<inputs.length;i++){
     const e=inputs[i],cid=qid+'-'+i;e.dataset.webqaCid=cid;
     if(e.tagName==='SELECT'){
       if(inputs.length!==1)return null;e.dataset.webqaCid=qid+'-select';
       [...e.options].filter(o=>!o.disabled&&o.value!=='').forEach((o,j)=>choices.push({cid:qid+'-option-'+j,text:clean(o.textContent),control_type:'select',checked:o.selected,value:o.value}));
     }else if(['radio','checkbox'].includes(choiceType(e))){
       const label=labelledText(e)||[...e.labels||[]].map(l=>l.innerText).join(' ')||e.getAttribute('aria-label')||e.textContent||e.parentElement.innerText;
       choices.push({cid,text:clean(label),control_type:choiceType(e),checked:typeof e.checked==='boolean'?e.checked:e.getAttribute('aria-checked')==='true',value:e.value||''});
     }else{blank++;if(kind!=='text')return null;}
   }
   if(blank)text+=' Answer each field in order: '+Array.from({length:blank},(_,i)=>'[Blank '+(i+1)+']').join(' ');
   const publicId=root.getAttribute('data-question-id')||root.id;
   return {qid,text,kind,choices,has_visual:!!root.querySelector('img,svg,canvas,math'),
     html_hint:'learning-semantic; blanks='+blank+(publicId?'|question:'+encodeURIComponent(publicId):'')};
 }).filter(Boolean);
 // Identical visible questions without public IDs still have separate controls.
 // Give each occurrence a stable identity within this render so both can be
 // verified before advancing; do not collapse them into one question.
 const keyOf=q=>JSON.stringify([q.kind,q.text,q.choices.map(c=>[c.control_type,c.text]).sort(),q.html_hint]);
 const totals=new Map();
 for(const q of extracted){const key=keyOf(q);totals.set(key,(totals.get(key)||0)+1);}
 const occurrences=new Map();
 for(const q of extracted){
   const key=keyOf(q);
   if(totals.get(key)>1){
     const index=occurrences.get(key)||0;
     q.html_hint+='|occurrence:'+index;
     occurrences.set(key,index+1);
   }
 }
 return extracted;
}'''


async def extract_learning_questions(frame):
    raw=await frame.evaluate(EXTRACT)
    return [Question(**{**item,'choices':[Choice(**c) for c in item['choices']]}) for item in raw]
