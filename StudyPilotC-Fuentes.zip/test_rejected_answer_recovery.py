import unittest
from dataclasses import replace
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch
from playwright.async_api import async_playwright
from models import Question, Choice
from llm import Solver
from mcgraw_adapter import extract_mcgraw_question
import app


class FreshRecovery(unittest.IsolatedAsyncioTestCase):
    async def test_recovery_bypasses_cached_uncertain_review(self):
        q=Question('q','Choose one pair.','single_choice',[Choice('a','Na+; K+','radio'),Choice('b','Ca2+; Mg2+','radio')])
        solver=Solver('test-key','test-model')
        request=AsyncMock(side_effect=[
            NS(status='completed',output_text='{"answers":["Na+; K+"],"confidence":0.2}'),
            NS(status='completed',output_text='{"answers":["Ca2+; Mg2+"],"confidence":0.98}')])
        solver.client=NS(responses=NS(create=request))
        self.assertEqual((await solver.solve(q,review=True)).confidence,.2)
        answer=await solver.solve(q,review=True,recovery_attempt=1,recovery_hint='Na+; K+',
                                  resource_context='The supplied practice passage describes calcium and magnesium.')
        self.assertEqual(answer.answers,['Ca2+; Mg2+'])
        self.assertEqual(request.await_count,2)
        self.assertIn('ONE complete visible option',request.call_args.kwargs['input'][0]['content'][0]['text'])
        self.assertIn('<concept_reference>',request.call_args.kwargs['input'][0]['content'][0]['text'])
        self.assertIn('calcium and magnesium',request.call_args.kwargs['input'][0]['content'][0]['text'])

    async def test_pending_resource_return_precedes_extraction_and_feedback(self):
        page=NS()
        with patch.object(app,'identify_site',AsyncMock(return_value=('McGraw Hill',True))), \
             patch('question_resources.restore_question_resource',AsyncMock(return_value=False)) as restore, \
             patch.object(app,'collect_questions_from_frames',AsyncMock()) as collect, \
             patch.object(app,'handle_feedback',AsyncMock()) as feedback, \
             patch.object(app,'update_overlay',AsyncMock()):
            self.assertEqual(await app.analyze_page(page,NS(),{}),0)
            restore.assert_awaited_once_with(page)
            collect.assert_not_awaited()
            feedback.assert_not_awaited()

    async def test_rejected_answer_waits_then_recovers_and_advances_without_user(self):
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page(viewport={'width':1200,'height':900})
                html='''<main><h1>Multiple Choice Question</h1><p>Choose the pair specified by the study passage.</p>
                <label style="display:block;margin:40px"><input type="radio" name="answer" value="a">Na+; K+</label>
                <label style="display:block;margin:40px"><input type="radio" name="answer" value="b">Ca2+; Mg2+</label>
                <button id="send" disabled>Medium</button></main><script>
                window.sends=0;window.selected='';
                document.querySelector('main').onchange=()=>document.querySelector('#send').disabled=false;
                document.querySelector('#send').onclick=()=>{window.sends++;window.selected=document.querySelector('input:checked').value;
                document.querySelector('main').innerHTML='<h1>Your Answer correct</h1><button id="next">Next Question</button>';
                document.querySelector('#next').onclick=()=>document.querySelector('main').innerHTML='<h1>Next question loaded</h1>';};
                </script>'''
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body=html))
                await page.goto('https://learning.mheducation.com/recovery')
                q=(await extract_mcgraw_question(page.main_frame))[0]
                solver=Solver('test-key','test-model')
                solver.memory.learn(q,['Na+; K+'],False)
                rejected=NS(status='completed',output_text='{"answers":["Na+; K+"],"confidence":0.99}')
                corrected=NS(status='completed',output_text='{"answers":["Ca2+; Mg2+"],"confidence":0.98}')
                request=AsyncMock(side_effect=[rejected,rejected,corrected])
                solver.client=NS(responses=NS(create=request))
                settings=replace(app.settings,mode='fill',mcgraw_auto=True,pacing_minutes=0,use_vision='never',mcgraw_confidence='Medium',min_confidence=.5)
                with patch.object(app,'settings',settings), patch('question_resources.read_question_resource',AsyncMock(return_value='The supplied passage identifies calcium and magnesium.')):
                    seen={}
                    await app.analyze_page(page,solver,seen)
                    self.assertFalse(seen)
                    self.assertEqual(await page.evaluate('window.sends'),0)
                    self.assertEqual(request.await_count,2)
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(request.await_count,2)  # No rapid API loop.
                    for state in app._solve_retries[page].values():state['at']-=1000
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(request.await_count,3)
                    self.assertEqual(await page.evaluate('window.sends'),1)
                    self.assertEqual(await page.evaluate('window.selected'),'b')
                    self.assertTrue(solver.memory.is_rejected(q,['Na+; K+']))
                    await app.analyze_page(page,solver,seen)
                    self.assertIn('Next question loaded',await page.locator('body').inner_text())
            finally:await browser.close()


class RecoverySchedule(unittest.TestCase):
    def test_repeated_uncertainty_stops_at_manual_review_limit(self):
        class Page:pass
        page=Page()
        with patch.object(app.time,'monotonic',return_value=1000):
            for expected in [2,5,10,10,10,10]:
                app.schedule_answer_recovery(page,'q',NS(answers=['uncertain']))
                self.assertEqual(app._solve_retries[page]['q']['at'],1000+expected)

        self.assertTrue(app._solve_retries[page]['q']['blocked'])
