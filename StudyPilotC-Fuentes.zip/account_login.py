"""First-run sign-in for the shared desktop; no server/code fields required."""
import queue
import threading
import tkinter as tk
import webbrowser
import httpx
from shared_access import load_access, save_access, validate_token

SERVER = 'https://study-pilot-server.onrender.com'


def response_data(result):
    try:
        data = result.json()
    except ValueError:
        raise ValueError('El servidor no devolvió una respuesta válida. Vuelve a intentarlo.') from None
    if not isinstance(data, dict):
        raise ValueError('Respuesta del servidor no válida. Vuelve a intentarlo.')
    if result.status_code != 200:
        # Keep unexpected remote content and credentials out of the desktop log.
        messages = {401: 'Correo, contraseña o sesión no válidos. Vuelve a entrar.',
                    403: 'Acceso pendiente o bloqueado. Revisa tu cuenta.',
                    429: 'Demasiados intentos. Espera unos minutos y vuelve a entrar.'}
        raise ValueError(messages.get(result.status_code, 'El servidor no está disponible. Vuelve a intentarlo.'))
    return data


def sign_in(email, password):
    with httpx.Client(timeout=20, follow_redirects=False) as client:
        result = client.post(SERVER + '/v1/account/login', json={'email':email.strip(),'password':password})
    data = response_data(result)
    account = data.get('account')
    if not isinstance(account, dict) or type(account.get('active')) is not bool:
        raise ValueError('Respuesta de cuenta no válida. Vuelve a intentarlo.')
    token = validate_token(data.get('access_token', ''))
    save_access(SERVER, token)
    return account


def access_status():
    url, token = load_access()
    with httpx.Client(timeout=15,follow_redirects=False) as client:
        result=client.get(url+'/access',headers={'Authorization':'Bearer '+token})
    data = response_data(result)
    if data.get('service') != 'study-pilot-c' or type(data.get('active')) is not bool:
        raise ValueError('El servidor no devolvió un estado de acceso válido.')
    return data


def build_account(app, notebook):
    frame=app.account_tab=tk.Frame(notebook,bg='white',padx=26,pady=20)
    notebook.add(frame,text='Mi cuenta')
    app.label(frame,'BIENVENIDO A STUDY PILOT',9,'#087f73',True).pack(anchor='w')
    app.label(frame,'Entra y abre tu actividad',21,bold=True).pack(anchor='w',pady=(8,8))
    app.label(frame,'Tu cuenta conecta la app. No necesitas una API key ni configurar un servidor.',10,
              '#536579',wraplength=570,justify='left').pack(anchor='w',pady=(0,16))
    email=tk.StringVar();password=tk.StringVar();status=tk.StringVar(value='Inicia sesión con el correo y contraseña de tu cuenta.')
    tk.Label(frame,textvariable=status,bg='#e7f5ef',fg='#142c3c',font=('Segoe UI',10,'bold'),wraplength=590,justify='left',padx=10,pady=8).pack(anchor='w',fill='x',pady=(0,10))
    status.trace_add('write',lambda *_:app.detail.set(status.get()))
    for label,var,mask in [('Correo',email,''),('Contraseña',password,'•')]:
        app.label(frame,label,10,bold=True).pack(anchor='w')
        app.entry(frame,var,show=mask).pack(fill='x',ipady=7,pady=(5,12))
    result=queue.Queue()
    def run(fn):
        login['state']=check['state']='disabled';status.set('Conectando…')
        def work():
            try:result.put((True,fn()))
            except ValueError as exc:result.put((False,str(exc)))
            except Exception:result.put((False,'No se pudo conectar. Comprueba Internet y vuelve a intentar.'))
        threading.Thread(target=work,daemon=True).start()
        def done():
            try:ok,value=result.get_nowait()
            except queue.Empty:frame.after(100,done);return
            password.set('');login['state']=check['state']='normal'
            if ok and value.get('active'):
                status.set('Acceso activo. Pulsa Abrir actividad para comenzar.')
                app.status.set('Acceso activo')
                app.detail.set('Acceso activo. Pega el enlace de Canvas o de tu plataforma en Inicio rápido.')
                notebook.select(0)
            elif ok:
                status.set('Sesión iniciada. Tu acceso está pendiente o vencido. Revisa tu cuenta web.')
                app.status.set('Acceso pendiente')
            else:
                status.set(value)
                app.status.set('No se pudo iniciar sesión')
        frame.after(100,done)
    def login_action():
        e,p=email.get(),password.get()
        if not e or not p:status.set('Escribe tu correo y contraseña.');return
        run(lambda:sign_in(e,p))
    login=app.button(frame,'Entrar',login_action,True);login.pack(anchor='w')
    check=app.button(frame,'Comprobar mi acceso guardado',lambda:run(access_status));check.pack(anchor='w')
    app.button(frame,'Crear cuenta / Ver pagos',lambda:webbrowser.open(SERVER+'/cuenta')).pack(anchor='w',pady=5)
    app.label(frame,'1. Entra en tu cuenta   2. Abre Chrome   3. Entra en tu universidad',10,bold=True,wraplength=580).pack(anchor='w',pady=12)
    return frame
