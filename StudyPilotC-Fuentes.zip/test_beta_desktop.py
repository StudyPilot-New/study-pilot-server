import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch
from types import SimpleNamespace
import tempfile
import tkinter as tk
import desktop_ui
import account_login
from desktop_ui import StudyPilot
from drag_diagnostics import _safe_text
from build_release import KEY_PATTERN


class DesktopBetaTests(unittest.TestCase):
    def test_destroy_cancels_scheduled_ui_callbacks(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(desktop_ui,'ROOT',Path(directory)):
            root=tk.Tk();root.withdraw()
            app=StudyPilot(root)
            callbacks={app._poll_after,app._pace_after}
            root.destroy()
            self.assertFalse(callbacks.intersection(root.tk.call('after','info')))

    def test_malformed_login_does_not_replace_saved_access(self):
        for data in ([], None, {}, {'account':[]}, {'account':{'active':'yes'},'access_token':'invalid'}):
            response=MagicMock(status_code=200)
            response.json.return_value=data
            with patch.object(account_login.httpx,'Client') as client, patch.object(account_login,'save_access') as save:
                client.return_value.__enter__.return_value.post.return_value=response
                with self.assertRaises(ValueError):account_login.sign_in('test@example.com','temporary-password')
                save.assert_not_called()

    def test_valid_login_saves_once_and_returns_boolean_state(self):
        token='spc_'+'x'*43
        response=MagicMock(status_code=200)
        response.json.return_value={'account':{'active':False},'access_token':token}
        with patch.object(account_login.httpx,'Client') as client, patch.object(account_login,'save_access') as save:
            client.return_value.__enter__.return_value.post.return_value=response
            self.assertEqual(account_login.sign_in(' test@example.com ','temporary-password'),{'active':False})
            save.assert_called_once_with(account_login.SERVER,token)

    def test_invalid_status_or_html_is_recoverable(self):
        for data in ([], {'service':'other','active':True}, {'service':'study-pilot-c','active':'false'}):
            response=MagicMock(status_code=200)
            response.json.return_value=data
            with patch.object(account_login,'load_access',return_value=('https://test/v1','test')), patch.object(account_login.httpx,'Client') as client:
                client.return_value.__enter__.return_value.get.return_value=response
                with self.assertRaises(ValueError):account_login.access_status()
        response.json.side_effect=ValueError('raw private content')
        with self.assertRaisesRegex(ValueError,'respuesta válida'):account_login.response_data(response)

    def app(self, path):
        app=object.__new__(StudyPilot)
        app.process=MagicMock();app.control=path;app.paused=False;app.stopping=False
        app.status=MagicMock();app.detail=MagicMock();app.pause_button={};app.stop_button={}
        return app

    def test_failed_control_does_not_claim_pause_or_stop(self):
        app=self.app(Path('missing')/'control.txt')
        with patch.object(Path,'write_text',side_effect=PermissionError):
            app.pause();self.assertFalse(app.paused)
            self.assertFalse(app.stop());self.assertFalse(app.stopping)
            app.recover();self.assertFalse(app.paused)
        app.status.set.assert_called_with('No se pudo enviar el comando')

    def test_stop_cannot_be_overwritten_by_repeated_pause_or_recover(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'control.txt';app=self.app(path)
            app.pause();self.assertEqual(path.read_text(),'pause')
            app.stop();app.pause();app.recover();app.stop()
            self.assertEqual(path.read_text(),'stop')

    def test_shared_tokens_bearers_and_urls_redacted_and_package_guarded(self):
        token='spc_'+'x'*43
        secret='sk-proj-'+'y'*30
        output=_safe_text(f'error {token} {secret} Bearer private-value https://test/?key=private')
        for private in (token,secret,'private-value','key=private'):
            self.assertNotIn(private,output)
        self.assertIsNotNone(KEY_PATTERN.search(token.encode()))


if __name__=='__main__':unittest.main()
