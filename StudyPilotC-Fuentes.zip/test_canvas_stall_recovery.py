"""Regression cases for Canvas questions that previously stalled the watcher."""
import unittest
import time
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from playwright.async_api import async_playwright

from learning_adapter import extract_learning_questions
from canvas_navigation import current_question, question_identity, restore_answer, answer_is_selected
from app import collect_questions_from_frames
import app


class CanvasStallRecovery(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw = await async_playwright().start()
        self.browser = await self.pw.chromium.launch(channel='chrome', headless=True)
        self.page = await self.browser.new_page()

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def test_identical_questions_both_rebind_and_select(self):
        await self.page.set_content('''<main>
          <section class="question"><p class="question_text">Select the best example.</p>
            <label><input type="radio" name="first">Alpha</label>
            <label><input type="radio" name="first">Beta</label></section>
          <section class="question"><p class="question_text">Select the best example.</p>
            <label><input type="radio" name="second">Alpha</label>
            <label><input type="radio" name="second">Beta</label></section>
        </main>''')
        found = await collect_questions_from_frames(self.page)
        self.assertEqual(len(found), 2)
        self.assertNotEqual(question_identity(found[0][2]), question_identity(found[1][2]))
        for _, frame, question in found:
            self.assertIsNotNone(await current_question(frame, question))
            self.assertTrue(await restore_answer(frame, question, ['Alpha']))
            self.assertTrue(await answer_is_selected(frame, question, ['Alpha'], stable_for=.01))
        self.assertEqual(await self.page.locator('input:checked').count(), 2)

    async def test_quiz_item_is_a_question(self):
        await self.page.set_content('''<h1>Question 1</h1><div class="quiz-item">
          <p>Choose a correct answer.</p>
          <label><input type="radio" name="answer">Alpha</label>
          <label><input type="radio" name="answer">Beta</label></div>''')
        questions = await extract_learning_questions(self.page.main_frame)
        self.assertEqual(len(questions), 1)
        self.assertEqual(questions[0].kind, 'single_choice')
        self.assertIn('Choose a correct answer', questions[0].text)

    async def test_nested_answer_wrapper_keeps_outer_prompt(self):
        await self.page.set_content('''<section class="question">
          <p class="question_text">Which attribute describes ability?</p>
          <div class="quiz-item"><label><input type="radio" name="answer">Stable</label>
          <label><input type="radio" name="answer">Unstable</label></div></section>''')
        questions=await extract_learning_questions(self.page.main_frame)
        self.assertEqual(len(questions),1)
        self.assertEqual(questions[0].text,'Which attribute describes ability?')

    async def test_list_wrapper_does_not_merge_two_questions(self):
        await self.page.set_content('''<main class="question-container">
          <section class="question"><p class="question_text">Which answer is first?</p>
            <label><input type="radio" name="a">Alpha</label></section>
          <section class="question"><p class="question_text">Which answer is second?</p>
            <label><input type="radio" name="b">Beta</label></section></main>''')
        questions=await extract_learning_questions(self.page.main_frame)
        self.assertEqual([q.text for q in questions],['Which answer is first?','Which answer is second?'])

    async def test_no_controls_releases_input_once_and_explains_wait(self):
        await self.page.set_content('<h1>Question 1</h1><p>Loading controls</p>')
        app._blank_since[self.page]=time.monotonic()-9
        overlay=AsyncMock()
        with patch.object(app,'settings',replace(app.settings,mode='fill',pacing_minutes=0)), \
             patch.object(app,'identify_site',AsyncMock(return_value=('Canvas',False))), \
             patch.object(app,'update_overlay',overlay), \
             patch('recovery.release_input',new_callable=AsyncMock) as release:
            await app.analyze_page(self.page,SimpleNamespace(memory=None),{})
            await app.analyze_page(self.page,SimpleNamespace(memory=None),{})
        release.assert_awaited_once()
        self.assertIn('no se detectan controles',overlay.await_args.args[2])

    async def test_iframe_canvas_quiz_beats_older_mcgraw_tab(self):
        context=await self.browser.new_context()
        async def route(request):
            if request.request.url.endswith('/quiz-inner'):
                body='<section class="question"><p>Which answer is correct?</p><label><input type="radio">Alpha</label></section>'
            elif 'instructure.com' in request.request.url:
                body='<iframe src="https://course.instructure.com/quiz-inner"></iframe>'
            else:
                body='<h1>Old McGraw activity</h1>'
            await request.fulfill(content_type='text/html',body=body)
        await context.route('**/*',route)
        try:
            canvas=await context.new_page()
            await canvas.goto('https://course.instructure.com/courses/1/quizzes/1/take')
            await canvas.frames[-1].locator('.question').wait_for(state='visible')
            mcgraw=await context.new_page()
            await mcgraw.goto('https://learning.mheducation.com/old')
            self.assertIs(await app.choose_target_page(context),canvas)
        finally:
            await context.close()


if __name__ == '__main__':
    unittest.main()
