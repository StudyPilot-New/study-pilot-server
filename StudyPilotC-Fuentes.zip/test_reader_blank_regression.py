import json
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from playwright.async_api import async_playwright

import app
import reading_navigation as nav
from llm import Solver
from models import Choice, Question
from session_memory import SessionMemory


class ThreeBlankRepair(unittest.IsolatedAsyncioTestCase):
    async def test_repairs_empty_field_without_opening_another_resource(self):
        q=Question('three','The three levels are [Blank 1] regulation, [Blank 2] regulation, [Blank 3] regulation.',
                   'fill_blank',[Choice(str(i),'','text') for i in range(3)])
        solver=object.__new__(Solver)
        solver.memory=SessionMemory();solver.cache={};solver.fast_mode=True
        solver.model='test-model';solver.reasoning_effort='none';solver.max_output_tokens=180;solver.book=None
        responses=[SimpleNamespace(status='completed',output_text=json.dumps({
            'answer_type':'fill_blank','answers':['transcriptional','','post-translational'],'confidence':.4})),
            SimpleNamespace(status='completed',output_text=json.dumps({
            'answer_type':'fill_blank','answers':['transcriptional','translational','post-translational'],'confidence':.7}))]
        create=AsyncMock(side_effect=responses)
        solver.client=SimpleNamespace(responses=SimpleNamespace(create=create))
        answer=await solver.solve(q)
        self.assertEqual(answer.answers,['transcriptional','translational','post-translational'])
        self.assertEqual(create.await_count,2)
        self.assertGreaterEqual(create.await_args_list[0].kwargs['max_output_tokens'],300)


class OrphanReader(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page()
        await self.page.route('https://learning.mheducation.com/**',lambda route:route.fulfill(
            content_type='text/html',body='<div id="content"><h1>Question</h1></div>'))
        await self.page.goto('https://learning.mheducation.com/static/awd/index.html')

    async def asyncTearDown(self):
        await self.browser.close();await self.pw.stop()

    async def test_reader_without_checkpoint_returns_by_history(self):
        await self.page.evaluate('''() => {history.pushState({},"","#reader");
            document.body.innerHTML='<h1>CHAPTER 6</h1><p>Page 134</p>';
            addEventListener('popstate',()=>document.body.innerHTML='<h1>Question</h1>',{once:true});}''')
        self.assertTrue(await nav.reader_view(self.page))
        self.assertIn('buscando',await nav.recover_orphan_reader(self.page))
        nav._orphan_readers[self.page]['started']-=4
        self.assertIn('historial',await nav.recover_orphan_reader(self.page))
        self.assertFalse(await nav.reader_view(self.page))

    async def test_unrelated_page_does_not_trigger_reader_recovery(self):
        await self.page.set_content('<h1>CHAPTER 6</h1><p>Loading a question</p>')
        with patch.object(self.page,'go_back',AsyncMock()) as back:
            self.assertEqual(await nav.recover_orphan_reader(self.page),'')
            back.assert_not_awaited()


if __name__=='__main__':unittest.main()
