"""Bounded local technical events. Never accepts application text or identifiers."""
import datetime
import json
import os
from pathlib import Path
import sys
import threading
import time
import uuid

VERSION = '2026.10.02.15'
STAGES = {'session', 'cycle', 'control', 'selection', 'analysis'}
EVENTS = {'start', 'complete', 'waiting', 'pause_pending', 'stop_requested', 'cancelled', 'error',
          'session_expired', 'session_resumed', 'review_retry', 'review_exhausted'}
ERRORS = {'TimeoutError', 'OSError', 'PermissionError', 'ValueError', 'RuntimeError', 'CancelledError',
          'AuthenticationError', 'PermissionDeniedError', 'RateLimitError', 'APIConnectionError',
          'APITimeoutError', 'InternalServerError', 'BadRequestError', 'OtherError'}


class Diagnostics:
    def __init__(self, directory, limit=65536):
        self.directory = Path(directory)
        self.path = self.directory / ('engine-%s.jsonl' % os.getpid())
        self.limit = limit
        self.session = uuid.uuid4().hex
        self.started = time.monotonic()
        self.lock = threading.Lock()
        self.last_events = {}

    def event(self, stage, event, duration=0, error=None):
        if stage not in STAGES or event not in EVENTS:
            return False
        try:
            duration = max(0, min(float(duration), 86400))
            row = {'version': VERSION, 'session': self.session, 'pid': os.getpid(),
                   'stage': stage, 'event': event, 'duration_s': round(duration, 2),
                   'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   'error_type': type(error).__name__ if type(error).__name__ in ERRORS else ('OtherError' if error else None)}
            payload = json.dumps(row, allow_nan=False) + '\n'
            with self.lock:
                # Fast polling otherwise replaces the useful incident with
                # hundreds of identical healthy-cycle events in a few minutes.
                key=(stage,event,row['error_type'])
                now=time.monotonic()
                if now-self.last_events.get(key,float('-inf'))<30:return True
                self.directory.mkdir(parents=True, exist_ok=True)
                # Global bound: current file plus at most two other files, including old sessions.
                files = sorted(self.directory.glob('engine-*.jsonl*'), key=lambda p:p.stat().st_mtime)
                for old in files[:-2]:
                    if old != self.path: old.unlink()
                if self.path.exists() and self.path.stat().st_size + len(payload.encode()) > self.limit:
                    self.path.replace(self.path.with_suffix('.jsonl.1'))
                with self.path.open('a', encoding='utf-8') as target: target.write(payload)
                self.last_events[key]=now
                files = sorted(self.directory.glob('engine-*.jsonl*'), key=lambda p:p.stat().st_mtime)
                for old in files[:-3]: old.unlink()
            return True
        except (OSError, ValueError, TypeError):
            return False  # Diagnostic storage must not interrupt the activity.

    def export(self, destination):
        rows = []
        with self.lock:
            for path in sorted(self.directory.glob('engine-*.jsonl*'))[-3:]:
                # Parse and whitelist again; never copy arbitrary file contents.
                for line in path.read_bytes()[:self.limit].decode('utf-8',errors='replace').splitlines():
                    try:
                        row = json.loads(line)
                        if row.get('stage') not in STAGES or row.get('event') not in EVENTS: continue
                        duration = float(row['duration_s'])
                        if not 0 <= duration <= 86400: continue
                        rows.append({'stage':row['stage'], 'event':row['event'], 'duration_s':duration,
                                     'error_type':row.get('error_type') if row.get('error_type') in ERRORS else None})
                    except (ValueError, TypeError, KeyError, AttributeError): continue
        # Export excludes raw messages, URLs, timestamps and original session identifiers.
        with Path(destination).open('x',encoding='utf-8') as target:
            json.dump({'diagnostic_version':VERSION,'events':rows},target,indent=2)


_instance = None
def diagnostics():
    global _instance
    if _instance is None:
        from runtime_paths import DATA_DIR
        _instance = Diagnostics(DATA_DIR/'diagnostics')
    return _instance
