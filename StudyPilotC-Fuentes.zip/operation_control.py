"""Observe an in-flight cycle; defer pause, cancel stop, never restart work."""
import asyncio
import time


async def supervised_cycle(operation, control, emit, interval=.25, notice_after=15):
    task = asyncio.create_task(operation)
    started = time.monotonic()
    next_notice = notice_after
    pause_notified = False
    try:
        while not task.done():
            done, _ = await asyncio.wait({task}, timeout=interval)
            if done: break
            try: command = control.read_text(encoding='utf-8').strip() if control else 'run'
            except OSError: command = 'run'
            elapsed = time.monotonic()-started
            if command == 'stop':
                emit('stop_requested', elapsed)
                task.cancel()
                try: await task
                except asyncio.CancelledError: pass
                emit('cancelled', elapsed)
                return None
            if command == 'pause' and not pause_notified:
                pause_notified = True
                emit('pause_pending', elapsed)
            if elapsed >= next_notice:
                emit('waiting', elapsed)
                next_notice = elapsed + notice_after
        return await task
    finally:
        if not task.done():
            task.cancel()
            try: await task
            except asyncio.CancelledError: pass

