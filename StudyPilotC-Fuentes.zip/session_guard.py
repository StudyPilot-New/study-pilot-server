"""Recognize a visible logged-out dialog without clicking or keeping a session alive."""
import asyncio

async def session_expired(page):
    try:
        frames = page.frames
    except AttributeError:
        return False
    for frame in frames:
        try:
            expired = await asyncio.wait_for(frame.evaluate('''() => {
                const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);
                    return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';};
                return [...document.querySelectorAll('[role="dialog"],dialog,[aria-modal="true"],section,div')].some(e=>{
                    if(!visible(e)||e.closest('#webqa-overlay'))return false;
                    const t=(e.innerText||'').trim();
                    return t.length<700 && /session\\s+expired/i.test(t) &&
                        /(?:due to inactivity|logged out)/i.test(t) &&
                        [...e.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"]')].some(b=>visible(b)&&/exit (?:recharge|assignment)|log ?in|sign ?in/i.test(b.innerText||b.value||b.getAttribute('aria-label')||''));
                });
            }'''), 2)
            if expired:return True
        except Exception:
            continue
    return False


def incomplete_blank_prompt(question):
    """Repeated field labels alone are not a question; never invent the missing stem."""
    import re
    if question.kind!='fill_blank' or question.has_visual:return False
    text=re.sub(r'\[Blank\s+\d+\]',' ',question.text,flags=re.I)
    words=re.findall(r'[a-zA-Z]+',text.lower())
    return len(question.choices)>1 and len(words)<8 and len(set(words))<=2
