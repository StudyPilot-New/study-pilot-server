from __future__ import annotations
from typing import Any, Dict, List
from models import Choice, Question

MARK_AND_EXTRACT_JS = r"""
() => {
  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim();

  const visible = (el) => {
    if (!el || !el.getBoundingClientRect) return false;
    const s = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return s.display !== 'none' &&
           s.visibility !== 'hidden' &&
           Number(s.opacity || 1) > 0 &&
           r.width > 2 && r.height > 2;
  };

  const textOf = (el) => clean(el?.innerText || el?.textContent || '');

  // Recursively search document + all OPEN shadow roots.
  const allRoots = () => {
    const roots = [document];
    const queue = [document.documentElement];

    while (queue.length) {
      const node = queue.shift();
      if (!node || !node.querySelectorAll) continue;

      for (const el of node.querySelectorAll('*')) {
        if (el.shadowRoot) {
          roots.push(el.shadowRoot);
          queue.push(el.shadowRoot);
        }
      }
    }
    return roots;
  };

  const roots = allRoots();

  const qsa = (selector) => {
    const out = [];
    for (const root of roots) {
      try {
        for (const el of root.querySelectorAll(selector)) out.push(el);
      } catch (_) {}
    }
    return [...new Set(out)];
  };

  const semanticControlSelector = [
    'input[type="radio"]',
    'input[type="checkbox"]',
    '[role="radio"]',
    '[role="checkbox"]',
    '[role="option"]',
    '[aria-checked]',
    'input[type="text"]',
    'input:not([type])',
    'textarea',
    'select'
  ].join(',');

  let controls = qsa(semanticControlSelector).filter(visible);

  // Fallback for custom UI widgets.
  const clickableSelector = [
    'button',
    '[role="button"]',
    '[tabindex="0"]',
    '[class*="checkbox" i]',
    '[class*="radio" i]',
    '[class*="option" i]',
    '[class*="answer" i]',
    '[data-testid*="option" i]',
    '[data-testid*="answer" i]'
  ].join(',');

  const clickable = qsa(clickableSelector).filter(el => {
    if (!visible(el)) return false;
    const t = textOf(el);
    return t.length > 0 && t.length < 500;
  });

  const candidates = new Set();

  const semanticQuestionSelectors = [
    'fieldset',
    '[role="group"]',
    '[role="radiogroup"]',
    '[class*="question" i]',
    '[id*="question" i]',
    '[data-testid*="question" i]',
    '[data-question]',
    '[aria-label*="question" i]',
    '[class*="prompt" i]',
    '[class*="stem" i]',
    '[class*="problem" i]',
    '[class*="activity" i]'
  ];

  for (const sel of semanticQuestionSelectors) {
    for (const el of qsa(sel)) {
      if (!visible(el)) continue;
      const txt = textOf(el);
      if (txt.length < 3 || txt.length > 10000) continue;

      const innerControls = [...el.querySelectorAll?.(semanticControlSelector) || []].filter(visible);
      const innerClickable = [...el.querySelectorAll?.(clickableSelector) || []].filter(visible);

      if (innerControls.length || innerClickable.length) {
        candidates.add(el);
      }
    }
  }

  // Walk upward from every real semantic control.
  for (const c of controls) {
    let el = c;
    let best = null;

    for (let depth = 0; depth < 10 && el; depth++, el = el.parentElement) {
      if (!visible(el)) continue;
      const txt = textOf(el);
      if (txt.length >= 3 && txt.length <= 10000) best = el;

      if (el.matches?.(
        'fieldset,[role="group"],[role="radiogroup"],' +
        '[class*="question" i],[id*="question" i],[data-testid*="question" i],' +
        '[data-question],[class*="prompt" i],[class*="stem" i],[class*="problem" i]'
      )) {
        best = el;
        break;
      }
    }
    if (best) candidates.add(best);
  }

  // McGraw-style fallback:
  // Find the visible "Multiple Select Question" / "Multiple Choice Question"
  // heading and use a nearby large container even when controls are fully custom.
  const bodyText = textOf(document.body);
  const looksLikeQuestionPage =
      /multiple\s+select\s+question/i.test(bodyText) ||
      /multiple\s+choice\s+question/i.test(bodyText) ||
      /select\s+all\s+that\s+apply/i.test(bodyText) ||
      /concepts?\s+completed/i.test(bodyText);

  if (looksLikeQuestionPage && candidates.size === 0) {
    const textNodes = qsa('h1,h2,h3,h4,h5,h6,div,section,main,article,p,span').filter(visible);

    const anchor = textNodes.find(el =>
      /multiple\s+(select|choice)\s+question/i.test(textOf(el)) ||
      /select\s+all\s+that\s+apply/i.test(textOf(el))
    );

    if (anchor) {
      let el = anchor;
      let best = null;

      for (let depth = 0; depth < 9 && el; depth++, el = el.parentElement) {
        const t = textOf(el);
        if (t.length >= 20 && t.length <= 12000) {
          // prefer a container with several short clickable descendants
          const shortClicks = [...el.querySelectorAll?.(clickableSelector) || []]
            .filter(x => visible(x) && textOf(x).length > 0 && textOf(x).length < 300);

          if (shortClicks.length >= 2 || depth >= 3) best = el;
        }
      }

      if (best) candidates.add(best);
    }
  }

  let list = [...candidates].filter(visible);

  // Deduplicate nested wrappers, preferring the smallest one containing
  // meaningful control/option content.
  list = list.filter(el => {
    const t = textOf(el);
    if (t.length < 3) return false;

    return !list.some(other => {
      if (other === el || !el.contains(other)) return false;
      const ot = textOf(other);
      if (ot.length < 3) return false;

      const otherControlCount =
        [...other.querySelectorAll?.(semanticControlSelector) || []].filter(visible).length;
      const thisControlCount =
        [...el.querySelectorAll?.(semanticControlSelector) || []].filter(visible).length;

      return otherControlCount >= thisControlCount && ot.length <= t.length;
    });
  });

  list.sort((a,b) =>
    a.getBoundingClientRect().top - b.getBoundingClientRect().top
  );

  const getAriaText = (el) => {
    const labelledby = el.getAttribute?.('aria-labelledby');
    if (labelledby) {
      const text = labelledby.split(/\s+/)
        .map(id => document.getElementById(id))
        .filter(Boolean)
        .map(textOf)
        .filter(Boolean)
        .join(' ');
      if (text) return text;
    }
    return clean(el.getAttribute?.('aria-label') || '');
  };

  const labelFor = (control) => {
    if (control.id) {
      try {
        const root = control.getRootNode?.() || document;
        const lbl = root.querySelector?.(`label[for="${CSS.escape(control.id)}"]`);
        if (lbl && textOf(lbl)) return textOf(lbl);
      } catch (_) {}
    }

    const aria = getAriaText(control);
    if (aria) return aria;

    const wrapping = control.closest?.('label');
    if (wrapping && textOf(wrapping)) return textOf(wrapping);

    let p = control.parentElement;
    for (let i = 0; i < 5 && p; i++, p = p.parentElement) {
      const t = textOf(p);
      if (t && t.length <= 500) return t;
    }

    return clean(control.value || control.getAttribute?.('data-value') || '');
  };

  const utilityPatterns = [
    /^multiple\s+select\s+question$/i,
    /^multiple\s+choice\s+question$/i,
    /^true\s*\/?\s*false\s+question$/i,
    /^select\s+all\s+that\s+apply\.?$/i,
    /^choose\s+the\s+(best|correct)\s+answer\.?$/i,
    /^select\s+one\.?$/i,
    /^\d+\s+of\s+\d+\s+concepts?\s+completed$/i,
    /^check\s+my\s+work$/i,
    /^submit$/i,
    /^next$/i,
    /^previous$/i,
    /^question\s+\d+$/i
  ];

  const removeUtilityLines = (fullText, choiceTexts) => {
    let lines = (fullText || '')
      .split(/\n+/)
      .map(clean)
      .filter(Boolean);

    lines = lines.filter(line => {
      if (utilityPatterns.some(re => re.test(line))) return false;
      if (choiceTexts.some(c => clean(c).toLowerCase() === line.toLowerCase())) return false;
      return true;
    });

    return clean(lines.join(' '));
  };

  const plausibleOptionText = (t) => {
    t = clean(t);
    if (!t || t.length > 300) return false;
    if (utilityPatterns.some(re => re.test(t))) return false;
    if (/^(help|hint|read about|references?|resources?|tools?)$/i.test(t)) return false;
    return true;
  };

  const result = [];
  let idx = 0;

  for (const el of list) {
    idx += 1;
    const qid = `webqa-q-${idx}`;
    el.setAttribute('data-webqa-qid', qid);

    const scoped = (selector) => {
      const out = [];
      try {
        for (const x of el.querySelectorAll(selector)) out.push(x);
      } catch (_) {}
      // If element hosts an open shadow root, include that too.
      if (el.shadowRoot) {
        try {
          for (const x of el.shadowRoot.querySelectorAll(selector)) out.push(x);
        } catch (_) {}
      }
      return [...new Set(out)].filter(visible);
    };

    const radios = scoped('input[type="radio"],[role="radio"]');
    const checks = scoped('input[type="checkbox"],[role="checkbox"],[aria-checked]');
    const texts = scoped('input[type="text"],input:not([type]),textarea');
    const selects = scoped('select');

    let kind = 'unknown';
    if (checks.length) kind = 'multiple_choice';
    else if (radios.length) kind = 'single_choice';
    else if (selects.length) kind = 'select';
    else if (texts.length) kind = 'text';

    const choices = [];
    let n = 0;

    const register = (control, type, labelText) => {
      const cid = `${qid}-c-${++n}`;
      control.setAttribute('data-webqa-cid', cid);
      choices.push({
        cid,
        text: clean(labelText),
        control_type: type,
        checked:
          control.checked === true ||
          control.getAttribute?.('aria-checked') === 'true',
        value: clean(control.value || control.getAttribute?.('data-value') || '')
      });
    };

    for (const r of radios) register(r, 'radio', labelFor(r));
    for (const c of checks) register(c, 'checkbox', labelFor(c));

    for (const s of selects) {
      const options = [...s.options].filter(o => !o.disabled && clean(o.text));
      for (const o of options) {
        const cid = `${qid}-c-${++n}`;
        choices.push({
          cid,
          text: clean(o.text),
          control_type: 'option',
          checked: o.selected,
          value: clean(o.value || '')
        });
      }
      s.setAttribute('data-webqa-cid', `${qid}-select`);
    }

    for (const t of texts) register(t, t.tagName.toLowerCase(), '');

    // Custom-control fallback: use short clickable descendants as choices.
    if (choices.length === 0) {
      const customs = scoped(clickableSelector)
        .filter(x => plausibleOptionText(textOf(x)));

      const seenText = new Set();
      for (const c of customs) {
        const txt = textOf(c);
        const key = txt.toLowerCase();

        if (!txt || seenText.has(key)) continue;
        seenText.add(key);

        const cid = `${qid}-c-${++n}`;
        c.setAttribute('data-webqa-cid', cid);

        choices.push({
          cid,
          text: txt,
          control_type: 'custom',
          checked: c.getAttribute?.('aria-checked') === 'true',
          value: clean(c.getAttribute?.('data-value') || '')
        });
      }

      if (choices.length >= 2) {
        const fullText = textOf(el);
        if (/select\s+all\s+that\s+apply/i.test(fullText) ||
            /multiple\s+select/i.test(fullText)) {
          kind = 'multiple_choice';
        } else {
          kind = 'single_choice';
        }
      }
    }

    const visualSelector = [
      'img', 'canvas', 'svg', 'video', 'math', 'mjx-container',
      '[class*="math" i]', '[class*="diagram" i]', '[class*="figure" i]'
    ].join(',');

    const hasVisual = !!el.querySelector?.(visualSelector);
    const full = (el.innerText || el.textContent || '').trim();
    const qtext = removeUtilityLines(full, choices.map(c => c.text));

    if (!qtext && choices.length === 0) continue;

    result.push({
      qid,
      text: (qtext || clean(full)).slice(0, 7000),
      kind,
      choices,
      has_visual: hasVisual,
      html_hint: clean(el.tagName + ' ' + (el.className || '')).slice(0, 350)
    });
  }

  return result;
}
"""

DEBUG_DOM_JS = r"""
() => {
  const clean = s => (s || '').replace(/\s+/g, ' ').trim();
  const visible = el => {
    if (!el || !el.getBoundingClientRect) return false;
    const s = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return s.display !== 'none' && s.visibility !== 'hidden' &&
           r.width > 2 && r.height > 2;
  };

  const roots = [document];
  const queue = [document.documentElement];
  while (queue.length) {
    const n = queue.shift();
    if (!n || !n.querySelectorAll) continue;
    for (const el of n.querySelectorAll('*')) {
      if (el.shadowRoot) {
        roots.push(el.shadowRoot);
        queue.push(el.shadowRoot);
      }
    }
  }

  const qsa = sel => {
    const out = [];
    for (const root of roots) {
      try { out.push(...root.querySelectorAll(sel)); } catch (_) {}
    }
    return [...new Set(out)];
  };

  const sample = qsa(
    'input,[role],[aria-checked],button,[tabindex="0"],' +
    '[class*="question" i],[class*="option" i],[class*="answer" i],' +
    '[class*="checkbox" i],[class*="radio" i]'
  ).filter(visible).slice(0, 80).map(el => ({
    tag: el.tagName,
    role: el.getAttribute?.('role') || '',
    type: el.getAttribute?.('type') || '',
    ariaChecked: el.getAttribute?.('aria-checked') || '',
    cls: String(el.className || '').slice(0, 120),
    text: clean(el.innerText || el.textContent || '').slice(0, 160)
  }));

  return {
    url: location.href,
    title: document.title,
    shadowRoots: roots.length - 1,
    inputs: qsa('input').filter(visible).length,
    radios: qsa('input[type="radio"],[role="radio"]').filter(visible).length,
    checkboxes: qsa('input[type="checkbox"],[role="checkbox"],[aria-checked]').filter(visible).length,
    buttons: qsa('button,[role="button"]').filter(visible).length,
    bodyText: clean(document.body?.innerText || '').slice(0, 2200),
    sample
  };
}
"""

async def extract_questions(frame) -> List[Question]:
    raw: List[Dict[str, Any]] = await frame.evaluate(MARK_AND_EXTRACT_JS)
    out: List[Question] = []

    for q in raw:
        choices = [Choice(**c) for c in q.get("choices", [])]
        if not q.get("text") and not any(c.text for c in choices):
            continue

        out.append(
            Question(
                qid=q["qid"],
                text=q.get("text", ""),
                kind=q.get("kind", "unknown"),
                choices=choices,
                has_visual=bool(q.get("has_visual")),
                html_hint=q.get("html_hint", ""),
            )
        )
    return out

async def debug_dom(frame) -> Dict[str, Any]:
    return await frame.evaluate(DEBUG_DOM_JS)

async def screenshot_question(frame, qid: str) -> bytes:
    loc = frame.locator(f'[data-webqa-qid="{qid}"]').first
    await loc.scroll_into_view_if_needed()
    # Preserve thin chemical bonds and subscript labels without JPEG artifacts.
    return await loc.screenshot(type="png",
                                style="#webqa-overlay { visibility: hidden !important; }")

async def highlight_answer(frame, question: Question, answer_texts: List[str], matcher):
    await frame.evaluate(r"""
    () => {
      for (const el of document.querySelectorAll('[data-webqa-highlight="1"]')) {
        el.style.removeProperty('outline');
        el.style.removeProperty('outline-offset');
        el.style.removeProperty('box-shadow');
        el.style.removeProperty('border-radius');
        el.removeAttribute('data-webqa-highlight');
      }
    }
    """)

    matched = []
    for requested in answer_texts:
        best = matcher(requested, question.choices)
        if best and all(x.cid != best.cid for x in matched):
            matched.append(best)

    if question.kind == "single_choice" and matched:
        matched = matched[:1]

    for ch in matched:
        loc = frame.locator(f'[data-webqa-cid="{ch.cid}"]').first
        try:
            await loc.evaluate(r"""
            el => {
              let target = el;
              if (el.id) {
                try {
                  const root = el.getRootNode?.() || document;
                  const lbl = root.querySelector?.(`label[for="${CSS.escape(el.id)}"]`);
                  if (lbl) target = lbl;
                } catch (_) {}
              }

              if (target === el) {
                const wrapping = el.closest?.('label');
                if (wrapping) target = wrapping;
                else if (el.parentElement) target = el.parentElement;
              }

              target.setAttribute('data-webqa-highlight', '1');
              target.style.setProperty('outline', '3px solid #f2b705', 'important');
              target.style.setProperty('outline-offset', '4px', 'important');
              target.style.setProperty('box-shadow', '0 0 0 5px rgba(242,183,5,.14)', 'important');
              target.style.setProperty('border-radius', '5px', 'important');
            }
            """)
        except Exception:
            pass

    return matched

async def fill_answer(frame, question: Question, answer_texts: List[str], matcher) -> Dict[str, Any]:
    result = {"qid": question.qid, "filled": False, "details": ""}

    if question.kind in {"single_choice", "multiple_choice"}:
        if not question.choices:
            result["details"] = "No choices discovered."
            return result

        matched = []
        for requested in answer_texts:
            best = matcher(requested, question.choices)
            if best:
                matched.append(best)

        if question.kind == "single_choice" and matched:
            matched = matched[:1]

        for ch in matched:
            loc = frame.locator(f'[data-webqa-cid="{ch.cid}"]').first
            try:
                await loc.check(force=False)
            except Exception:
                await loc.click(force=False)

        result["filled"] = bool(matched)
        result["details"] = ", ".join(c.text for c in matched) or "No matching option."
        return result

    if question.kind == "select":
        if not answer_texts:
            return result
        sel = frame.locator(f'[data-webqa-cid="{question.qid}-select"]').first
        best = matcher(answer_texts[0], question.choices)
        if best:
            try:
                await sel.select_option(label=best.text)
            except Exception:
                await sel.select_option(value=best.value)
            result["filled"] = True
            result["details"] = best.text
        return result

    if question.kind == "text":
        if not answer_texts:
            return result
        qloc = frame.locator(f'[data-webqa-qid="{question.qid}"]').first
        fields = qloc.locator('textarea,input[type="text"],input[type="number"],input:not([type])')
        count=await fields.count()
        if count!=len(answer_texts):
            result['details']='Expected one answer per field; no partial answer applied.'
            return result
        for index,text in enumerate(answer_texts):await fields.nth(index).fill(text)
        result["filled"] = True
        result["details"] = ' | '.join(answer_texts)
        return result

    result["details"] = f"Unsupported/unknown DOM type: {question.kind}"
    return result
