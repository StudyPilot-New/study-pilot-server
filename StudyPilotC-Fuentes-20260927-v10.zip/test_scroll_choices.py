import unittest
from playwright.async_api import async_playwright
from mcgraw_adapter import extract_mcgraw_question
from mcgraw_actions import fill_mcgraw_answer


class ScrollChoices(unittest.IsolatedAsyncioTestCase):
    async def test_all_checkboxes_are_read_below_fixed_footer_and_after_scroll(self):
        html='''<meta charset="utf-8"><h1>Multiple Select Question</h1>
        <p>Select all that apply</p><p>Which descriptions apply to this reaction?</p>
        <section>'''+''.join(f'<label style="display:block;height:180px"><input type="checkbox" value="{i}">Description {i}</label>' for i in range(5))+'''
        </section><p>Need help? Review concept resources.</p>
        <footer style="position:fixed;bottom:0;background:white;height:70px;width:100%"><p>Rate your confidence to submit your answer.</p><button>Low</button></footer>
        <div hidden><label><input type="checkbox">Hidden previous answer</label></div>'''
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page(viewport={'width':1100,'height':500})
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body=html))
                await page.goto('https://learning.mheducation.com/test')
                for scrolled in (False,True):
                    with self.subTest(scrolled=scrolled):
                        if scrolled:await page.evaluate('window.scrollTo(0,document.body.scrollHeight)')
                        found=await extract_mcgraw_question(page.main_frame)
                        self.assertEqual(len(found),1)
                        q=found[0]
                        self.assertEqual(q.kind,'multiple_choice')
                        self.assertEqual([c.text for c in q.choices],[f'Description {i}' for i in range(5)])
                        result=await fill_mcgraw_answer(page,page.main_frame,q,['Description 1','Description 4'])
                        self.assertTrue(result['filled'],result)
                        self.assertEqual(await page.locator('input:checked').evaluate_all('els=>els.map(x=>x.value)'),['1','4'])
            finally:await browser.close()


if __name__=='__main__':unittest.main()
