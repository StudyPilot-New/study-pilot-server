"""Apply top-to-bottom ordering through the application's keyboard controls."""
import asyncio


DRAG_TEXT_JS = r"""el => {
    const clean=s=>(s || '').normalize('NFKC').replace(/\s+/g,' ').trim();
    const recorded=el.getAttribute('data-webqa-match-option-text');
    if(recorded)return clean(recorded);
    const announced=clean(el.getAttribute('aria-label')).match(/^Choice\s+\d+\s+of\s+\d+\.\s*(.+)$/i);
    if(announced)return announced[1];
    const clone=el.cloneNode(true);
    clone.querySelectorAll('script,style,template,annotation,annotation-xml,[aria-live],[role="status"],.sr-only,.visually-hidden').forEach(n=>n.remove());
    let replaced=false;
    for(const renderer of clone.querySelectorAll('mjx-container,.MathJax,.katex')) {
        const math=renderer.querySelector('math');
        if(math){renderer.replaceWith(document.createTextNode(math.textContent));replaced=true;}
    }
    if(replaced)return clean(clone.textContent);
    const maths=clone.querySelectorAll('math');
    if(maths.length===1){const key=s=>clean(s).replace(/[−–—]/g,'-').replace(/\s/g,'');
        const single=key(maths[0].textContent),whole=key(clone.textContent);
        if(single && (whole===single || whole===single+single))return clean(maths[0].textContent);}
    let text=el.innerText || clone.textContent || '';
    el.querySelectorAll('[aria-live],[role="status"],.sr-only,.visually-hidden').forEach(n=>{if(n.textContent)text=text.replace(n.textContent,'');});
    return clean(text);
}"""


async def focus_drag_control(item):
    """A role=button wrapper may contain the actual keyboard handle."""
    return await item.evaluate("""el => {
        const canFocus = n => n && (n.hasAttribute('tabindex') ||
            /^(BUTTON|INPUT|SELECT|TEXTAREA|A)$/.test(n.tagName));
        const candidates = [el, ...el.querySelectorAll('[tabindex],button,input,select,textarea,a[href]')];
        const control = candidates.find(n => canFocus(n) && n.getClientRects().length &&
            !n.disabled && n.getAttribute('aria-disabled') !== 'true');
        if (!control) return false;
        control.focus({preventScroll:true});
        return control.getRootNode().activeElement === control;
    }""", timeout=1200)


async def drag_identity(item):
    return await item.evaluate("""el => {const textOf=__DRAG_TEXT__;return {
        text:textOf(el),
        cid:el.getAttribute('data-webqa-cid'),
        rfd:el.getAttribute('data-rfd-draggable-id') || el.getAttribute('data-rbd-draggable-id')
    }}""".replace('__DRAG_TEXT__',DRAG_TEXT_JS),timeout=1200)


async def drag_point(item, fraction=.5, dragging=None):
    """Use an exposed part of a tile, avoiding pinned footers and overlays."""
    point = await item.evaluate("""(el, {fraction,dragging}) => {
        const textOf=__DRAG_TEXT__;
        const r=el.getBoundingClientRect(),doc=el.ownerDocument,win=doc.defaultView;
        const previewSelector='[aria-grabbed="true"],[data-is-dragging="true"],.cdk-drag-preview,.gu-mirror,.ui-draggable-dragging';
        const isPreview = node => {
            if(!dragging)return false;
            const preview=node.closest?.(previewSelector);
            if(!preview)return false;
            const text=textOf(preview);
            return (dragging.cid && preview.getAttribute('data-webqa-cid')===dragging.cid) ||
                (dragging.rfd && (preview.getAttribute('data-rfd-draggable-id') || preview.getAttribute('data-rbd-draggable-id'))===dragging.rfd) ||
                (dragging.text && text===dragging.text);
        };
        const left=Math.max(r.left,0),right=Math.min(r.right,win.innerWidth);
        const top=Math.max(r.top,0),bottom=Math.min(r.bottom,win.innerHeight);
        if(right-left<4 || bottom-top<4)return null;
        for(const fy of [fraction,.5,.25,.75,.1,.9]) {
          for(const fx of [.5,.25,.75,.1,.9]) {
            const x=left+(right-left)*fx,y=top+(bottom-top)*fy;
            // A moving portal/clone may be above its destination and intercept
            // hit testing. Skip only this active tile's identifiable preview;
            // unrelated overlays still block the gesture. Never modify styles.
            const stack=el.getRootNode().elementsFromPoint?.(x,y) || doc.elementsFromPoint(x,y);
            const hit=stack.find(n=>!isPreview(n));
            if(hit && (hit===el || el.contains(hit)))return {x:x-r.left,y:y-r.top};
          }
        }
        return null;
    }""".replace('__DRAG_TEXT__',DRAG_TEXT_JS), {'fraction':fraction,'dragging':dragging}, timeout=1200)
    if point is None:
        raise ValueError('Drag control is covered or outside the visible page')
    box=await item.bounding_box(timeout=1200)
    if not box:
        raise ValueError('Drag control disappeared before the gesture')
    return box['x']+point['x'],box['y']+point['y']


async def current_order(frame):
    return await frame.locator('[data-webqa-order-item]').evaluate_all("""els => els
        .map(el=>({id:el.getAttribute('data-webqa-cid'),y:el.getBoundingClientRect().top}))
        .sort((a,b)=>a.y-b.y).map(x=>x.id)""")


async def held_drag_state(frame):
    return await frame.locator('[aria-grabbed="true"],[data-is-dragging="true"],.cdk-drag-preview,.gu-mirror').evaluate_all("""els => els
        .filter(el=>{const r=el.getBoundingClientRect();return r.width>0 && r.height>0 && getComputedStyle(el).visibility!=='hidden';})
        .map(el=>{const r=el.getBoundingClientRect();return [Math.round(r.left),Math.round(r.top),(el.innerText||'').trim()];})""")


async def wait_ordering_pickup(frame):
    until=asyncio.get_running_loop().time()+.9
    while asyncio.get_running_loop().time()<until:
        if await held_drag_state(frame):return
        await asyncio.sleep(.05)


async def move_ordering_key(page,frame,key):
    before=(await current_order(frame),await held_drag_state(frame))
    await page.keyboard.press(key)
    until=asyncio.get_running_loop().time()+.65
    previous=None
    stable=0
    while asyncio.get_running_loop().time()<until:
        state=(await current_order(frame),await held_drag_state(frame))
        stable=stable+1 if state==previous else 0
        if state!=before and stable>=2:return
        previous=state
        await asyncio.sleep(.05)


async def apply_ordering(page, frame, question, answers, match, refresh=False):
    if len(answers) != len(question.choices):
        raise ValueError('Ordering requires every item exactly once')
    desired=[match(answer,question.choices).cid for answer in answers]
    if len(set(desired)) != len(desired):
        raise ValueError('Duplicate ordering item')
    initial=await current_order(frame)
    if set(initial) != set(desired):
        raise ValueError('Ordering controls changed; rescan required')
    async def reread():
        if not refresh:
            return desired
        from mcgraw_adapter import extract_mcgraw_question
        found=[q for q in await extract_mcgraw_question(frame) if q.kind=='ordering']
        if len(found)!=1 or found[0].text!=question.text or len(found[0].choices)!=len(answers):
            raise ValueError('Ordering question changed while moving; rescan required')
        ids=[match(answer,found[0].choices).cid for answer in answers]
        if len(set(ids))!=len(ids):
            raise ValueError('Ordering choices became ambiguous')
        return ids
    for position in range(len(desired)):
        desired=await reread()
        cid=desired[position]
        current=await current_order(frame)
        index=current.index(cid)
        if index==position: continue
        item=frame.locator('[data-webqa-cid="'+cid+'"]')
        await item.scroll_into_view_if_needed(timeout=3000)
        focused=await focus_drag_control(item)
        if focused:
            try:
                await page.keyboard.press('Space')
                await wait_ordering_pickup(frame)
                for _ in range(abs(index-position)):
                    await move_ordering_key(page,frame,'ArrowUp' if index>position else 'ArrowDown')
                await page.keyboard.press('Space')
            except Exception:
                await page.keyboard.press('Escape')
        async def settled():
            nonlocal desired
            stable=0
            for _ in range(15):
                desired=await reread()
                now=await current_order(frame)
                held=await frame.locator('[aria-grabbed="true"]').count()
                if not held and now[:position+1]==desired[:position+1]:
                    stable+=1
                    if stable>=3:return True
                else:stable=0
                await asyncio.sleep(0.1)
            return False
        if not focused or not await settled():
            # Some widgets ignore keyboard pickup. Cancel any unfinished gesture,
            # reread positional IDs, then use actual mouse events on current tiles.
            await page.keyboard.press('Escape')
            desired=await reread()
            current=await current_order(frame)
            cid=desired[position]
            source=frame.locator('[data-webqa-cid="'+cid+'"]')
            target=frame.locator('[data-webqa-cid="'+current[position]+'"]')
            await source.scroll_into_view_if_needed(timeout=3000)
            x,y=await drag_point(source)
            identity=await drag_identity(source)
            print('  Ordering: keyboard did not persist; trying pointer movement.')
            await page.mouse.move(x,y)
            try:
                await page.mouse.down()
                await page.mouse.move(x,y-12,steps=4)
                await asyncio.sleep(0.2)
                # Scrolling the source into view can hide a distant destination.
                # Recompute its viewport coordinates during the active gesture.
                await target.scroll_into_view_if_needed(timeout=3000)
                tx,ty=await drag_point(target,.2 if current.index(cid)>position else .8,dragging=identity)
                await page.mouse.move(tx,ty,steps=24)
                await asyncio.sleep(0.3)
            finally:
                await page.mouse.up()
            if not await settled():
                await page.keyboard.press('Escape')
                raise ValueError('Ordering movement did not persist after keyboard and pointer; submission stopped')
    if await current_order(frame)!=desired or await frame.locator('[aria-grabbed="true"]').count():
        raise ValueError('Final ordering does not match requested answer')
