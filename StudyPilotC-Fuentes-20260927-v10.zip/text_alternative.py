"""Read only the popup opened by the question's Text Alternative control."""
import asyncio
import re
from mcgraw_actions import allowed_mcgraw


async def has_text_alternative(frame):
    links = frame.get_by_role('link', name=re.compile(r'^Text Alternative$', re.I))
    return any([await links.nth(i).is_visible() for i in range(await links.count())])


def description_only(content):
    lines = content.strip().splitlines()
    if lines and re.search(r'text alternative\s*$', lines[0], re.I):
        lines = lines[1:]
    return '\n'.join(lines).strip()


async def read_text_alternative(page, frame):
    if not allowed_mcgraw(page) or not allowed_mcgraw(frame):
        return ''
    controls = frame.get_by_role('link', name=re.compile(r'^Text Alternative$',re.I))
    links = [controls.nth(i) for i in range(await controls.count()) if await controls.nth(i).is_visible()]
    if len(links) != 1:
        print('Text Alternative missing or ambiguous.')
        return ''
    popup = None
    opened = []
    # A named window may be reused without emitting another popup event.
    # Only inspect existing description windows opened by this question page.
    previous = {}
    for child in page.context.pages:
        try:
            if child != page and await child.opener() == page and re.search(
                    r'text alternative', await child.title(), re.I):
                previous[child] = await child.locator('body').inner_text(timeout=1500)
        except Exception:
            continue
    def on_popup(child): opened.append(child)
    page.on('popup',on_popup)
    try:
        await links[0].click(timeout=3000)
        for _ in range(50):
            if opened:
                popup = opened[0]
                break
            for child, old_text in previous.items():
                if not child.is_closed():
                    new_text = await child.locator('body').inner_text(timeout=1500)
                    if new_text != old_text:
                        popup = child
                        break
            if popup is not None:
                break
            await asyncio.sleep(0.1)
        if popup is None:
            print('Text Alternative did not open or update a description tab.')
            return ''
        # about:blank is legitimate here: McGraw writes the description into
        # its own popup. The popup event binds it to this particular click.
        for _ in range(50):
            if popup.is_closed():
                return ''
            if popup.url != 'about:blank' and not allowed_mcgraw(popup):
                print('Text Alternative redirected outside McGraw.')
                return ''
            content = description_only(await popup.locator('body').inner_text(timeout=1500))
            if len(content) >= 35:
                print(f'Text Alternative read ({len(content)} characters).')
                return content[:16000]
            await asyncio.sleep(0.1)
    except Exception as exc:
        print(f'Text Alternative could not be read: {exc}')
    finally:
        page.remove_listener('popup',on_popup)
        # Never close pre-existing or unrelated tabs.
        for child in opened:
            if not child.is_closed():
                await child.close()
        if not page.is_closed():
            await page.bring_to_front()
    return ''
