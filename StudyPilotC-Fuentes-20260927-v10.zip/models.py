\
from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class Choice:
    cid: str
    text: str
    control_type: str
    checked: bool = False
    value: str = ""

@dataclass
class Question:
    qid: str
    text: str
    kind: str
    choices: List[Choice] = field(default_factory=list)
    has_visual: bool = False
    html_hint: str = ""

@dataclass
class Answer:
    qid: str
    answer_type: str
    answers: List[str]
    confidence: float
    explanation: str = ""
