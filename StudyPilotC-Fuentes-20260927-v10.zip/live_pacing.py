"""Atomic UI-to-engine pacing updates, independent of pause/recovery commands."""
import asyncio
import json
import math
from pathlib import Path


def values(mode, seconds, minutes, questions):
    questions=int(questions)
    if not 1<=questions<=1000: raise ValueError('Usa entre 1 y 1000 preguntas estimadas.')
    if mode=='Por pregunta':
        seconds=float(seconds)
        if not math.isfinite(seconds) or not 0<=seconds<=3600: raise ValueError('Usa entre 0 y 3600 segundos por pregunta.')
        minutes=seconds*questions/60
    else:minutes=float(minutes)
    if not math.isfinite(minutes) or not 0<=minutes<=1440:raise ValueError('La duración estimada debe estar entre 0 y 1440 minutos.')
    return {'minutes':minutes,'questions':questions}


def write_update(control, data):
    path=Path(control).with_name('pacing.json')
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data),encoding='utf-8');temporary.replace(path)


async def watch_updates(control, apply):
    path=Path(control).with_name('pacing.json');last=None
    while True:
        try:
            raw=path.read_text(encoding='utf-8')
            if raw!=last:
                data=json.loads(raw)
                validated=values('Total','0',data['minutes'],data['questions'])
                apply(validated);last=raw
        except (OSError,ValueError,KeyError,TypeError):pass
        await asyncio.sleep(.25)
