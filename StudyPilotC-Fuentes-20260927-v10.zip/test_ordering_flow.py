import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from dataclasses import replace
from playwright.async_api import async_playwright
import app
from models import Answer


class OrderingFlow(unittest.IsolatedAsyncioTestCase):
    async def test_reorder_and_already_correct_both_advance(self):
        html='''<meta charset="utf-8"><main id="app"></main><script>
        let order=INITIAL;let held=null;window.moves=0;
        function render(){document.querySelector('#app').innerHTML='<h1>Ordering Question</h1><p>Click and drag on elements in order</p><p>Rank polysaccharides from most branched to least branched.</p><div id="list">'+order.map((x,i)=>'<div role="button" tabindex="0" aria-grabbed="false" aria-label="Choice '+(i+1)+' of 3. '+x+'" data-label="'+x+'" style="width:700px;height:80px"><span>Choice '+(i+1)+' of 3. '+x+' toggle button</span><p>'+x+'</p></div>').join('')+'</div><p>Need help? Review resources.</p><button id="confidence">Medium</button>';
        document.querySelector('#confidence').onclick=()=>{document.querySelector('#app').innerHTML='<h1>Your Answer correct</h1><button id="next">Next Question</button>';document.querySelector('#next').onclick=()=>document.querySelector('#app').innerHTML='<h1>Next question loaded</h1>';};}
        document.addEventListener('keydown',e=>{const tile=e.target.closest('[data-label]');if(!tile)return;e.preventDefault();
        if(e.code==='Space'){if(held){held=null;render();}else held=tile.dataset.label;}
        if(held && e.code==='ArrowUp'){const i=order.indexOf(held);if(i>0){[order[i-1],order[i]]=[order[i],order[i-1]];window.moves++;}}
        });render();</script>'''
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                for initial, pointer_only in [(['Cellulose','Starch','Glycogen'],False),(['Glycogen','Starch','Cellulose'],False),(['Starch','Glycogen','Cellulose'],True)]:
                    with self.subTest(initial=initial,pointer_only=pointer_only):
                        page=await browser.new_page(viewport={'width':1200,'height':900})
                        import json
                        await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body=html.replace('INITIAL',json.dumps(initial))))
                        await page.goto('https://learning.mheducation.com/test')
                        if pointer_only:
                            await page.evaluate("""() => {
                                document.addEventListener('keydown',e=>e.stopImmediatePropagation(),true);
                                let moving=null;
                                document.addEventListener('mousedown',e=>{moving=e.target.closest('[data-label]')?.dataset.label;});
                                document.addEventListener('mouseup',e=>{
                                    const destination=e.target.closest('[data-label]')?.dataset.label;
                                    if(moving && destination && moving!==destination){
                                        const at=order.indexOf(destination);
                                        order.splice(order.indexOf(moving),1);
                                        order.splice(at,0,moving);window.moves++;render();
                                    }
                                    moving=null;
                                });
                            }""")
                        solver=SimpleNamespace(solve=AsyncMock(return_value=Answer('mcgraw-ordering','ordering',['Glycogen','Starch','Cellulose'],1.0)))
                        with patch.object(app,'settings',replace(app.settings,pacing_minutes=0,mode='fill',mcgraw_auto=True,mcgraw_confidence='Medium')),patch('drag_diagnostics.save_drag_diagnostic',new=AsyncMock()):
                            await app.analyze_page(page,solver,{})
                            self.assertEqual(await page.evaluate('order'),['Glycogen','Starch','Cellulose'])
                            self.assertIn('Your Answer correct',await page.locator('body').inner_text())
                            await app.analyze_page(page,solver,{})
                        self.assertIn('Next question loaded',await page.locator('body').inner_text())
                        if initial[0]=='Glycogen':self.assertEqual(await page.evaluate('window.moves'),0)
                        await page.close()
            finally:await browser.close()

if __name__=='__main__':unittest.main()
