import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock,patch
from text_alternative import description_only
import visual_question as visual

class Tests(unittest.IsolatedAsyncioTestCase):
    async def test_description_precedes_even_high_confidence_answer(self):
        solver=NS(solve=AsyncMock(return_value=NS(confidence=1.0)))
        with patch.object(visual,'read_text_alternative',return_value='Four fused rings.') as read:
            answer,description=await visual.solve_with_visual_evidence(None,None,'q',solver,b'image',False,True,0.6)
        read.assert_awaited_once()
        self.assertEqual(solver.solve.call_args.kwargs['text_alternative'],'Four fused rings.')
        self.assertEqual(description,'Four fused rings.')
    async def test_missing_expected_description_stops_solver(self):
        solver=NS(solve=AsyncMock())
        with patch.object(visual,'read_text_alternative',return_value=''):
            answer,_=await visual.solve_with_visual_evidence(None,None,'q',solver,None,True,True,0.6)
        self.assertIsNone(answer);solver.solve.assert_not_awaited()
    async def test_failed_screenshot_can_use_description(self):
        solver=NS(solve=AsyncMock(return_value=NS(confidence=0.9)))
        with patch.object(visual,'read_text_alternative',return_value='Different covalent connectivity.'):
            answer,_=await visual.solve_with_visual_evidence(None,None,'q',solver,None,True,True,0.6)
        self.assertEqual(answer.confidence,0.9)
    def test_title_is_not_a_description(self):
        self.assertEqual(description_only('very_long_image_name.jpg Text Alternative\n'),'')
        self.assertEqual(description_only('image.jpg Text Alternative\n\nFour rings are fused.'),'Four rings are fused.')

if __name__=='__main__':unittest.main()
