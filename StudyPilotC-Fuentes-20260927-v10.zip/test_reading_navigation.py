import asyncio
import json
import unittest
from unittest.mock import patch

from playwright.async_api import async_playwright

import mcgraw_actions as actions
import reading_navigation as nav
from test_question_resources import QUESTION, READING_TEXT


class ReadingNavigation(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.context=await self.browser.new_context()
        self.documents={}
        async def route(request):
            await request.fulfill(content_type='text/html',body=self.documents.get(request.request.url,'<p>Isolated fixture</p>'))
        await self.context.route('**/*',route)
        self.page=await self.context.new_page()
        self.url='https://learning.mheducation.com/test-reading-activity'
        self.documents[self.url]=QUESTION
        await self.page.goto(self.url)

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def test_delayed_back_does_not_trigger_repeated_click_or_reload(self):
        feedback='<h1>Your Answer incorrect</h1><button onclick="window.nextClicks=(window.nextClicks||0)+1">Next Question</button>'
        await self.page.set_content(feedback)
        origin=await nav.checkpoint(self.page)
        origin['started']-=8
        await self.page.set_content('<button onclick="window.backClicks=(window.backClicks||0)+1;setTimeout(()=>document.body.innerHTML=window.feedback,700)">Back to Questions</button><article>'+READING_TEXT+'</article>')
        await self.page.evaluate('(html)=>window.feedback=html',feedback)
        state={'phase':'reading','last':0,'attempts':0,'reading_origin':origin}
        actions._feedback_navigation[self.page]=state
        with patch.object(self.page,'goto',wraps=self.page.goto) as goto,patch.object(self.page,'go_back',wraps=self.page.go_back) as history:
            await actions.handle_feedback(self.page)
            state['last']=0
            await actions.handle_feedback(self.page)
            self.assertEqual(await self.page.evaluate('window.backClicks'),1)
            goto.assert_not_awaited();history.assert_not_awaited()
            await self.page.get_by_role('button',name='Next Question').wait_for(state='visible')
            state['last']=0
            self.assertIn('Next Question clicked',await actions.handle_feedback(self.page))
            self.assertEqual(await self.page.evaluate('window.nextClicks'),1)
            goto.assert_not_awaited()

    async def test_owned_reading_popup_returns_without_closing_unrelated_tab(self):
        reader='https://learning.mheducation.com/test-reader-popup'
        self.documents[reader]='<article>'+READING_TEXT+'</article>'
        unrelated=await self.context.new_page()
        await unrelated.goto('https://learning.mheducation.com/test-unrelated')
        html='<h1>Your Answer incorrect</h1><p id="required">You must review a resource</p><button id="read">Reading</button><button id="next" disabled onclick="window.nextClicks=(window.nextClicks||0)+1">Next Question</button>'
        await self.page.set_content(html)
        await self.page.evaluate('(url)=>document.querySelector("#read").onclick=()=>{window.open(url,"_blank");document.querySelector("#required").remove();document.querySelector("#next").disabled=false}',reader)
        async with self.page.expect_popup() as popup_info:
            self.assertIn('opening',await actions.handle_feedback(self.page))
        popup=await popup_info.value
        await popup.get_by_text(READING_TEXT,exact=True).wait_for(state='visible')
        self.assertIs(nav.reading_owner(popup),self.page)
        self.assertIs(nav.reading_owner(unrelated),unrelated)
        state=actions._feedback_navigation[self.page];state['last']=0
        self.assertIn('popup closed',await actions.handle_feedback(self.page))
        self.assertTrue(popup.is_closed());self.assertFalse(unrelated.is_closed())
        state['last']=0
        self.assertIn('Next Question clicked',await actions.handle_feedback(self.page))
        self.assertEqual(await self.page.evaluate('window.nextClicks'),1)

    async def test_iframe_reader_fallback_restores_child_without_reloading_parent(self):
        activity='https://learning.mheducation.com/test-frame-activity'
        reader='https://learning.mheducation.com/test-frame-reader'
        self.documents[activity]=QUESTION
        self.documents[reader]='<article>'+READING_TEXT+'</article>'
        await self.page.set_content('<h1>Study shell</h1><iframe src="'+activity+'"></iframe>')
        frame=self.page.frames[-1]
        await frame.get_by_text('Multiple Choice Question',exact=True).wait_for(state='visible')
        origin=await nav.checkpoint(self.page);origin['started']-=8
        await frame.goto(reader)
        with patch.object(self.page,'goto',wraps=self.page.goto) as goto,patch.object(self.page,'reload',wraps=self.page.reload) as reload:
            self.assertTrue(await nav.fallback_return(self.page,origin))
            await frame.get_by_text('Multiple Choice Question',exact=True).wait_for(state='visible')
            goto.assert_not_awaited();reload.assert_not_awaited()
        self.assertEqual(self.page.url,self.url)
        self.assertEqual(frame.url,activity)

    async def test_later_unrelated_popup_is_not_claimed_by_stale_checkpoint(self):
        origin=await nav.checkpoint(self.page)
        origin['capture_until']-=6
        async with self.page.expect_popup() as popup_info:
            await self.page.evaluate('window.open("https://learning.mheducation.com/test-later", "_blank")')
        popup=await popup_info.value
        self.assertIs(nav.reading_owner(popup),popup)
        self.assertEqual(nav.owned_popups(origin),[])
        self.assertFalse(await nav.return_owned_popup(self.page,origin))
        self.assertFalse(popup.is_closed())

    async def test_history_return_waits_for_delayed_spa_render(self):
        origin=await nav.checkpoint(self.page);origin['started']-=8
        await self.page.evaluate('(question)=>{window.original=question;history.pushState({},"","#reader");document.body.innerHTML="<article>Reading resource</article>";addEventListener("popstate",()=>setTimeout(()=>document.body.innerHTML=window.original,650))}',QUESTION)
        with patch.object(self.page,'goto',wraps=self.page.goto) as goto:
            self.assertTrue(await nav.fallback_return(self.page,origin))
            self.assertFalse(await nav.fallback_return(self.page,origin))
            goto.assert_not_awaited()
            await self.page.get_by_text('Multiple Choice Question',exact=True).wait_for(state='visible')
            self.assertTrue(await nav.returned_to_activity(self.page,origin))

    async def test_required_message_lag_does_not_reopen_reading_each_cycle(self):
        await self.page.set_content('<h1>Your Answer incorrect</h1><p>You must review a resource</p><button onclick="window.reads=(window.reads||0)+1">Reading</button><button disabled>Next Question</button>')
        import time
        state={'phase':'feedback','last':0,'attempts':0,'reviewed':True,'returned_at':time.monotonic(),'review_visits':1}
        actions._feedback_navigation[self.page]=state
        for _ in range(4):
            self.assertIn('waiting for McGraw',await actions.handle_feedback(self.page))
        self.assertIsNone(await self.page.evaluate('window.reads'))

    async def test_screen_state_question_heading_excludes_hidden_and_overlay_titles(self):
        await self.page.set_content('<h1>Reading</h1><h2 hidden>Matching Question</h2><div id="webqa-overlay"><h2>Ordering Question</h2></div>')
        self.assertFalse((await actions.screen_state(self.page))['question'])
        await self.page.set_content('<h2>Matching Question</h2><p>Loading controls…</p>')
        self.assertTrue((await actions.screen_state(self.page))['question'])

    async def test_next_and_required_review_retry_after_cooldown(self):
        import time
        await self.page.set_content('<h1>Your Answer incorrect</h1><button onclick="window.nextClicks=(window.nextClicks||0)+1">Next Question</button>')
        state={'phase':'next','last':time.monotonic()-3,'attempts':3}
        actions._feedback_navigation[self.page]=state
        self.assertIn('waiting before retrying',await actions.handle_feedback(self.page))
        self.assertIsNone(await self.page.evaluate('window.nextClicks'))
        state['last']-=31
        self.assertIn('Next Question clicked',await actions.handle_feedback(self.page))
        self.assertEqual(await self.page.evaluate('window.nextClicks'),1)
        await self.page.set_content('<h1>Your Answer incorrect</h1><p>You must review a resource</p><button onclick="window.reads=(window.reads||0)+1">Reading</button>')
        state={'phase':'feedback','last':0,'attempts':0,'reviewed':True,'returned_at':time.monotonic(),'review_visits':2}
        actions._feedback_navigation[self.page]=state
        self.assertIn('waiting for McGraw',await actions.handle_feedback(self.page))
        self.assertIsNone(await self.page.evaluate('window.reads'))
        state['returned_at']-=31
        self.assertIn('opening',await actions.handle_feedback(self.page))
        self.assertEqual(await self.page.evaluate('window.reads'),1)


if __name__=='__main__':unittest.main()
