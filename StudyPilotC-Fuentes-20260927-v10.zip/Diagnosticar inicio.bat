@echo off
setlocal
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
chcp 65001 >nul
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" diagnosticar_inicio.py
  goto finish
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 diagnosticar_inicio.py
  goto finish
)
where python >nul 2>nul
if not errorlevel 1 (
  python diagnosticar_inicio.py
  goto finish
)
echo BLOQUEO: no se encontro Python. Instala Python 3.11 o superior.
echo Luego ejecuta "Instalar Study Pilot C.bat".
:finish
pause
