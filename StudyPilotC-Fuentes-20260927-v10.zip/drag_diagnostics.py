"""Keep the last failed interaction's controls locally, without page credentials."""
import json
from datetime import datetime, timezone
from pathlib import Path
import re
import tempfile

from runtime_paths import APP_DIR, DATA_DIR


def _safe_text(value):
    """Keep interaction evidence while excluding bearer secrets and URLs."""
    value = str(value)
    value = re.sub(r"https?://[^\s\"'<>]+", '[URL omitted]', value, flags=re.I)
    value = re.sub(r'\b(?:sk-(?:proj-|svcacct-)?|spc_)[A-Za-z0-9_-]{20,}', '[secret omitted]', value)
    value = re.sub(r'\bBearer\s+[^\s\"\'<>]+', 'Bearer [secret omitted]', value, flags=re.I)
    return value[:4000]


def _sanitize(value):
    if isinstance(value, str):
        return _safe_text(value)
    if isinstance(value, list):
        return [_sanitize(item) for item in value]
    if isinstance(value, dict):
        return {key: _sanitize(item) for key, item in value.items()}
    return value


async def save_drag_diagnostic(frame, question, answers, error):
    temporary = None
    try:
        controls = await frame.locator('[data-webqa-cid],[data-webqa-match-target]').evaluate_all('''els => els.map(el=>({
      cid:el.getAttribute('data-webqa-cid'),target:el.getAttribute('data-webqa-match-target'),
      tag:el.tagName,role:el.getAttribute('role'),label:el.getAttribute('aria-label'),
      text:(el.innerText||'').slice(0,1200),rawText:(el.textContent||'').slice(0,1200),
      draggable:el.getAttribute('draggable'),grabbed:el.getAttribute('aria-grabbed'),
      math:[...el.querySelectorAll('math')].map(m=>m.textContent.slice(0,400)),
      rect:{x:el.getBoundingClientRect().x,y:el.getBoundingClientRect().y,
            width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height}
    })).slice(0,80)''')
        version = APP_DIR.name if re.fullmatch(r'\d{4}\.\d{2}\.\d{2}\.\d+(?:-[a-f0-9]+)?', APP_DIR.name) else 'source'
        report = _sanitize({
            'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
            'runtime_version': version,
            'error': str(error), 'question': question.text, 'answers': answers,
            'choices': [{'cid': c.cid, 'text': c.text} for c in question.choices],
            'controls': controls,
        })
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        path = DATA_DIR / 'last_drag_failure.json'
        # Replace only complete reports, including when the process is interrupted.
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=DATA_DIR,
                                         prefix='drag-report-', suffix='.tmp', delete=False) as stream:
            temporary = stream.name
            json.dump(report, stream, ensure_ascii=False, indent=2)
        Path(temporary).replace(path)
        temporary = None
        print(f'Drag diagnostic saved: {path.name}')
        return True
    except Exception:
        # Diagnostics must not interrupt recovery or echo a credential-bearing exception.
        print('Drag diagnostic unavailable; interaction recovery will continue.')
        return False
    finally:
        if temporary:
            try:
                Path(temporary).unlink(missing_ok=True)
            except OSError:
                pass
