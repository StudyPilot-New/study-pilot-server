"""Capture a question plus readable, loaded figure details (never the overlay)."""
import json
import base64
import hashlib

SCOPE_JS = '''root => {
  const figure = el => [...el.querySelectorAll('img,canvas,svg')].some(x => {
    const r=x.getBoundingClientRect(); return r.width>=100 && r.height>=80 &&
      !x.closest('#webqa-overlay,header,nav');
  });
  let el=root;
  while (!figure(el) && el.parentElement && el.parentElement!==document.body)
    el=el.parentElement;
  return el;
}'''


async def enrich_visual_identity(frame, question):
    """Include changing figures for every question type, not only radio choices."""
    root = frame.locator('[data-webqa-qid=' + json.dumps(question.qid) + ']').first
    if not await root.count():
        return
    scope = await root.evaluate_handle(SCOPE_JS)
    try:
        identities = await scope.evaluate('''el => [...el.querySelectorAll('img,canvas,svg')]
          .filter(x => {const r=x.getBoundingClientRect();return r.width>=100 && r.height>=80 &&
            !x.closest('#webqa-overlay,header,nav') && getComputedStyle(x).visibility!=='hidden';})
          .map(x => {
            if(x.tagName==='IMG') return [x.currentSrc || x.src,x.alt];
            if(x.tagName==='CANVAS') {try{return x.toDataURL();}catch{return ['canvas',x.width,x.height];}}
            return x.outerHTML;
          })''')
        if identities:
            question.has_visual = True
            digest = hashlib.sha256(json.dumps(identities).encode()).hexdigest()
            question.html_hint = question.html_hint.split('|figure:',1)[0] + '|figure:' + digest
    finally:
        await scope.dispose()


async def capture_visual(frame, qid):
    root = frame.locator('[data-webqa-qid=' + json.dumps(qid) + ']').first
    await root.scroll_into_view_if_needed()
    # The figure can be a sibling of the question, in the left column.
    scope = await root.evaluate_handle(SCOPE_JS)
    try:
        figures = await scope.as_element().query_selector_all('img,canvas,svg')
        eligible = []
        for figure in figures:
            if await figure.evaluate('''x => {
              const r=x.getBoundingClientRect(); return r.width>=100 && r.height>=80 &&
                getComputedStyle(x).visibility!=='hidden' &&
                !x.closest('#webqa-overlay,header,nav');
            }'''):
                eligible.append(figure)
        if len(eligible)>8:
            raise ValueError('Too many figures to associate with this question safely.')
        images=[]
        for figure in eligible:
            await figure.scroll_into_view_if_needed()
            if await figure.evaluate("x => x.tagName==='IMG'"):
                await figure.evaluate('''async x => {
                  await Promise.race([x.decode(),new Promise((_,reject)=>
                    setTimeout(()=>reject(Error('Figure did not load')),5000))]);
                  if(!x.naturalWidth) throw Error('Empty figure');
                }''')
                # Preserve native resolution where the browser permits pixel
                # access. Cross-origin images still use the screenshot fallback.
                native = await figure.evaluate('''x => {
                  if(x.naturalWidth*x.naturalHeight>16000000) return null;
                  try {const c=document.createElement('canvas');
                    c.width=x.naturalWidth;c.height=x.naturalHeight;
                    c.getContext('2d').drawImage(x,0,0);return c.toDataURL('image/png');
                  } catch {return null;}
                }''')
                if native:
                    images.append(base64.b64decode(native.split(',',1)[1]))
                    continue
            images.append(await figure.screenshot(type='png',
                style='#webqa-overlay { visibility:hidden !important; }'))
        # Prompt and choices are already supplied as text. Detail crops avoid
        # shrinking thin bonds inside a large screenshot of whitespace.
        if not images:
            images=[await root.screenshot(type='png',
                style='#webqa-overlay { visibility:hidden !important; }')]
        print(f'Visual capture: {len(images)} image(s), {sum(map(len,images))} bytes.')
        return images
    finally:
        await scope.dispose()
