"""Skippable first-run guide and shared access activation."""
import queue
import threading
import tkinter as tk
from tkinter import ttk
from guide_visuals import draw
from shared_access import shared_mode, load_access, save_access, server_url, validate_token

STEPS = [
    ('01 · Entra en tu cuenta', 'Abre Mi cuenta y entra con tu correo y contraseña. Si aún no tienes cuenta, pulsa Crear cuenta / Ver pagos.\n\nEn la web puedes activar una prueba de 20 análisis durante 48 horas, una vez por cuenta. No necesitas tarjeta ni API key. Los reintentos también consumen análisis.\n\nEspera el mensaje Acceso activo antes de abrir la actividad.'),
    ('02 · Instala y abre', 'Descarga el instalador desde la web. Pulsa Instalar y abre Study Pilot C desde el acceso directo. Python ya está incluido; necesitas Windows y Google Chrome instalado.\n\nSi ya estás leyendo esta guía dentro de la app, este paso está completo. Pulsa Abrir actividad para abrir el Chrome de Study Pilot.'),
    ('03 · Abre tu actividad en este Chrome', 'En tu navegador habitual, copia el enlace de la actividad desde Canvas o el portal de tu universidad.\n\nPégalo en la barra de direcciones del NUEVO Chrome de Study Pilot y pulsa Enter. Inicia sesión en tu universidad y abre las preguntas. Este Chrome usa un perfil separado; es normal tener que iniciar sesión otra vez.\n\nUsa el enlace de Canvas si la actividad necesita ese acceso, en lugar de copiar solo el enlace interno de McGraw.'),
    ('04 · Elige tu ritmo', 'En Actividad ajusta los segundos por pregunta. Puedes cambiarlos mientras la sesión está en marcha.\n\nPor ejemplo: 180 preguntas a 40 segundos son unas 2 horas. Es una estimación: el análisis, las preguntas adicionales y los reintentos pueden alargarla.\n\nComprueba el estado y revisa las respuestas: la IA puede equivocarse. Puedes pausar o detener cuando quieras.'),
    ('05 · Si necesitas ayuda', 'Si Chrome muestra la pantalla de bienvenida, aún falta pegar el enlace de tu actividad en su barra de direcciones.\n\nSi no puedes entrar, ve a Mi cuenta y comprueba el mensaje: acceso activo, pendiente o vencido. La prueba termina a las 48 horas o al consumir 20 análisis.\n\nSi una actividad se atasca, pulsa Recuperar en la app. Si persiste, guarda el mensaje del registro. La compatibilidad depende de cada actividad; una recarga no resuelve errores de acceso o de saldo.')
]


def build_guide(app, notebook):
    frame = app.guide_tab = tk.Frame(notebook, bg='white', padx=22, pady=18)
    notebook.add(frame, text='Guía de inicio')
    controls=tk.Frame(frame,bg='white');controls.pack(side='bottom',fill='x',pady=(12,0))
    canvas=tk.Canvas(frame,bg='white',highlightthickness=0)
    scroll=ttk.Scrollbar(frame,command=canvas.yview);scroll.pack(side='right',fill='y')
    canvas.pack(fill='both',expand=True);canvas.configure(yscrollcommand=scroll.set)
    content=tk.Frame(canvas,bg='white')
    window=canvas.create_window((0,0),window=content,anchor='nw')
    content.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
    canvas.bind('<Configure>',lambda e:canvas.itemconfigure(window,width=e.width))
    title=tk.StringVar(); progress=tk.StringVar()
    app.label(content,'EMPIEZA AQUÍ',9,'#087f73',True).pack(anchor='w')
    tk.Label(content,textvariable=title,bg='white',fg='#162b3c',font=('Segoe UI',17,'bold'),anchor='w').pack(fill='x',pady=(8,12))
    illustration=tk.Canvas(content,height=280,bg='#f2f7f8',highlightthickness=0)
    illustration.pack(fill='x',pady=(0,16))
    body=tk.Text(content,wrap='word',font=('Segoe UI',11),bg='white',fg='#334b60',relief='flat',height=12,padx=0,pady=4)
    body.pack(fill='both',expand=True)
    conn=tk.Frame(content,bg='white')
    url=tk.StringVar(); token=tk.StringVar(); status=tk.StringVar()
    app.access_status=status
    if shared_mode():
        try:
            u,t=load_access();url.set(u);token.set(t);status.set('Acceso configurado en este equipo.')
        except ValueError:status.set('Introduce los datos de tu administrador.')
        for label,var,mask in [('URL HTTPS del servidor',url,''),('Código individual spc_',token,'•')]:
            app.label(conn,label,9).pack(anchor='w')
            app.entry(conn,var,show=mask).pack(fill='x',ipady=4,pady=(3,6))
        results=queue.Queue()
        def activate():
            try:u=server_url(url.get());t=validate_token(token.get().strip())
            except ValueError as exc:status.set(str(exc));return
            activate_button['state']='disabled';status.set('Comprobando acceso…')
            def check():
                try:
                    import httpx
                    with httpx.Client(timeout=15,follow_redirects=False) as client:
                        response=client.get(u+'/access',headers={'Authorization':'Bearer '+t})
                    data=response.json() if response.status_code==200 else {}
                    if data.get('service')!='study-pilot-c' or not data.get('active'):
                        raise ValueError('El servidor no confirmó el acceso. Comprueba la URL y el código.')
                    save_access(u,t)
                    results.put('Acceso activado. Ya puedes iniciar sesión.')
                except Exception:
                    results.put('No se pudo activar. Comprueba la URL, el código y la conexión con tu administrador.')
            threading.Thread(target=check,daemon=True).start()
            def finish():
                try:message=results.get_nowait()
                except queue.Empty:frame.after(100,finish);return
                status.set(message);activate_button['state']='normal'
            frame.after(100,finish)
        activate_button=app.button(conn,'Activar acceso',activate,True)
        activate_button.pack(anchor='w',pady=4)
        tk.Label(conn,textvariable=status,bg='white',fg='#536579',wraplength=600,justify='left').pack(anchor='w')
    current=[0]
    def render_picture(event=None):
        width=min(800,max(260,illustration.winfo_width()))
        illustration.configure(height=width/2)
        illustration.delete('all')
        draw(illustration,[0,1,2,3,3][current[0]],width)
    illustration.bind('<Configure>',render_picture)
    def show(delta=0):
        current[0]=max(0,min(len(STEPS)-1,current[0]+delta))
        name,text=STEPS[current[0]];title.set(name);progress.set(f'{current[0]+1} / {len(STEPS)}')
        body['state']='normal';body.delete('1.0','end');body.insert('1.0',text);body['state']='disabled'
        previous['state']='normal' if current[0] else 'disabled'
        following['state']='normal' if current[0]<len(STEPS)-1 else 'disabled'
        canvas.yview_moveto(0)
        render_picture()
        conn.pack_forget()
    previous=app.button(controls,'Anterior',lambda:show(-1));previous.pack(side='left')
    following=app.button(controls,'Siguiente',lambda:show(1),True);following.pack(side='left',padx=8)
    tk.Label(controls,textvariable=progress,bg='white',fg='#536579').pack(side='left',padx=6)
    app.button(controls,'Mi cuenta' if shared_mode() else 'Ir a ajustes',lambda:notebook.select(app.account_tab if shared_mode() else app.settings_tab)).pack(side='right')
    show()
