import unittest
from unittest.mock import AsyncMock, patch
from playwright.async_api import async_playwright
import reading_navigation as nav
import recovery
import mcgraw_actions as actions
import question_resources as resources
from test_question_resources import QUESTION, READING_TEXT


class BrowserRecovery(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page()
        self.url='https://learning.mheducation.com/test-recovery'
        await self.page.route(self.url,lambda r:r.fulfill(content_type='text/html',body=QUESTION))
        await self.page.goto(self.url)
    async def asyncTearDown(self):
        await self.browser.close();await self.pw.stop()

    async def test_icon_only_return_is_recognized_and_restores_question(self):
        import json
        original=await resources._question_signature(self.page)
        resources._pending_returns[self.page]={'original':original,'last_click':0,'context':READING_TEXT,'navigation':await nav.checkpoint(self.page)}
        await self.page.set_content('<button title="Back to assignment" onclick="document.body.innerHTML=window.question">↩</button><article>'+READING_TEXT+'</article>')
        await self.page.evaluate('(s)=>window.question=s',QUESTION)
        self.assertTrue(await resources.restore_question_resource(self.page))
        self.assertNotIn(self.page,resources._pending_returns)
        self.assertEqual(await resources.consume_question_resource(self.page),READING_TEXT)

    async def test_missing_return_recovers_captured_url_once(self):
        state=await nav.checkpoint(self.page);state['started']-=7
        await self.page.set_content('<article>'+READING_TEXT+'</article>')
        self.assertTrue(await nav.fallback_return(self.page,state))
        self.assertIn('Multiple Choice',await self.page.inner_text('body'))
        self.assertFalse(await nav.fallback_return(self.page,state))

    async def test_history_back_precedes_reload(self):
        state=await nav.checkpoint(self.page);state['started']-=4
        await self.page.evaluate("history.pushState({},'', '#reader')")
        self.assertTrue(await nav.fallback_return(self.page,state))
        self.assertEqual(self.page.url,self.url)
        self.assertFalse(state['reload_used'])

    async def test_broken_back_button_cannot_trap_feedback_navigation(self):
        await self.page.set_content('<button onclick="window.clicks=(window.clicks||0)+1">Back to Questions</button><article>'+READING_TEXT+'</article>')
        origin=await nav.checkpoint(self.page);origin['started']-=7
        actions._feedback_navigation[self.page]={'phase':'reading','last':0,'attempts':0,'reading_origin':origin}
        await actions.handle_feedback(self.page)
        actions._feedback_navigation[self.page]['last']=0
        await actions.handle_feedback(self.page)
        self.assertEqual(await self.page.evaluate('window.clicks'),1)
        self.assertIn('Back to Questions',await self.page.inner_text('body'))
        for _ in range(2):
            actions._feedback_navigation[self.page]['last']=0
            origin['last_return']-=5
            await actions.handle_feedback(self.page)
        self.assertIn('Multiple Choice',await self.page.inner_text('body'))
        self.assertEqual(actions._feedback_navigation[self.page]['phase'],'feedback')
        actions._feedback_navigation[self.page]['last']=0
        self.assertEqual(await actions.handle_feedback(self.page),'')

    async def test_recovery_is_bounded_and_does_not_submit(self):
        with patch.object(self.page,'reload',wraps=self.page.reload) as reload:
            self.assertTrue(await recovery.recover_page(self.page,'same-question'))
            reload.assert_not_awaited()  # First cancel the gesture without flashing.
            self.assertFalse(await recovery.recover_page(self.page,'same-question'))
            recovery._resets[self.page]['last']-=16
            self.assertTrue(await recovery.recover_page(self.page,'same-question'))
            recovery._resets[self.page]['last']-=16
            self.assertTrue(await recovery.recover_page(self.page,'same-question'))
            recovery._resets[self.page]['last']-=16
            with patch.object(actions,'resume_interactions',wraps=actions.resume_interactions) as resume:
                self.assertTrue(await recovery.recover_page(self.page,'same-question'))
                resume.assert_called_once_with(self.page)
        self.assertEqual(reload.await_count,2)
        self.assertEqual(await self.page.locator('input:checked').count(),0)
        await self.page.set_content('<h1>Your Answer incorrect</h1>')
        with patch.object(self.page,'reload',new_callable=AsyncMock) as reload:
            self.assertFalse(await recovery.recover_page(self.page,manual=True))
            reload.assert_not_awaited()

    async def test_changed_tile_identity_cannot_bypass_reload_budget(self):
        with patch.object(self.page,'reload',wraps=self.page.reload) as reload:
            self.assertTrue(await recovery.recover_page(self.page,'before-drop'))
            self.assertFalse(await recovery.recover_page(self.page,'after-drop'))
            for identity in ('after-drop','another-id','rerendered-frame','another-render'):
                recovery._resets[self.page]['last']-=16
                self.assertTrue(await recovery.recover_page(self.page,identity))
            self.assertEqual(reload.await_count,2)
            recovery._resets[self.page]['window']-=recovery.RELOAD_WINDOW+1
            recovery._resets[self.page]['last']-=16
            self.assertTrue(await recovery.recover_page(self.page,'after-window'))
            self.assertEqual(reload.await_count,2)  # Each window starts softly.
            recovery._resets[self.page]['last']-=16
            self.assertTrue(await recovery.recover_page(self.page,'after-window'))
            self.assertEqual(reload.await_count,3)

    async def test_failed_pickup_does_not_sweep_every_drop_zone(self):
        from types import SimpleNamespace
        await self.page.set_content('<button id="s">Tile</button><div id="t" data-webqa-match-target="x">Target</div>')
        await self.page.evaluate("window.arrows=0;document.addEventListener('keydown',e=>{if(e.key.startsWith('Arrow'))window.arrows++})")
        self.assertFalse(await actions.keyboard_match(self.page,self.page.locator('#s'),self.page.locator('#t'),SimpleNamespace(text='Tile',cid='tile')))
        self.assertEqual(await self.page.evaluate('window.arrows'),0)


if __name__=='__main__':unittest.main()
