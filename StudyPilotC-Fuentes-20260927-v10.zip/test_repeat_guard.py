import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock,patch
import mcgraw_actions as a

class Page:
    url='https://learning.mheducation.com/test'

class RepeatGuard(unittest.IsolatedAsyncioTestCase):
    async def test_fallback_rebinds_after_source_ids_change(self):
        page=AsyncMock();target=AsyncMock()
        sources=[AsyncMock() for _ in range(3)]
        for s in sources:
            s.bounding_box.return_value={'x':10,'y':400,'width':200,'height':70}
            s.evaluate_all.return_value=['Required answer']
            s.get_attribute.return_value='true'
        target.bounding_box.return_value={'x':400,'y':100,'width':200,'height':70}
        choices=[NS(cid=str(i),text='Required answer') for i in range(3)]
        rebind=AsyncMock(side_effect=list(zip(sources,choices)))
        with patch.object(a,'drop_verified',return_value=False),patch.object(a,'keyboard_match',return_value=False),patch.object(a,'wait_for_drop',side_effect=[False,True]),patch.object(a,'drag_point',side_effect=[(20,420),(410,110)]) as point,patch.object(a.asyncio,'sleep',new=AsyncMock()):
            await a.drag_match(page,AsyncMock(),target,choices[0],AsyncMock(),rebind)
        self.assertEqual(rebind.await_count,3)
        sources[0].drag_to.assert_not_awaited()
        sources[1].drag_to.assert_awaited_once()
        self.assertIs(point.await_args_list[0].args[0],sources[2])

    async def test_failed_question_does_not_repeat_until_resume(self):
        page=Page();frame=Page();q=NS(kind='ordering',text='Rank the items',choices=[])
        action=AsyncMock(side_effect=ValueError('Drop did not persist'))
        with patch.object(a,'apply_ordering',action),patch('drag_diagnostics.save_drag_diagnostic',new=AsyncMock()):
            first=await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            second=await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            self.assertFalse(first['filled'])
            self.assertIn('stopped',second['details'])
            self.assertEqual(action.await_count,1)
            a.clear_navigation(page)
            await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            self.assertEqual(action.await_count,2)
        a.clear_navigation(page)

    async def test_transient_failure_retries_after_cooldown_but_stops_after_three(self):
        page=Page();frame=Page();q=NS(kind='ordering',text='Rank the items',choices=[])
        clock=NS(now=100.)
        action=AsyncMock(side_effect=ValueError('Drop did not persist'))
        with patch.object(a,'apply_ordering',action),patch.object(a.time,'monotonic',side_effect=lambda:clock.now),patch('drag_diagnostics.save_drag_diagnostic',new=AsyncMock()):
            await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            self.assertEqual(action.await_count,1)
            clock.now+=16
            await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            self.assertEqual(action.await_count,2)
            clock.now+=31
            await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            clock.now+=1000
            stopped=await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            self.assertEqual(action.await_count,3)
            self.assertIn('three',stopped['details'])
        a.clear_navigation(page)

    async def test_manual_completion_during_cooldown_advances_without_moving(self):
        from models import Choice
        page=Page();frame=NS(url=Page.url,locator=lambda selector:NS(count=AsyncMock(return_value=0)));q=NS(kind='ordering',text='Rank the items',choices=[Choice('a','one','ordering'),Choice('b','two','ordering')])
        with patch.object(a,'apply_ordering',new=AsyncMock(side_effect=ValueError('No movement'))) as action,patch('drag_diagnostics.save_drag_diagnostic',new=AsyncMock()),patch.object(a,'current_order',new=AsyncMock(return_value=['a','b'])):
            await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            completed=await a.fill_mcgraw_answer(page,frame,q,['one','two'])
            self.assertTrue(completed['filled'])
            self.assertEqual(action.await_count,1)
        a.clear_navigation(page)

if __name__=='__main__':unittest.main()
