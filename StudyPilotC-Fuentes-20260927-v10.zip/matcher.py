\
from rapidfuzz import fuzz
from models import Choice

def normalize(s: str) -> str:
    return " ".join((s or "").lower().strip().split())

def best_choice(requested: str, choices: list[Choice]) -> Choice | None:
    req = normalize(requested)
    if not req:
        return None

    # Exact / containment first.
    for c in choices:
        t = normalize(c.text)
        if t == req:
            return c
    for c in choices:
        t = normalize(c.text)
        if req in t or t in req:
            if min(len(req), len(t)) >= 2:
                return c

    scored = []
    for c in choices:
        t = normalize(c.text)
        if not t:
            continue
        score = max(fuzz.ratio(req, t), fuzz.token_set_ratio(req, t))
        scored.append((score, c))

    if not scored:
        return None
    score, choice = max(scored, key=lambda x: x[0])
    return choice if score >= 62 else None
