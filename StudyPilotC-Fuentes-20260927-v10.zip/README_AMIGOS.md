# Study Pilot C — inicio en Windows

Esta entrega es una aplicación Python para Windows. No es un ejecutable autónomo.

## Instalar una vez

1. Instala Python 3.11 o superior desde [python.org](https://www.python.org/downloads/windows/), con Tcl/Tk y la opción **Add python.exe to PATH**. Instala también Google Chrome.
2. Extrae **todo** el ZIP en una carpeta propia, por ejemplo `Documentos\Study Pilot C`. No abras el programa desde dentro del ZIP.
3. Ejecuta **Instalar Study Pilot C.bat**. Necesita Internet y crea un entorno `.venv` dentro de esa carpeta.
4. Cuando termine, abre **Iniciar Study Pilot C.bat**.

## Preparar una sesión

En los ajustes, escribe tu propia clave API. Las llamadas a la API usan tu cuenta y pueden generar cargos. El modelo inicial se indica en `.env.example`; puedes configurar `OPENAI_MODEL` en tu `.env` con un modelo compatible al que tu cuenta tenga acceso. La clave introducida en la interfaz no se guarda al cerrar el programa. Si prefieres guardarla localmente, copia `.env.example` como `.env` y edita ese archivo; mantenlo privado.

Pulsa **Iniciar sesión** y entra con tu propia cuenta de McGraw en la ventana de Chrome abierta por la aplicación. La sesión que ya tengas en otro Chrome no se comparte automáticamente. Abre allí la actividad que puedes utilizar.

El modo `assist` muestra sugerencias; `fill` aplica las respuestas compatibles. La confianza mínima controla qué respuestas se aplican. **Pausar**, **Reanudar** y **Detener** controlan la ejecución. Los ajustes nuevos se aplican al iniciar una sesión nueva.

## Ritmo y duración

La duración inicial es **120 minutos** y la estimación es de **180 preguntas**: 90 conceptos con dos preguntas por concepto equivalen a unos **40 segundos por pregunta**. Ajusta manualmente la cantidad estimada a tu actividad.

Son intervalos de trabajo reales. Una actividad adaptativa puede añadir o repetir preguntas, y los tiempos de carga y revisión varían; la duración total puede resultar menor o mayor a dos horas. El programa no puede garantizar un tiempo exacto ni respuestas siempre correctas.

## Datos y recuperación

La memoria de errores se conserva durante la ejecución actual y usa la corrección que la página permita leer. Reiniciar el programa comienza una memoria nueva. Si no puede leer la solución, registra el intento rechazado sin inventar una corrección.

Si una respuesta sale vacía, tiene poca confianza o coincide con un intento rechazado, la app vuelve a analizarla con esperas crecientes de **15, 30, 60, 120 y hasta 300 segundos**. Cada reanálisis solicita una revisión nueva; no reenvía una respuesta que ya fue rechazada en esa ejecución. Cuando hay un recurso del concepto accesible, puede consultarlo y volver a la pregunta para aportar más contexto.

El registro muestra cuándo se intentará de nuevo. Estas revisiones pueden generar **llamadas API y cargos adicionales**, y alargar la duración de la actividad. Puedes pausar o detener la sesión. Si faltan datos, el recurso no se puede leer o la revisión sigue siendo insuficiente, no está garantizado que la app consiga una respuesta aplicable; puede necesitar tu intervención.

El programa envía preguntas y, cuando corresponde, imágenes o texto alternativo al servicio de IA configurado. Guarda el perfil de Chrome y los ajustes en tu carpeta local. No se incluye el libro ni el índice de otra persona; la consulta del libro requiere un recurso local propio compatible.

No compartas tu carpeta de uso: contiene tu perfil, tus ajustes y posiblemente tu `.env`. Para compartir la aplicación, utiliza únicamente el ZIP limpio original.

## Si algo falla

- **No abre:** ejecuta `Instalar Study Pilot C.bat` y revisa el mensaje. No omitas la extracción del ZIP.
- **No encuentra Chrome:** instala Google Chrome y vuelve a iniciar la aplicación.
- **Clave o modelo rechazado:** revisa la clave, el acceso al modelo y el saldo de tu cuenta API.
- **Perfil de Chrome ocupado:** detén la sesión anterior y cierra su ventana antes de iniciar otra.
- **Parece detenida en una pregunta:** revisa si el registro anuncia un reintento y su tiempo de espera. Si continúa sin resolverla, guarda el mensaje del registro y una captura de la pregunta. Los archivos `last_drag_failure.json` y `last_navigation_wait.json`, si existen, pueden incluir contenido de tu actividad; revísalos antes de compartirlos. No envíes tu clave, `.env` ni `.browser_profile`.

Las pruebas de esta entrega usan lógica local y páginas de ejemplo en Chrome. No equivalen a una sesión real completa de dos horas ni cubren todas las variantes que pueda mostrar McGraw. Prueba primero una actividad breve antes de depender de una sesión larga.
