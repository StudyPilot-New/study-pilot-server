import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from shared_access import server_url,validate_token,save_access,load_access,shared_mode
from llm import Solver


class SharedAccessTests(unittest.TestCase):
    def test_https_only_and_no_embedded_credentials(self):
        self.assertEqual(server_url('https://study.example.com/'),'https://study.example.com/v1')
        self.assertEqual(server_url('https://study.example.com/v1'),'https://study.example.com/v1')
        for value in ('http://example.com','https://user:pass@example.com','https://example.com?key=secret','https://example.com/wrong','https://example.com:invalid','https://bad host.example.com'):
            with self.assertRaises(ValueError):server_url(value)

    def test_openai_key_is_not_a_friend_code(self):
        with self.assertRaises(ValueError):validate_token('sk-proj-'+'x'*40)
        self.assertEqual(validate_token('spc_'+'x'*43),'spc_'+'x'*43)

    def test_access_roundtrip_and_no_secret_in_distribution(self):
        with tempfile.TemporaryDirectory() as temporary,patch.dict(os.environ,{},clear=True):
            root=Path(temporary);(root/'distribution.json').write_text('{"mode":"shared","server_url":""}')
            self.assertTrue(shared_mode(root))
            with self.assertRaisesRegex(ValueError,'activar'):load_access(root)
            save_access('https://study.example.com','spc_'+'x'*43,root)
            self.assertEqual(load_access(root),('https://study.example.com/v1','spc_'+'x'*43))
            self.assertNotIn('spc_', (root/'distribution.json').read_text())

    def test_solver_uses_shared_code_instead_of_owner_key(self):
        with patch('llm.shared_mode',return_value=True),patch('llm.load_access',return_value=('https://study.example.com/v1','spc_'+'x'*43)),patch('llm.AsyncOpenAI') as client:
            Solver('OWNER_KEY_MUST_NOT_BE_USED','owner-model')
            self.assertEqual(client.call_args.kwargs['api_key'],'spc_'+'x'*43)
            self.assertEqual(client.call_args.kwargs['base_url'],'https://study.example.com/v1')
            self.assertEqual(client.call_args.kwargs['max_retries'],0)

    def test_unconfigured_shared_client_does_not_fallback_to_owner_key(self):
        with patch('llm.shared_mode',return_value=True),patch('llm.load_access',side_effect=ValueError('Configure access')),patch('llm.AsyncOpenAI') as client:
            with self.assertRaises(ValueError):Solver('OWNER_KEY','owner-model')
            client.assert_not_called()


if __name__=='__main__':unittest.main()
