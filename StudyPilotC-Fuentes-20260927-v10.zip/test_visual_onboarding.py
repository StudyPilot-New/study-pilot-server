import tempfile,unittest,tkinter as tk
from pathlib import Path
from unittest.mock import patch
import desktop_ui
from guide_visuals import svg
from browser_welcome import WELCOME_HTML

class VisualOnboardingTests(unittest.TestCase):
 def test_all_guide_steps_render_in_small_window(self):
  with tempfile.TemporaryDirectory() as directory,patch.object(desktop_ui,'ROOT',Path(directory)):
   root=tk.Tk();root.withdraw()
   try:
    app=desktop_ui.StudyPilot(root)
    app.notebook.select(app.guide_tab);root.geometry('850x650');root.update()
    def descendants(widget):
     for w in widget.winfo_children():
      yield w;yield from descendants(w)
    widgets=list(descendants(app.guide_tab))
    forward=next(w for w in widgets if isinstance(w,tk.Button) and w.cget('text')=='Siguiente')
    pictures=[w for w in widgets if isinstance(w,tk.Canvas) and len(w.find_all())>3]
    self.assertTrue(pictures)
    for _ in range(4):forward.invoke();root.update();self.assertGreater(len(pictures[0].find_all()),3)
    self.assertEqual(str(forward['state']),'disabled')
   finally:root.destroy()
 def test_illustrations_and_welcome_are_self_contained(self):
  import xml.etree.ElementTree as ET
  for step in range(4):ET.fromstring(svg(step))
  self.assertIn('barra de direcciones',WELCOME_HTML)
  self.assertNotIn('<input',WELCOME_HTML)
  self.assertNotIn('<script',WELCOME_HTML)

if __name__=='__main__':unittest.main()
