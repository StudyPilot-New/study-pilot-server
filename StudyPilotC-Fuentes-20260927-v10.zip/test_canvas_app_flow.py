"""Whole watch-loop fixtures for dynamic Canvas forms; no service/API calls."""
import asyncio
from dataclasses import replace
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock,patch

from playwright.async_api import async_playwright

import app
from canvas_navigation import CanvasNavigation
from models import Answer


HTML=r'''<!doctype html><html><head><style>
label,[role=checkbox]{display:block;padding:12px;margin:5px;width:280px;border:1px solid #ccc}
input[type=radio]{display:none}input[type=text]{display:block;padding:10px}button{padding:10px}
</style></head><body><main id="quiz"></main><script>
window.fixture={stage:0,answers:[null,['Copper'],['wrong','']],remounts:[0,0,0],
  nextClicks:[0,0,0],saved:[],earlyNext:0,submitClicks:0,busy:false,ignoredNext:false};
const expected=[['Carbon'],['Hydrogen','Oxygen'],['amino','acid']];
function current(){
 if(fixture.stage===0)return [...document.querySelectorAll('input[type=radio]:checked')].map(e=>e.value);
 if(fixture.stage===1)return [...document.querySelectorAll('[role=checkbox][aria-checked=true]')].map(e=>e.getAttribute('data-value')).sort();
 return [...document.querySelectorAll('input[type=text]')].map(e=>e.value);
}
function next(){
 const stage=fixture.stage,actual=current();fixture.nextClicks[stage]++;
 if(JSON.stringify(actual)!==JSON.stringify(expected[stage])){fixture.earlyNext++;return;}
 fixture.busy=true;document.querySelector('#next').disabled=true;
 if(stage===0&&!fixture.ignoredNext){
  fixture.ignoredNext=true;setTimeout(()=>{fixture.busy=false;render()},150);return;
 }
 fixture.saved.push({question:stage,answers:actual});
 setTimeout(()=>{fixture.stage++;fixture.busy=false;render()},60);
}
function changedRadio(el){
 fixture.answers[0]=el.value;
 if(!fixture.remounts[0]++)setTimeout(()=>{fixture.answers[0]=null;render()},0);
}
function changedCheckbox(el){
 const value=el.getAttribute('data-value'),checked=el.getAttribute('aria-checked')==='true';
 el.setAttribute('aria-checked',String(!checked));
 fixture.answers[1]=current();
 if(!fixture.remounts[1]++)setTimeout(render,0);
}
function changedText(index,el){
 fixture.answers[2][index]=el.value;
 if(!fixture.remounts[2]++)setTimeout(render,0);
}
function render(){
 const stage=fixture.stage;
 if(stage===3){document.querySelector('#quiz').innerHTML='<h2>Review your quiz</h2><button onclick="fixture.submitClicks++">Submit Quiz</button>';return;}
 let body='';
 if(stage===0)body='<div class="question_text">Choose the element represented by C.</div><fieldset><legend>Group of answer choices</legend>'+['Carbon','Calcium','Copper'].map((name,i)=>'<input type="radio" name="element" id="r'+i+'" value="'+name+'" '+(fixture.answers[0]===name?'checked':'')+' onchange="changedRadio(this)"><label for="r'+i+'">'+name+'</label>').join('')+'</fieldset>';
 if(stage===1)body='<div class="question_text">Select the two elements in water.</div><div role="group">'+['Hydrogen','Oxygen','Copper'].map(name=>'<div role="checkbox" tabindex="0" data-value="'+name+'" aria-label="'+name+'" aria-checked="'+fixture.answers[1].includes(name)+'" onclick="changedCheckbox(this)">'+name+'</div>').join('')+'</div>';
 if(stage===2)body='<div class="question_text">Complete the two-word name of a protein building block.</div>'+['First word','Second word'].map((label,i)=>'<label>'+label+'<input type="text" value="'+fixture.answers[2][i]+'" oninput="changedText('+i+',this)"></label>').join('');
 document.querySelector('#quiz').innerHTML='<section class="question" data-question-id="question-'+stage+'">'+body+'</section><button id="next" onclick="next()" '+(fixture.busy?'disabled':'')+'>Next</button>';
}
render();</script></body></html>'''


class CanvasAppFlow(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.context=await self.browser.new_context(viewport={'width':1200,'height':900})
        await self.context.route('**/*',lambda route:route.fulfill(content_type='text/html',body=HTML))
        self.page=await self.context.new_page()
        await self.page.goto('https://school.instructure.com/courses/42/quizzes/5/take')

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def test_three_dynamic_questions_recover_and_advance_without_duplicate_analysis(self):
        now=[100.0]
        navigator=CanvasNavigation(clock=lambda:now[0])
        async def answer(_page,_frame,question,*args,**kwargs):
            if question.text.startswith('Choose the element'):
                values=['Carbon']
            elif question.text.startswith('Select the two'):
                values=['Hydrogen','Oxygen']
            elif question.text.startswith('Complete the two-word'):
                values=['amino','acid']
            else:
                raise AssertionError('Unexpected fixture question: '+question.text)
            return Answer(question.qid,question.kind,values,.99),''
        solve=AsyncMock(side_effect=answer)
        settings=replace(app.settings,mode='fill',use_vision='never',pacing_minutes=0,
                         min_confidence=.6,highlight_recommendations=False)
        seen={};solver=SimpleNamespace(memory=None)
        with patch.object(app,'settings',settings),patch.object(app,'_canvas_navigation',navigator), \
             patch.object(app,'solve_with_visual_evidence',solve),patch.object(app,'update_overlay',AsyncMock()):
            for _ in range(50):
                await app.analyze_page(self.page,solver,seen)
                now[0]+=11
                await asyncio.sleep(.03)
                state=await self.page.evaluate('fixture')
                self.assertEqual(state['earlyNext'],0,'Next fired before the complete live answer set was selected')
                if state['stage']==3:break
            self.assertEqual(state['stage'],3,'Watch loop did not recover and reach the final review page')
            for _ in range(3):
                await app.analyze_page(self.page,solver,seen)
                now[0]+=11
            state=await self.page.evaluate('fixture')
        self.assertEqual(state['saved'],[
            {'question':0,'answers':['Carbon']},
            {'question':1,'answers':['Hydrogen','Oxygen']},
            {'question':2,'answers':['amino','acid']},
        ])
        self.assertEqual(state['nextClicks'],[2,1,1])
        self.assertTrue(all(count>0 for count in state['remounts']))
        self.assertEqual(state['submitClicks'],0)
        self.assertEqual(solve.await_count,3,'Mechanical recovery queried the model again')
        self.assertEqual(len({call.args[2].text for call in solve.await_args_list}),3)


if __name__=='__main__':unittest.main()
