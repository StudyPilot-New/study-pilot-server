import unittest
from unittest.mock import AsyncMock,patch
from playwright.async_api import async_playwright
from mcgraw_adapter import extract_mcgraw_question
from mcgraw_actions import fill_mcgraw_answer


class OrderingScroll(unittest.IsolatedAsyncioTestCase):
    async def test_nonfocusable_tiles_reorder_across_scroll_and_ignore_fixed_footer(self):
        html='''<meta charset="utf-8"><main id="app"></main><script>
        let order=['Polysaccharide','Disaccharide','Monosaccharide'];window.moves=0;let moving=null;
        function render(){document.querySelector('#app').innerHTML='<h1>Ordering Question</h1><p>Click and drag on elements in order</p><p>Arrange these carbohydrates in order of increasing size.</p>'+order.map(x=>'<div aria-grabbed="false" data-label="'+x+'" style="height:220px;width:900px;border:1px solid;padding:5px;margin:12px">'+x+'</div>').join('')+'<p>Need help? Review concept resources.</p><footer style="position:fixed;bottom:0;background:white;height:70px;width:100%"><p>Rate your confidence to submit your answer.</p><button>Low</button></footer>';}
        document.addEventListener('mousedown',e=>moving=e.target.closest('[data-label]')?.dataset.label);
        document.addEventListener('mouseup',e=>{
          const destination=e.target.closest('[data-label]')?.dataset.label;
          if(moving && destination && moving!==destination){const at=order.indexOf(destination);order.splice(order.indexOf(moving),1);order.splice(at,0,moving);window.moves++;render();}moving=null;
        });render();</script>'''
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page(viewport={'width':1100,'height':500})
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body=html))
                await page.goto('https://learning.mheducation.com/test')
                question=(await extract_mcgraw_question(page.main_frame))[0]
                self.assertEqual(len(question.choices),3)
                with patch('drag_diagnostics.save_drag_diagnostic',new=AsyncMock()):
                    result=await fill_mcgraw_answer(page,page.main_frame,question,['Monosaccharide','Disaccharide','Polysaccharide'])
                self.assertTrue(result['filled'],result)
                self.assertEqual(await page.evaluate('order'),['Monosaccharide','Disaccharide','Polysaccharide'])
                self.assertEqual(await page.evaluate('window.moves'),2)
                # A visual arrangement while a tile is still held is not a drop.
                question=(await extract_mcgraw_question(page.main_frame))[0]
                await page.locator('[data-label]').first.evaluate("el=>el.setAttribute('aria-grabbed','true')")
                from mcgraw_actions import placement_matches_answer
                self.assertFalse(await placement_matches_answer(page.main_frame,question,['Monosaccharide','Disaccharide','Polysaccharide']))
            finally:await browser.close()


if __name__=='__main__':unittest.main()
