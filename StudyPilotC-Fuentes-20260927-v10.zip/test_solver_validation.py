import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock
from llm import Solver
from models import Question,Choice


class SolverValidation(unittest.IsolatedAsyncioTestCase):
    async def test_malformed_responses_are_not_cached_or_applied(self):
        q=Question('q','Choose the correct option','single_choice',[Choice('a','A','radio')])
        for payload in ['{"answers":"A","confidence":1}',
                        '{"answers":["A"],"confidence":2}',
                        '{"answers":["A"],"confidence":NaN}',
                        '{"answers":[null],"confidence":1}']:
            with self.subTest(payload=payload):
                solver=Solver('test-key','test-model')
                request=AsyncMock(side_effect=[NS(status='completed',output_text=payload),
                                               NS(status='completed',output_text='{"answers":["A"],"confidence":1}')])
                solver.client=NS(responses=NS(create=request))
                with self.assertRaises(ValueError):await solver.solve(q)
                self.assertEqual((await solver.solve(q)).answers,['A'])
                self.assertEqual(request.await_count,2)
