from __future__ import annotations
from urllib.parse import urlsplit

PLATFORMS={'instructure.com':'Canvas','canvaslms.com':'Canvas','moodle.com':'Moodle','moodle.org':'Moodle',
           'blackboard.com':'Blackboard','pearson.com':'Pearson','pearsoncmg.com':'Pearson',
           'cengage.com':'Cengage','webassign.net':'Cengage WebAssign'}

def platform_from_url(url):
    host=(urlsplit(url).hostname or '').lower()
    for domain,name in PLATFORMS.items():
        if host==domain or host.endswith('.'+domain):return name
    return None

STUDY_HOST_HINTS = (
    "mheducation.com",
    "mcgrawhill.com",
    "connect.mheducation.com",
    "aleks.com",
)

STUDY_TEXT_HINTS = (
    "mcgraw hill",
    "multiple select question",
    "concepts completed",
)

async def identify_site(page) -> tuple[str, bool]:
    """
    Returns (site_name, is_study_platform).
    """
    url = (page.url or "").lower()

    host=(urlsplit(url).hostname or '').lower()
    if any(host==h or host.endswith('.'+h) for h in STUDY_HOST_HINTS if h!='aleks.com'):
        return "McGraw Hill", True
    platform=platform_from_url(url)
    if platform:return platform,False
    if host=='aleks.com' or host.endswith('.aleks.com'):return 'ALEKS (semantic controls)',False

    try:
        title = (await page.title()).lower()
    except Exception:
        title = ""

    try:
        body = (await page.locator("body").inner_text(timeout=1200)).lower()[:5000]
    except Exception:
        body = ""

    combined = title + "\n" + body
    for label in ('Canvas','Moodle','Blackboard','Pearson','Cengage'):
        if label.lower() in title:return label,False
    if 'mcgraw hill' in combined:
        return "McGraw Hill", True

    return "Generic page", False
