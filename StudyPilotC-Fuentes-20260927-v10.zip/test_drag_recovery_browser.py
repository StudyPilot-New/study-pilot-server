"""Regression fixtures for committed drops, remounted numbered rows and input cleanup."""
import asyncio
import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock,patch
from playwright.async_api import async_playwright
from mcgraw_actions import drop_verified,keyboard_match,drag_match,fill_mcgraw_answer
from mcgraw_adapter import extract_mcgraw_question


class DragRecoveryBrowser(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page(viewport={'width':1400,'height':900})

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def test_drop_preview_is_not_committed_and_missing_target_returns_immediately(self):
        await self.page.set_content('''<div id="target"><div aria-grabbed="true">Synthesis</div></div>''')
        target=self.page.locator('#target')
        self.assertFalse(await drop_verified(target,NS(text='Synthesis')))
        await self.page.locator('[aria-grabbed]').evaluate("el=>el.setAttribute('aria-grabbed','false')")
        self.assertTrue(await drop_verified(target,NS(text='Synthesis')))
        await target.evaluate('el=>el.remove()')
        self.assertFalse(await asyncio.wait_for(drop_verified(target,NS(text='Synthesis')),1))

    async def test_keyboard_uses_nested_focusable_handle_in_role_wrapper(self):
        await self.page.set_content('''<div id="target" data-webqa-match-target="2" style="position:absolute;left:400px;top:80px;width:400px;height:70px"></div>
          <div id="tile" role="button" aria-grabbed="false" data-webqa-cid="tile" style="position:absolute;left:400px;top:300px;width:400px;height:70px"><button>Synthesis</button></div>
          <script>let held=false,moved=false;const tile=document.querySelector('#tile'),target=document.querySelector('#target');
          tile.addEventListener('keydown',e=>{e.preventDefault();
            if(e.code==='Space'){held=!held;tile.setAttribute('aria-grabbed',String(held));if(!held&&moved){target.append(tile);tile.style.position='static';tile.style.transform='';}}
            if(held&&e.code==='ArrowUp'){moved=true;tile.style.transform='translateY(-220px)';}
            if(e.code==='Escape'){held=false;tile.setAttribute('aria-grabbed','false');tile.style.transform='';}
          });</script>''')
        self.assertTrue(await keyboard_match(self.page,self.page.locator('#tile'),self.page.locator('#target'),NS(cid='tile',text='Synthesis')))
        self.assertEqual(await self.page.locator('#target #tile').count(),1)

    async def test_ignored_arrows_cancel_without_sweeping_thirty_positions(self):
        await self.page.set_content('''<div id="target" data-webqa-match-target="1" style="position:absolute;left:400px;top:20px;width:400px;height:70px"></div>
          <div id="tile" tabindex="0" aria-grabbed="false" data-webqa-cid="tile" style="position:absolute;left:400px;top:300px;width:400px;height:70px">Synthesis</div>
          <script>window.arrows=0;document.querySelector('#tile').onkeydown=e=>{e.preventDefault();
            if(e.code==='Space')e.target.setAttribute('aria-grabbed','true');
            if(e.code.startsWith('Arrow'))window.arrows++;
            if(e.code==='Escape')e.target.setAttribute('aria-grabbed','false');};</script>''')
        self.assertFalse(await asyncio.wait_for(keyboard_match(self.page,self.page.locator('#tile'),self.page.locator('#target'),NS(cid='tile',text='Synthesis')),5))
        self.assertLessEqual(await self.page.evaluate('window.arrows'),6)
        self.assertEqual(await self.page.locator('[aria-grabbed="true"]').count(),0)

    async def test_numbered_custom_pointer_rows_rebind_after_each_render_and_repair_wrong_placement(self):
        html='''<meta charset="utf-8"><main id="app"></main><script>
        const names=['1','2','3','4'];const answers=['Synthesis','Exergonic reaction','Endergonic reaction','Hydrolysis'];
        let placed={},moving=null;window.moves=[];window.nativeDrags=0;
        function render(){document.querySelector('#app').innerHTML='<h1>Matching Question</h1><p>Match each item with the correct option.</p>'+names.map((name,i)=>
          '<div style="display:flex;gap:10px;height:80px"><div style="width:500px">'+name+'</div><div class="drop-zone-brace" style="width:5px;height:60px"></div><div class="match-single-response-wrapper" data-index="'+i+'" aria-label="'+name+' drop zone '+(placed[i]?'has choice '+placed[i]:'empty')+'" style="width:500px;height:60px;border:1px solid">'+(placed[i]?tile(placed[i],name+' drop zone has choice '+placed[i]):'')+'</div></div>').join('')+
          '<div style="margin-top:30px;display:flex;flex-wrap:wrap;width:1300px">'+answers.filter(x=>!Object.values(placed).includes(x)).map((x,i)=>tile(x,'position '+(i+1)+' list choices. Choice, '+x)).join('')+'</div><p>Need help? Review resources.</p>';}
        function tile(x,label){return '<div role="button" draggable="false" aria-grabbed="false" class="choice-item-wrapper" data-answer="'+x+'" aria-label="'+label+'" style="width:520px;height:65px;border:1px solid;margin:5px">'+x+'</div>';}
        document.addEventListener('dragstart',()=>window.nativeDrags++);
        document.addEventListener('mousedown',e=>{const item=e.target.closest('[data-answer]');if(item){moving=item.dataset.answer;item.setAttribute('aria-grabbed','true');}});
        document.addEventListener('mouseup',e=>{const target=e.target.closest('[data-index]');
          if(moving&&target){const answer=moving;for(const key of Object.keys(placed))if(placed[key]===answer)delete placed[key];placed[target.dataset.index]=answer;window.moves.push([target.dataset.index,answer]);}
          moving=null;render();});render();</script>'''
        await self.page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body=html))
        await self.page.goto('https://learning.mheducation.com/fixture')
        expected=['Exergonic reaction','Synthesis','Hydrolysis','Endergonic reaction']
        for broken in (False,True):
            with self.subTest(existing_wrong_placement=broken):
                if broken:await self.page.evaluate("placed={0:'Synthesis'};window.moves=[];render()")
                question=(await extract_mcgraw_question(self.page.main_frame))[0]
                with patch('drag_diagnostics.save_drag_diagnostic',new=AsyncMock()):
                    result=await fill_mcgraw_answer(self.page,self.page.main_frame,question,[f'{i+1} => {text}' for i,text in enumerate(expected)])
                self.assertTrue(result['filled'],result)
                self.assertEqual(await self.page.evaluate('names.map((_,i)=>placed[i])'),expected)
                self.assertEqual(len(await self.page.evaluate('window.moves')),4)
                self.assertEqual(await self.page.evaluate('window.nativeDrags'),0)
                self.assertEqual(await self.page.locator('[aria-grabbed="true"]').count(),0)

    async def test_failed_pointer_releases_mouse_and_avoids_unsupported_html5_events(self):
        await self.page.set_content('''<div id="target" style="position:absolute;left:400px;top:20px;width:400px;height:70px"></div>
          <div id="tile" draggable="false" style="position:absolute;left:400px;top:300px;width:400px;height:70px">Synthesis</div>
          <script>window.down=false;window.ups=0;window.drags=0;
          document.onmousedown=()=>window.down=true;document.onmouseup=()=>{window.down=false;window.ups++};document.ondragstart=()=>window.drags++;</script>''')
        with patch('mcgraw_actions.keyboard_match',new=AsyncMock(return_value=False)),patch('mcgraw_actions.drag_point',side_effect=[(500,330),ValueError('Destination covered')]):
            with self.assertRaisesRegex(ValueError,'not registered'):
                await drag_match(self.page,self.page.locator('#tile'),self.page.locator('#target'),NS(cid='tile',text='Synthesis'))
        self.assertEqual(await self.page.evaluate('[window.down,window.ups,window.drags]'),[False,1,0])


if __name__=='__main__':unittest.main()
