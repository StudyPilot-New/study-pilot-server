import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

from build_release import RELEASE_FILES, build_release, release_payload


class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for name in RELEASE_FILES:
            (self.root / name).write_text("# sample deliverable\n", encoding="utf-8")

    def test_only_allowlist_and_manifest_no_personal_files(self):
        for name in (".env", "desktop_settings.json", "biology_reference.sqlite3", "private.pdf", "last_drag_failure.json"):
            (self.root / name).write_text("PRIVATE_TEST_DATA", encoding="utf-8")
        (self.root / ".browser_profile").mkdir()
        (self.root / ".browser_profile" / "Cookies").write_text("PRIVATE_TEST_DATA")
        archive = build_release(self.root, release_id="test")
        with zipfile.ZipFile(archive) as package:
            expected = set(RELEASE_FILES) | {".env.example", "RELEASE_MANIFEST.json"}
            self.assertEqual({name.removeprefix("Study Pilot C/") for name in package.namelist()}, expected)
            for name in package.namelist():
                self.assertNotIn(b"PRIVATE_TEST_DATA", package.read(name))
            manifest = json.loads(package.read("Study Pilot C/RELEASE_MANIFEST.json"))
            for name, digest in manifest["files"].items():
                self.assertEqual(hashlib.sha256(package.read("Study Pilot C/" + name)).hexdigest(), digest)
            sample = package.read("Study Pilot C/.env.example").decode()
            self.assertIn("OPENAI_API_KEY=\n", sample)
            self.assertIn("PACING_QUESTIONS=180", sample)

    def test_reject_missing_file(self):
        (self.root / "models.py").unlink()
        with self.assertRaisesRegex(ValueError, "models.py"):
            release_payload(self.root)

    def test_reject_unlisted_local_dependency(self):
        (self.root / "app.py").write_text("import private_module\n")
        (self.root / "private_module.py").write_text("# never ship accidentally\n")
        with self.assertRaisesRegex(ValueError, "private_module.py"):
            release_payload(self.root)

    def test_reject_likely_secret_without_exposing_value(self):
        secret = "sk-proj-" + "A" * 25
        (self.root / "app.py").write_text(f"value = '{secret}'\n")
        with self.assertRaises(ValueError) as error:
            release_payload(self.root)
        self.assertNotIn(secret, str(error.exception))

    def test_never_overwrite_an_existing_release(self):
        first = build_release(self.root, release_id="test")
        original = first.read_bytes()
        with self.assertRaises(FileExistsError):
            build_release(self.root, release_id="test")
        self.assertEqual(first.read_bytes(), original)


if __name__ == "__main__":
    unittest.main()
