"""Canvas regressions for real styled controls and asynchronous remounts."""
import unittest
from playwright.async_api import async_playwright,TimeoutError as BrowserTimeout
from canvas_navigation import CanvasNavigation,question_identity,current_question,validate_answer,restore_answer
from learning_adapter import extract_learning_questions


class CanvasRecoveryDynamic(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page()
        self.now=[0.]
        self.nav=CanvasNavigation(clock=lambda:self.now[0])

    async def asyncTearDown(self):
        await self.browser.close();await self.pw.stop()

    async def question(self,controls,script=''):
        await self.page.set_content('<main><div class="question" data-question-id="42"><div class="question_text">Choose the complete answer.</div><div id="controls">'+controls+'</div></div><button id="next" onclick="window.nexts=(window.nexts||0)+1">Next</button><button onclick="window.submits=(window.submits||0)+1">Submit Quiz</button></main><script>'+script+'</script>')
        q=(await extract_learning_questions(self.page.main_frame))[0]
        found=[(0,self.page.main_frame,q)]
        self.nav.observe(self.page,((0,q.qid,question_identity(q)),),found=found)
        return q,found

    async def test_hidden_native_radio_recovers_through_its_visible_label(self):
        q,found=await self.question('<label><input style="display:none" type="radio" name="x">Alpha</label><label><input style="display:none" type="radio" name="x">Beta</label>')
        # This was the old repair operation: it cannot act on the styled input.
        with self.assertRaises(BrowserTimeout):await self.page.locator('input').first.check(timeout=150)
        self.assertTrue(await validate_answer(self.page.main_frame,q,['Alpha']))
        self.nav.remember(self.page,0,q,question_identity(q),['Alpha'])
        self.assertTrue(await restore_answer(self.page.main_frame,q,['Alpha']))
        self.assertIn('Next pulsado',await self.nav.advance(self.page,found,question_identity))
        self.assertEqual(await self.page.evaluate('[window.nexts,window.submits||0]'),[1,0])

    async def test_custom_aria_multiselect_rebinds_after_each_render(self):
        html='<button role="checkbox" aria-checked="false" data-label="Alpha">Alpha</button><button role="checkbox" aria-checked="false" data-label="Beta">Beta</button><button role="checkbox" aria-checked="true" data-label="Gamma">Gamma</button>'
        q,_=await self.question(html,'''const selected=new Set(['Gamma']);document.querySelector('#controls').onclick=e=>{
          const item=e.target.closest('[data-label]');if(!item)return;selected.has(item.dataset.label)?selected.delete(item.dataset.label):selected.add(item.dataset.label);
          document.querySelector('#controls').innerHTML=['Alpha','Beta','Gamma'].map(x=>'<button role="checkbox" aria-checked="'+selected.has(x)+'" data-label="'+x+'">'+x+'</button>').join('');};''')
        self.assertTrue(await restore_answer(self.page.main_frame,q,['Alpha','Beta']))
        self.assertEqual(await self.page.locator('[aria-checked="true"]').all_inner_texts(),['Alpha','Beta'])

    async def test_two_text_fields_are_rebound_after_the_first_input_remounts(self):
        q,_=await self.question('<input type="text" data-index="0"><input type="text" data-index="1">','''const values=['',''];let rerender=true;
          document.querySelector('#controls').oninput=e=>{values[Number(e.target.dataset.index)]=e.target.value;
          if(rerender){rerender=false;document.querySelector('#controls').innerHTML=values.map((v,i)=>'<input type="text" data-index="'+i+'" value="'+v+'">').join('');}};''')
        self.assertTrue(await restore_answer(self.page.main_frame,q,['amino','acid']))
        self.assertEqual(await self.page.locator('input').evaluate_all('els=>els.map(e=>e.value)'),['amino','acid'])

    async def test_delayed_controlled_reset_never_advances_a_transient_selection(self):
        q,found=await self.question('<label><input type="radio" name="x">Alpha</label><label><input type="radio" name="x">Beta</label>','''let once=true;document.querySelector('#controls').onchange=e=>{if(once){once=false;setTimeout(()=>{document.querySelectorAll('input').forEach(n=>n.checked=false);},250);}};''')
        self.nav.remember(self.page,0,q,question_identity(q),['Alpha'])
        self.assertFalse(await restore_answer(self.page.main_frame,q,['Alpha']))
        self.assertIsNone(await self.page.evaluate('window.nexts'))
        self.now[0]=2
        self.assertIn('restablecida',await self.nav.advance(self.page,found,question_identity))
        self.assertIsNone(await self.page.evaluate('window.nexts'))
        self.now[0]=3
        self.assertIn('Next pulsado',await self.nav.advance(self.page,found,question_identity))
        self.assertEqual(await self.page.evaluate('window.nexts'),1)

    async def test_question_position_and_option_order_changes_preserve_only_the_same_public_question(self):
        q,found=await self.question('<label><input type="radio" name="x">Alpha</label><label><input type="radio" name="x">Beta</label>')
        self.nav.remember(self.page,0,q,question_identity(q),['Beta'])
        await self.page.locator('main').evaluate('''e=>e.insertAdjacentHTML('afterbegin','<div class="question" data-question-id="other"><p class="question_text">Another visible question.</p><label><input type="radio">Other</label></div>')''')
        await self.page.locator('#controls').evaluate('e=>e.append(e.firstElementChild)')
        fresh=await current_question(self.page.main_frame,q)
        self.assertIsNotNone(fresh)
        self.assertNotEqual(fresh.qid,q.qid)
        self.assertTrue(await restore_answer(self.page.main_frame,q,['Beta']))
        await self.page.locator('[data-question-id="other"]').evaluate('e=>e.remove()')
        fresh=(await extract_learning_questions(self.page.main_frame))[0]
        found=[(4,self.page.main_frame,fresh)]
        self.nav.observe(self.page,((4,fresh.qid,question_identity(fresh)),),found=found)
        self.assertIn('Next pulsado',await self.nav.advance(self.page,found,question_identity))
        self.assertEqual(await self.page.evaluate('window.nexts'),1)
        await self.page.locator('.question').evaluate("e=>e.setAttribute('data-question-id','a-new-real-question')")
        self.assertIsNone(await current_question(self.page.main_frame,q))
        self.assertFalse(await restore_answer(self.page.main_frame,q,['Alpha']))

    async def test_ambiguous_or_partial_answer_is_not_accepted_for_navigation(self):
        q,_=await self.question('<label><input type="radio" name="x">Alpha molecule</label><label><input type="radio" name="x">Alpha molecule complex</label>')
        self.assertFalse(await validate_answer(self.page.main_frame,q,['Alpha']))
        self.assertFalse(await restore_answer(self.page.main_frame,q,['Alpha']))
        self.assertEqual(await self.page.locator('input:checked').count(),0)

    async def test_native_checked_property_overrides_stale_aria_state(self):
        from canvas_navigation import answer_is_selected
        q,_=await self.question('<label><input type="radio" name="x" aria-checked="true">Alpha</label><label><input type="radio" name="x">Beta</label>')
        self.assertFalse(q.choices[0].checked)
        self.assertFalse(await answer_is_selected(self.page.main_frame,q,['Alpha']))
        self.assertTrue(await restore_answer(self.page.main_frame,q,['Alpha']))
        self.assertTrue(await self.page.get_by_label('Alpha',exact=True).is_checked())

    async def test_failed_remembered_question_does_not_starve_another_remembered_repair(self):
        await self.page.set_content('''<div class="question" data-question-id="first"><div class="question_text">Choose the enabled confirmation.</div>
          <label><input type="radio" onclick="if(document.querySelector('#needed').value!=='ready')return false">Confirm</label></div>
          <div class="question" data-question-id="second"><div class="question_text">Fill the confirmation word.</div><input id="needed" type="text"></div>
          <button onclick="window.nexts=(window.nexts||0)+1">Next</button>''')
        questions=await extract_learning_questions(self.page.main_frame)
        found=[(0,self.page.main_frame,q) for q in questions]
        fingerprint=tuple((0,q.qid,question_identity(q)) for q in questions)
        self.nav.observe(self.page,fingerprint,found=found)
        for q,answer in zip(questions,['Confirm','ready']):self.nav.remember(self.page,0,q,question_identity(q),[answer])
        self.now[0]=1
        self.assertIn('recuperando',await self.nav.advance(self.page,found,question_identity))
        # q1 is still cooling down, but q2 must get its own repair now.
        self.assertIn('restablecida',await self.nav.advance(self.page,found,question_identity))
        self.assertEqual(await self.page.locator('#needed').input_value(),'ready')
        self.assertIsNone(await self.page.evaluate('window.nexts'))
        self.now[0]=3
        self.assertIn('restablecida',await self.nav.advance(self.page,found,question_identity))
        self.assertIn('Next pulsado',await self.nav.advance(self.page,found,question_identity))
        self.assertEqual(await self.page.evaluate('window.nexts'),1)

    async def test_failed_repair_requests_soft_recovery_without_pressing_next_or_submit(self):
        q,found=await self.question('<label><input type="radio" name="x">Alpha</label><label><input type="radio" name="x">Beta</label>',"document.querySelectorAll('input').forEach(e=>e.onclick=()=>false)")
        self.nav.remember(self.page,0,q,question_identity(q),['Alpha'])
        for now in (1,3,7):
            self.now[0]=now
            self.assertIn('recuperando',await self.nav.advance(self.page,found,question_identity))
        self.assertIsNotNone(self.nav.take_recovery_request(self.page))
        self.assertIsNone(self.nav.take_recovery_request(self.page))
        self.assertEqual(await self.page.evaluate('[window.nexts||0,window.submits||0]'),[0,0])
        await self.page.locator('input').evaluate_all('els=>els.forEach(e=>e.onclick=null)')
        self.now[0]=20
        self.assertIn('restablecida',await self.nav.advance(self.page,found,question_identity))
        await self.nav.advance(self.page,found,question_identity)
        self.assertEqual(await self.page.evaluate('window.nexts'),1)


if __name__=='__main__':unittest.main()
