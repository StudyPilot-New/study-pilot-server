"""Study Pilot C desktop launcher. Uses the existing Python environment."""
import json
import os
from pathlib import Path
import queue
import re
import subprocess
import sys
import tempfile
import threading
import time
import tkinter as tk
from tkinter import ttk
from shared_access import shared_mode, load_access
from runtime_paths import DATA_DIR
from quality import quality_environment

ROOT = DATA_DIR
BG, INK, MUTED, ACCENT = '#f1f5f7', '#162b3c', '#536579', '#087f73'
PREFERENCE_FIELDS = ('url','confidence','mode','vision','minimum','book','pacing_minutes','pacing_questions','quality','pacing_mode','pacing_seconds')


def validate_session_options(minimum, minutes, questions):
    """Validate before launching so a malformed form never creates a process."""
    try:
        minimum = float(minimum)
        if not 0 <= minimum <= 1:
            raise ValueError
    except (ValueError, TypeError):
        raise ValueError('El mínimo debe ser un número entre 0 y 1.') from None
    try:
        minutes = int(minutes)
        if not 0 <= minutes <= 1440:
            raise ValueError
    except (ValueError, TypeError):
        raise ValueError('La duración debe ser un número entero entre 0 y 1440 minutos.') from None
    try:
        questions = int(questions)
        if not 1 <= questions <= 1000:
            raise ValueError
    except (ValueError, TypeError):
        raise ValueError('La cantidad estimada debe ser un número entero entre 1 y 1000 preguntas.') from None
    return minimum, minutes, questions


class StudyPilot:
    def __init__(self, root):
        self.root, self.process = root, None
        self.events = queue.Queue()
        self.control = None
        self.paused = self.closing = False
        self.count = 0
        self.secret = ''
        self.started_at = None
        root.title('Study Pilot C')
        root.geometry('1100x780')
        root.minsize(940,700)
        root.configure(bg=BG)
        style=ttk.Style(root);style.theme_use('clam')
        style.configure('TCombobox',padding=7,fieldbackground='white')
        style.configure('TCheckbutton',background='white',font=('Segoe UI',10))
        self.url=tk.StringVar()
        self.confidence=tk.StringVar(value='Medium')
        self.mode=tk.StringVar(value='fill')
        self.vision=tk.StringVar(value='auto')
        self.minimum=tk.StringVar(value='0.60')
        self.book=tk.BooleanVar(value=(ROOT/'biology_reference.sqlite3').is_file())
        self.api=tk.StringVar()
        self.quality=tk.StringVar(value='Equilibrado')
        self.pacing_minutes=tk.StringVar(value='120')
        self.pacing_questions=tk.StringVar(value='180')
        self.pacing_mode=tk.StringVar(value='Duración total')
        self.pacing_seconds=tk.StringVar(value='40')
        self._pace_after=None
        self.pace_summary=tk.StringVar()
        self.elapsed=tk.StringVar(value='00:00')
        self.status=tk.StringVar(value='Listo para comenzar')
        self.detail=tk.StringVar(value='Abre tu sesión y controla el asistente desde aquí.')
        self.total=tk.StringVar(value='0')
        self.load_preferences()
        self.pacing_minutes.trace_add('write',self.update_pace_summary)
        self.pacing_questions.trace_add('write',self.update_pace_summary)
        self.pacing_mode.trace_add('write',self.update_pace_summary)
        self.pacing_seconds.trace_add('write',self.update_pace_summary)
        self.update_pace_summary()
        from ui_layout import build_dashboard
        build_dashboard(self)
        if not (ROOT/'desktop_settings.json').exists():
            self.notebook.select(self.guide_tab)
        if shared_mode():
            try: load_access()
            except ValueError: self.notebook.select(self.account_tab)
        root.protocol('WM_DELETE_WINDOW',self.close)
        root.after(100,self.poll)

    def label(self,parent,text,size=11,color=INK,bold=False,**kw):
        return tk.Label(parent,text=text,bg=parent['bg'],fg=color,font=('Segoe UI',size,'bold' if bold else 'normal'),**kw)

    def button(self,parent,text,command,primary=False):
        return tk.Button(parent,text=text,command=command,bg=ACCENT if primary else '#e8edf5',
            fg='white' if primary else INK,activebackground='#06695f' if primary else '#dce4f0',
            activeforeground='white' if primary else INK,font=('Segoe UI',11,'bold'),relief='flat',
            bd=0,padx=18,pady=11,cursor='hand2',disabledforeground='#68788c',
            highlightthickness=2,highlightbackground=parent['bg'],highlightcolor=ACCENT,takefocus=True)

    def build(self):
        sidebar=tk.Frame(self.root,bg='#142139',width=210);sidebar.pack(side='left',fill='y');sidebar.pack_propagate(False)
        self.label(sidebar,'SP / C',26,'#ffffff',True).pack(anchor='w',padx=24,pady=(32,6))
        self.label(sidebar,'STUDY PILOT C',10,'#a6bce0',True).pack(anchor='w',padx=24)
        self.label(sidebar,'Tu espacio de estudio',10,'#8398b8').pack(anchor='w',padx=24,pady=(7,36))
        self.label(sidebar,'●   Panel de sesión',11,'#ffffff',True).pack(anchor='w',padx=24,pady=12)
        self.label(sidebar,'Ajusta. Inicia. Supervisa.',10,'#a6bce0').pack(anchor='w',padx=24,pady=10)
        self.label(sidebar,'CONTROL LOCAL\nTus ajustes, en tu equipo.',9,'#8398b8',justify='left').pack(side='bottom',anchor='w',padx=24,pady=28)
        main=tk.Frame(self.root,bg=BG);main.pack(side='left',fill='both',expand=True,padx=28,pady=24)
        self.label(main,'Sesión de estudio',26,bold=True).pack(anchor='w')
        self.label(main,'Todo lo que necesitas, sin comandos.',11,MUTED).pack(anchor='w',pady=(5,20))
        cards=tk.Frame(main,bg=BG);cards.pack(fill='x')
        card=tk.Frame(cards,bg='white',padx=18,pady=14);card.pack(side='left',fill='both',expand=True,padx=(0,12))
        self.label(card,'ESTADO DE LA SESIÓN',9,MUTED,True).pack(anchor='w')
        tk.Label(card,textvariable=self.status,bg='white',fg=ACCENT,font=('Segoe UI',15,'bold')).pack(anchor='w',pady=(6,0))
        stat=tk.Frame(cards,bg='white',padx=18,pady=14);stat.pack(side='left',fill='y')
        self.label(stat,'APLICACIONES VERIFICADAS',9,MUTED,True).pack(anchor='w')
        tk.Label(stat,textvariable=self.total,bg='white',fg=INK,font=('Segoe UI',19,'bold')).pack(anchor='w')
        settings=tk.Frame(main,bg='white',padx=18,pady=14);settings.pack(fill='x',pady=16)
        self.label(settings,'Configura tu sesión',13,bold=True).grid(row=0,column=0,columnspan=4,sticky='w',pady=(0,10))
        self.label(settings,'Página inicial · opcional',10,MUTED).grid(row=1,column=0,columnspan=4,sticky='w')
        self.entry(settings,self.url).grid(row=2,column=0,columnspan=4,sticky='ew',pady=(4,10))
        for col,(title,var,values) in enumerate([
            ('Modo',self.mode,['fill','assist']),('Confianza',self.confidence,['High','Medium','Low']),
            ('Visión',self.vision,['auto','always','never'])]):
            self.label(settings,title,10,MUTED).grid(row=3,column=col,sticky='w')
            ttk.Combobox(settings,textvariable=var,values=values,state='readonly',width=13).grid(row=4,column=col,sticky='ew',padx=(0,12),pady=(4,10))
        self.label(settings,'Mínimo (0–1)',10,MUTED).grid(row=3,column=3,sticky='w')
        self.entry(settings,self.minimum,width=9).grid(row=4,column=3,sticky='ew',pady=(4,10))
        ttk.Checkbutton(settings,text='Consultar el libro local',variable=self.book).grid(row=5,column=0,columnspan=2,sticky='w')
        self.label(settings,'fill = aplicar  ·  assist = sugerir',9,MUTED).grid(row=5,column=2,columnspan=2,sticky='e')
        access_label=('Acceso incluido · activa tu código con Configurar acceso.bat'
                      if shared_mode() else 'API key · opcional si ya está en .env · no se guarda')
        self.label(settings,access_label,9,MUTED).grid(row=6,column=0,columnspan=4,sticky='w',pady=(12,4))
        self.entry(settings,self.api,show='•',state='disabled' if shared_mode() else 'normal').grid(row=7,column=0,columnspan=4,sticky='ew')
        for i in range(4):settings.columnconfigure(i,weight=1)
        controls=tk.Frame(main,bg=BG);controls.pack(fill='x')
        self.start_button=self.button(controls,'Iniciar sesión',self.start,True);self.start_button.pack(side='left')
        self.pause_button=self.button(controls,'Pausar',self.pause);self.pause_button.pack(side='left',padx=10)
        self.stop_button=self.button(controls,'Detener',self.stop);self.stop_button.pack(side='left')
        self.pause_button['state']=self.stop_button['state']='disabled'
        tk.Label(main,textvariable=self.detail,bg=BG,fg=MUTED,font=('Segoe UI',10),anchor='w',wraplength=760,justify='left').pack(fill='x',pady=(12,12))
        self.label(main,'Actividad de la sesión',12,bold=True).pack(anchor='w',pady=(0,7))
        logframe=tk.Frame(main,bg='white');logframe.pack(fill='both',expand=True)
        self.log=tk.Text(logframe,bg='#19263c',fg='#dce6f5',font=('Consolas',10),relief='flat',padx=12,pady=12,wrap='word',state='disabled',height=7)
        self.log.pack(side='left',fill='both',expand=True)
        scroll=ttk.Scrollbar(logframe,command=self.log.yview);scroll.pack(side='right',fill='y');self.log['yscrollcommand']=scroll.set

    def entry(self,parent,var,**kwargs):
        return tk.Entry(parent,textvariable=var,font=('Segoe UI',11),bg='#f7f9fc',fg=INK,
            insertbackground=INK,relief='flat',bd=1,highlightthickness=1,
            highlightbackground='#8795a5',highlightcolor=ACCENT,**kwargs)

    def update_pace_summary(self,*_):
        try:
            from live_pacing import values
            data=values(self.pacing_mode.get(),self.pacing_seconds.get(),self.pacing_minutes.get(),self.pacing_questions.get())
            minutes,questions=data['minutes'],data['questions']
            seconds=minutes*60/questions
            self.pace_summary.set('Sin espera añadida' if minutes==0 else f'{seconds:g} s/pregunta · ~{minutes:g} min')
            if self._pace_after:self.root.after_cancel(self._pace_after)
            self._pace_after=self.root.after(400,self.send_live_pacing)
        except (ValueError,TypeError):
            self.pace_summary.set('Revisa la duración')

    def send_live_pacing(self):
        self._pace_after=None
        from live_pacing import values,write_update
        try:
            data=values(self.pacing_mode.get(),self.pacing_seconds.get(),self.pacing_minutes.get(),self.pacing_questions.get())
            if self.process is not None:
                write_update(self.control,data)
                (ROOT/'desktop_settings.json').write_text(json.dumps({name:getattr(self,name).get() for name in PREFERENCE_FIELDS},indent=2),encoding='utf-8')
        except (ValueError,OSError):return

    def settings_error(self,message):
        self.status.set('Revisa tus ajustes')
        self.detail.set(message)
        if hasattr(self,'notebook'):
            self.notebook.select(self.settings_tab)

    def load_preferences(self):
        try:
            data=json.loads((ROOT/'desktop_settings.json').read_text(encoding='utf-8'))
            if not isinstance(data,dict):return
            for name in PREFERENCE_FIELDS:
                if name in data and (name!='book' or isinstance(data[name],bool)):
                    getattr(self,name).set(data[name])
        except (OSError,ValueError):pass

    def start(self):
        if self.process is not None:return
        if shared_mode():
            try: load_access()
            except ValueError as exc:
                self.detail.set('Entra en Mi cuenta para activar tu acceso.')
                self.notebook.select(self.account_tab);return
        try:
            minimum,minutes,questions=validate_session_options(self.minimum.get(),'0' if self.pacing_mode.get()=='Por pregunta' else self.pacing_minutes.get(),self.pacing_questions.get())
            from live_pacing import values
            pace=values(self.pacing_mode.get(),self.pacing_seconds.get(),minutes,questions)
            minutes=pace['minutes']
            quality_env=quality_environment(self.quality.get())
        except ValueError as exc:
            self.settings_error(str(exc));return
        self.url.set(self.url.get().strip())
        if self.url.get() and not self.url.get().startswith(('https://','http://')):
            self.settings_error('La dirección debe empezar por https:// o http://.');return
        if self.mode.get() not in ('fill','assist') or self.confidence.get() not in ('High','Medium','Low') or self.vision.get() not in ('auto','always','never'):
            self.settings_error('Selecciona un modo, una confianza y una opción de visión válidos.');return
        env=os.environ.copy()
        env.update(quality_env)
        env.update(MODE=self.mode.get(),MCGRAW_CONFIDENCE=self.confidence.get(),USE_VISION=self.vision.get(),
                   MIN_CONFIDENCE=str(minimum),BOOK_REFERENCE=str(self.book.get()),
                   PACING_MINUTES=f'{minutes:g}',PACING_QUESTIONS=str(questions),
                   PYTHONUNBUFFERED='1',PYTHONIOENCODING='utf-8')
        self.secret=self.api.get().strip()
        if self.secret:env['OPENAI_API_KEY']=self.secret
        if shared_mode():env.pop('OPENAI_API_KEY',None)
        self.temp=tempfile.TemporaryDirectory(prefix='study-pilot-')
        self.control=Path(self.temp.name)/'control.txt';self.control.write_text('run')
        python=Path(sys.executable)
        if python.name.lower()=='pythonw.exe':python=python.with_name('python.exe')
        cmd=([sys.executable,'--engine'] if getattr(sys,'frozen',False)
             else [str(python),'-u',str(ROOT/'app.py')])
        cmd+=['--watch','--control-file',str(self.control)]
        if self.url.get():cmd+=['--url',self.url.get()]
        try:
            self.process=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                text=True,encoding='utf-8',errors='replace',creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except OSError as exc:
            self.detail.set(str(exc));self.temp.cleanup();return
        self.paused=False;self.count=0;self.total.set('0')
        self.started_at=time.monotonic();self.elapsed.set('00:00')
        self.send_live_pacing()
        self.status.set('Iniciando navegador');self.detail.set('Puedes cambiar el ritmo durante la sesión. Los demás ajustes se aplican al reiniciar.')
        self.start_button['state']='disabled';self.pause_button['state']=self.stop_button['state']='normal'
        self.pause_button['text']='Pausar'
        try:
            (ROOT/'desktop_settings.json').write_text(json.dumps({name:getattr(self,name).get() for name in PREFERENCE_FIELDS},indent=2),encoding='utf-8')
        except OSError:pass
        process=self.process
        def reader():
            for line in process.stdout:self.events.put(line.rstrip())
        threading.Thread(target=reader,daemon=True).start()

    def pause(self):
        if self.process is None:return
        self.paused=not self.paused
        self.control.write_text('pause' if self.paused else 'run')
        self.pause_button['text']='Reanudar' if self.paused else 'Pausar'
        self.status.set('Pausa solicitada' if self.paused else 'En ejecución')
        self.detail.set('La pausa se aplica al terminar la pregunta en curso.' if self.paused else 'Buscando preguntas nuevas.')

    def recover(self):
        if self.process is None:return
        self.paused=False
        self.control.write_text('recover:'+str(time.monotonic_ns()),encoding='utf-8')
        self.pause_button['text']='Pausar'
        self.status.set('Recuperación solicitada')
        self.detail.set('Se liberará el arrastre y se revisará la página al terminar la operación en curso. Se conserva la memoria de la sesión.')

    def stop(self):
        if self.process is None:return
        self.control.write_text('stop')
        self.status.set('Cerrando sesión');self.detail.set('Terminando la operación en curso y cerrando el navegador…')
        self.pause_button['state']=self.stop_button['state']='disabled'

    def close(self):
        if self.process is None:self.root.destroy();return
        self.closing=True;self.stop()

    def poll(self):
        if self.process is not None and self.started_at is not None:
            seconds=int(time.monotonic()-self.started_at)
            self.elapsed.set(f'{seconds//3600:02}:{seconds//60%60:02}:{seconds%60:02}' if seconds>=3600 else f'{seconds//60:02}:{seconds%60:02}')
        for _ in range(80):
            try:line=self.events.get_nowait()
            except queue.Empty:break
            if self.secret:line=line.replace(self.secret,'[clave oculta]')
            line=re.sub(r'sk-[A-Za-z0-9_-]{10,}','[clave oculta]',line)
            self.log['state']='normal';self.log.insert('end',line+'\n')
            if int(self.log.index('end-1c').split('.')[0])>1200:self.log.delete('1.0','300.0')
            self.log.see('end');self.log['state']='disabled'
            if 'Confidence submitted:' in line:self.count+=1;self.total.set(str(self.count))
            if not self.paused and not self.closing:
                if 'below confidence' in line:self.status.set('Revisión necesaria');self.detail.set('La respuesta no alcanza el mínimo de confianza. Revisa esta pregunta manualmente.')
                elif 'error' in line.lower() or 'failed' in line.lower() or 'fill: False' in line:self.status.set('Atención requerida');self.detail.set(line[-180:])
                elif line.strip().startswith('Q:'):self.status.set('Analizando pregunta');self.detail.set(line.strip()[3:][:180])
                elif 'Confidence submitted' in line:self.status.set('Respuesta enviada')
                elif 'No se pudo analizar' in line:
                    self.status.set('Reintentando el análisis');self.detail.set(line[-180:])
                elif line.startswith('Pacing:'):
                    self.status.set('Tiempo de estudio');self.detail.set(line.partition(':')[2].strip())
                elif line.startswith('Ritmo actualizado:'):
                    self.detail.set(line+' · aplicado sin reiniciar la sesión.')
        if self.process is not None and self.process.poll() is not None:
            code=self.process.returncode;self.process.stdout.close();self.process=None;self.temp.cleanup()
            self.status.set('Sesión finalizada' if code==0 else 'No se pudo continuar')
            self.detail.set('Puedes iniciar otra sesión.' if code==0 else 'Consulta el registro: comprueba dependencias, API key y que no haya otra sesión usando Chrome.')
            self.start_button['state']='normal';self.pause_button['state']=self.stop_button['state']='disabled'
            if self.closing:self.root.destroy();return
        self.root.after(100,self.poll)


def main():
    root=tk.Tk();StudyPilot(root);root.mainloop()

if __name__=='__main__':main()
