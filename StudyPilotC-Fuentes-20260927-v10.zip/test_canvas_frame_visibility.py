import unittest
from playwright.async_api import async_playwright


class CanvasFrameVisibility(unittest.IsolatedAsyncioTestCase):
    async def test_only_visible_quiz_frame_is_collected(self):
        import app
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page()
                def question(name):
                    return '<div class="question" id="'+name+'"><p class="question_text">Choose the '+name+' example.</p><label><input type="radio" name="choice">Answer</label></div>'
                await page.set_content('<iframe id="old" style="display:none"></iframe><iframe id="current" style="width:700px;height:400px"></iframe>')
                for ident in ('old','current'):
                    element=await page.query_selector('#'+ident)
                    frame=await element.content_frame()
                    await frame.set_content(question(ident))
                found=await app.collect_questions_from_frames(page)
                self.assertEqual([q.text for _,_,q in found],['Choose the current example.'])
            finally:
                await browser.close()


if __name__=='__main__':unittest.main()
