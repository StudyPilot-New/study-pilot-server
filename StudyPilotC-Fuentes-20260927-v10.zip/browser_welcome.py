"""Offline first-run page: never a blank browser and never a credential form."""
from guide_visuals import svg

WELCOME_HTML = '''<!doctype html><html lang="es"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Abre tu actividad · Study Pilot C</title>
<style>body{font:18px system-ui;background:#f2f7f8;color:#152d3d;margin:0}main{max-width:900px;margin:6vh auto;padding:32px}h1{font-size:clamp(30px,5vw,46px)}p,li{line-height:1.7}li{margin:14px 0}article{padding:24px;background:white;border-radius:20px}svg{width:100%;max-width:650px;height:auto}a{color:#087b70}small{color:#4f6573}</style>
<main><small>STUDY PILOT C · CHROME ESTÁ LISTO</small><h1>Ahora abre tu actividad.</h1>
<article><ol><li>Copia el enlace de tu actividad desde Canvas o el portal de tu universidad.</li>
<li>Pégalo en la barra de direcciones de <strong>esta ventana</strong> y pulsa Enter.</li>
<li>Inicia sesión en tu universidad y abre las preguntas. Comprueba el estado en la app.</li></ol>
<p>Este Chrome usa un perfil separado. Es normal que tengas que iniciar sesión otra vez.</p></article>
''' + svg(2) + '''<p><a href="https://study-pilot-server.onrender.com/guia" target="_blank" rel="noopener">Ver la guía con imágenes</a></p>
<small>Puedes cambiar el ritmo, pausar o detener desde Study Pilot C. La IA puede equivocarse; revisa las respuestas.</small></main></html>'''
