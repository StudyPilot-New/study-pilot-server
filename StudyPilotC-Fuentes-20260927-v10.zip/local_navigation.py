from urllib.parse import urlparse

ALLOWED_HOSTS = {"localhost", "127.0.0.1"}


def is_local_page(page):
    try:
        return urlparse(page.url).hostname in ALLOWED_HOSTS
    except ValueError:
        return False


async def _click_local_button(page, name):
    if not is_local_page(page):
        print(f"Auto-{name} disabled on: {page.url}")
        return False
    button = page.get_by_role("button", name=name, exact=True).first
    try:
        await button.wait_for(state="visible", timeout=3000)
        # The page may have navigated while waiting for the control.
        if not is_local_page(page):
            return False
        if not await button.is_enabled():
            return False
        await button.click(timeout=3000)
    except Exception as exc:
        print(f"{name} unavailable or click failed: {exc}")
        return False
    print(f"{name} clicked.")
    return True


async def auto_submit(page):
    return await _click_local_button(page, "Submit")


async def next_question(page):
    return await _click_local_button(page, "Next")
