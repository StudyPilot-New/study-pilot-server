"""Separate bundled program files from writable per-user session data."""
import os
import sys
from pathlib import Path

APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
SHARED = (APP_DIR / 'distribution.json').is_file() or bool(os.getenv('STUDY_PILOT_SERVER_URL'))
DATA_DIR = (Path(os.getenv('LOCALAPPDATA', str(Path.home()))) / 'StudyPilotC' / ('Shared' if SHARED else 'Direct')
            if getattr(sys, 'frozen', False) else APP_DIR)
DATA_DIR.mkdir(parents=True, exist_ok=True)
