import asyncio
import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch
import mcgraw_actions as actions

class Page:
    url = 'https://learning.mheducation.com/test'

class Control:
    def __init__(self, checked=False):
        self.checked, self.value, self.clicks = checked, '', 0
    async def count(self): return 1
    async def is_visible(self): return True
    async def evaluate(self, script): return self.checked
    async def click(self, **kwargs):
        self.checked = not self.checked
        self.clicks += 1
    async def fill(self, value, **kwargs): self.value = value
    async def press(self, key, **kwargs): pass
    async def input_value(self): return self.value
    async def select_option(self, value, **kwargs): self.value = value

class Tests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.page = Page()
        self.frame = Page()
        self.choices = [NS(cid='a', text='Correct', value='1'), NS(cid='b', text='Incorrect', value='2')]
        self.controls = {'a': Control(), 'b': Control(True)}
        self.patch = patch.object(actions, 'by_attribute', side_effect=lambda f,a,v: self.controls[v])
        self.patch.start()
    def tearDown(self): self.patch.stop()
    def q(self, kind): return NS(kind=kind, choices=self.choices, qid='a')
    async def test_deselect_extra(self):
        result = await actions.fill_mcgraw_answer(self.page,self.frame,self.q('multiple_choice'),['Correct'])
        self.assertTrue(result['filled'])
        self.assertTrue(self.controls['a'].checked)
        self.assertFalse(self.controls['b'].checked)
    async def test_exact_not_substring(self):
        result = await actions.fill_mcgraw_answer(self.page,self.frame,self.q('multiple_choice'),['Cor'])
        self.assertFalse(result['filled'])
        self.assertEqual(self.controls['a'].clicks,0)
    async def test_no_double_toggle(self):
        self.controls['a'].checked = True
        self.controls['b'].checked = False
        result = await actions.fill_mcgraw_answer(self.page,self.frame,self.q('single_choice'),['Correct'])
        self.assertTrue(result['filled'])
        self.assertEqual(self.controls['a'].clicks,0)
    async def test_blank_count(self):
        result = await actions.fill_mcgraw_answer(self.page,self.frame,self.q('fill_blank'),['one'])
        self.assertFalse(result['filled'])
        self.assertEqual(self.controls['a'].value,'')
    async def test_blank_values(self):
        result = await actions.fill_mcgraw_answer(self.page,self.frame,self.q('fill_blank'),['one','two'])
        self.assertTrue(result['filled'])
        self.assertEqual(self.controls['b'].value,'two')
    async def test_foreign_frame(self):
        self.frame.url = 'https://mheducation.com.evil.test'
        result = await actions.fill_mcgraw_answer(self.page,self.frame,self.q('fill_blank'),['one','two'])
        self.assertFalse(result['filled'])
    async def test_unverifiable_control(self):
        self.controls['a'].checked = None
        result = await actions.fill_mcgraw_answer(self.page,self.frame,self.q('single_choice'),['Correct'])
        self.assertFalse(result['filled'])
    async def test_dropdown(self):
        result = await actions.fill_mcgraw_answer(self.page,self.frame,self.q('select'),['Incorrect'])
        self.assertTrue(result['filled'])
        self.assertEqual(self.controls['a'].value,'2')
    async def test_confidence_once_then_next_once(self):
        button = AsyncMock()
        with patch.object(actions, 'unique_button', return_value=button):
            self.assertTrue(await actions.submit_confidence(self.page,'Medium',('q1',)))
            self.assertFalse(await actions.submit_confidence(self.page,'Medium',('q1',)))
            self.assertTrue(await actions.advance_pending(self.page,('q1',)))
            self.assertTrue(await actions.advance_pending(self.page,('q1',)))
            self.assertEqual(button.click.await_count,2)
            self.assertFalse(await actions.advance_pending(self.page,('q2',)))
    async def test_missing_confidence(self):
        with patch.object(actions,'unique_button',return_value=None):
            self.assertFalse(await actions.submit_confidence(self.page,'Low',('q1',)))
    async def test_hosts(self):
        for url in ('https://mheducation.com','https://a.mcgrawhill.com'):
            self.assertTrue(actions.allowed_mcgraw(NS(url=url)))
        for url in ('https://evilmheducation.com','https://mheducation.com@evil.test', 'https://evil.test/?mheducation.com','http://localhost'):
            self.assertFalse(actions.allowed_mcgraw(NS(url=url)))

    async def test_retry_confidence_only_after_wait(self):
        button = AsyncMock()
        with patch.object(actions,'unique_button',return_value=button):
            await actions.submit_confidence(self.page,'High',('q',))
        actions._pending[self.page]['last_click'] -= 4
        with patch.object(actions,'unique_button',side_effect=[None,button,button,button]):
            await actions.advance_pending(self.page,('q',))
        self.assertEqual(button.click.await_count,2)
        self.assertEqual(actions._pending[self.page]['attempts'],2)

    async def test_no_retry_when_confidence_disappeared(self):
        button=AsyncMock()
        with patch.object(actions,'unique_button',return_value=button):
            await actions.submit_confidence(self.page,'Low',('q',))
        actions._pending[self.page]['last_click'] -= 4
        with patch.object(actions,'unique_button',return_value=None):
            await actions.advance_pending(self.page,('q',))
        self.assertEqual(button.click.await_count,1)

    async def test_confidence_timeout_retains_navigation_state(self):
        button=AsyncMock()
        button.click.side_effect=TimeoutError('delayed')
        with patch.object(actions,'unique_button',return_value=button):
            self.assertTrue(await actions.submit_confidence(self.page,'Medium',('q',)))
        self.assertIn(self.page,actions._pending)

if __name__ == '__main__': unittest.main()
