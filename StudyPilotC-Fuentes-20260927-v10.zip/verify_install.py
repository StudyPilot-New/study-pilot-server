"""Read-only local checks for the Windows source distribution; no API calls."""
from importlib import import_module
from importlib.metadata import version
from pathlib import Path
import os
import sys


def main():
    errors = []
    if sys.version_info < (3, 11):
        errors.append("Se necesita Python 3.11 o superior.")
    for module, distribution in (
        ("tkinter", None), ("openai", "openai"),
        ("playwright.async_api", "playwright"),
        ("dotenv", "python-dotenv"), ("rapidfuzz", "rapidfuzz"),
    ):
        try:
            import_module(module)
            print(f"OK {module}" + (f" {version(distribution)}" if distribution else ""))
        except Exception as exc:
            errors.append(f"No se pudo cargar {module}: {type(exc).__name__}")
    chrome_paths = [
        Path(os.environ[name]) / "Google/Chrome/Application/chrome.exe"
        for name in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")
        if os.environ.get(name)
    ]
    if os.name == "nt" and not any(path.is_file() for path in chrome_paths):
        print("AVISO: no se encontro Chrome en las rutas habituales. Instala Google Chrome antes de iniciar una sesion.")
    for error in errors:
        print(f"ERROR: {error}")
    if not errors:
        print("Comprobacion de dependencias terminada. No se ha iniciado sesion ni probado McGraw.")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
