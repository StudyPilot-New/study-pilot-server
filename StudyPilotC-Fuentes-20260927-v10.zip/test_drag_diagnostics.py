import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, Mock, patch

import drag_diagnostics


class DragDiagnosticsTests(unittest.IsolatedAsyncioTestCase):
    def fixture(self):
        frame = Mock()
        frame.locator.return_value.evaluate_all = AsyncMock(return_value=[{
            'cid': 'option-1', 'target': None, 'tag': 'DIV', 'role': 'button',
            'label': '1 drop zone has choice Example', 'text': 'Example',
            'rawText': 'Example', 'draggable': 'false', 'grabbed': 'false',
            'math': [], 'rect': {'x': 10, 'y': 20, 'width': 100, 'height': 40},
        }])
        question = SimpleNamespace(text='Fixture question', choices=[
            SimpleNamespace(cid='option-1', text='Example')])
        return frame, question

    async def test_saves_atomic_report_in_writable_data_dir_without_secrets(self):
        frame, question = self.fixture()
        with tempfile.TemporaryDirectory() as temp:
            data = Path(temp) / 'user-data'
            with patch.object(drag_diagnostics, 'DATA_DIR', data), patch.object(
                    drag_diagnostics, 'APP_DIR', Path(temp) / '2026.09.25.8'):
                error = 'Drop failed https://example.test/activity?token=private Bearer sensitive-token ' + 'spc_' + 'a' * 48
                self.assertTrue(await drag_diagnostics.save_drag_diagnostic(frame, question, ['Example'], error))
                report_text = (data / 'last_drag_failure.json').read_text(encoding='utf-8')
                report = json.loads(report_text)
                self.assertEqual(report['runtime_version'], '2026.09.25.8')
                self.assertIn('recorded_at_utc', report)
                self.assertEqual(report['controls'][0]['cid'], 'option-1')
                for secret in ('token=private', 'sensitive-token', 'spc_' + 'a' * 48):
                    self.assertNotIn(secret, report_text)
                self.assertEqual(list(data.glob('*.tmp')), [])
                self.assertFalse((Path(temp) / '2026.09.25.8').exists())

    async def test_failed_write_keeps_last_complete_report_and_does_not_raise(self):
        frame, question = self.fixture()
        with tempfile.TemporaryDirectory() as temp:
            data = Path(temp)
            report_path = data / 'last_drag_failure.json'
            report_path.write_text('{"previous": true}', encoding='utf-8')
            with patch.object(drag_diagnostics, 'DATA_DIR', data), patch.object(
                    drag_diagnostics.json, 'dump', side_effect=OSError('disk error')):
                self.assertFalse(await drag_diagnostics.save_drag_diagnostic(frame, question, ['Example'], 'drop failed'))
            self.assertEqual(json.loads(report_path.read_text()), {'previous': True})
            self.assertEqual(list(data.glob('*.tmp')), [])

    async def test_detached_frame_does_not_interrupt_recovery(self):
        frame, question = self.fixture()
        frame.locator.return_value.evaluate_all.side_effect = RuntimeError('frame detached')
        self.assertFalse(await drag_diagnostics.save_drag_diagnostic(frame, question, [], 'drop failed'))


if __name__ == '__main__':
    unittest.main()
