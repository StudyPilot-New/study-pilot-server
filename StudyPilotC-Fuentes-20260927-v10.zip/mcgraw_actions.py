"""Verified answer application and SmartBook confidence/feedback navigation."""
import asyncio
import json
import re
import time
import unicodedata
from ordering import apply_ordering, current_order, focus_drag_control, drag_point, drag_identity, DRAG_TEXT_JS
from urllib.parse import urlparse
from weakref import WeakKeyDictionary

MCGRAW_HOSTS = ("mheducation.com", "mcgrawhill.com")
_pending = WeakKeyDictionary()
_feedback_navigation = WeakKeyDictionary()
_confidence_wait = WeakKeyDictionary()
_failed_interactions = WeakKeyDictionary()

SCREEN_STATE_JS = r"""() => {
    let text = document.body?.innerText || '';
    const overlay = document.getElementById('webqa-overlay');
    if (overlay) text = text.replace(overlay.innerText, '');
    text = text.replace(/\s+/g,' ').trim();
    return {
        feedback: /your\s+answer\s*(incorrect|correct)/i.test(text),
        required: /before moving on.{0,60}(review|read)|must (review|read)|select a concept resource to continue/i.test(text),
        question: [...document.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"]')].some(el=>{
            if(el.closest('#webqa-overlay,[hidden],[aria-hidden="true"]') || !el.getClientRects().length)return false;
            const style=getComputedStyle(el);
            return style.visibility!=='hidden' && style.display!=='none' &&
                /^(Matching|Ordering|Multiple Choice|Multiple Select|Fill in the Blank) Question$/i.test((el.innerText||'').replace(/\s+/g,' ').trim());
        }),
        textLength: text.length
    };
}"""


async def screen_state(page):
    states = []
    for frame in page.frames:
        if allowed_mcgraw(frame):
            try:
                states.append(await frame.evaluate(SCREEN_STATE_JS))
            except Exception:
                continue
    return {'feedback': any(s['feedback'] for s in states),
            'required': any(s['required'] for s in states),
            'question': any(s.get('question',False) for s in states),
            'textLength': sum(s['textLength'] for s in states)}


async def named_control(page, names):
    # Prefer the specific action when a page also has a general Reading link.
    for name in names:
        matches = []
        pattern = re.compile(r'^' + re.escape(name) + r'$', re.I)
        for frame in page.frames:
            if not allowed_mcgraw(frame):
                continue
            for role in ('button', 'link'):
                controls = frame.get_by_role(role, name=pattern)
                for i in range(await controls.count()):
                    control = controls.nth(i)
                    if await control.is_visible() and await control.is_enabled():
                        matches.append(control)
        if matches:
            return matches[0] if len(matches) == 1 else None
    return None


async def handle_feedback(page):
    """Handle results before extraction, including after a process restart."""
    if not allowed_mcgraw(page):
        return ''
    screen = await screen_state(page)
    state = _feedback_navigation.get(page)
    if state is None:
        if not screen['feedback'] and not screen['required']:
            # Some result views expose Next Question without "Your Answer".
            # Use the specific enabled action, never a generic Continue here.
            next_question = await named_control(page, ('Next Question',))
            if next_question is None:
                return ''
        state = {'phase':'feedback', 'last':0, 'attempts':0}
        _feedback_navigation[page] = state
    now = time.monotonic()
    if now - state['last'] < 2:
        return 'Waiting for McGraw to finish the transition.'
    if state['phase'] == 'next' and not screen['feedback'] and not screen['required']:
        _feedback_navigation.pop(page, None)
        _pending.pop(page, None)
        return ''

    if state['phase']=='reading':
        from reading_navigation import returned_to_activity,finish_checkpoint
        origin=state.get('reading_origin')
        if await returned_to_activity(page,origin):
            finish_checkpoint(page,origin)
            state.update(phase='feedback',reviewed=True,attempts=0,returned_at=now)
    # Reading is a separate view; return only after its content has loaded.
    if state['phase'] == 'reading':
        from reading_navigation import return_control,fallback_return,return_owned_popup
        origin=state.get('reading_origin') or {}
        if await return_owned_popup(page,origin):
            state.update(last=now,returning=True)
            return 'Reading popup closed; verifying the original activity.'
        back = await return_control(page)
        if back is not None and screen['textLength'] >= 150 and state['attempts']<2 and now-origin.get('last_return',float('-inf'))>=4:
            await back.click(timeout=3000)
            state.update(last=now, returning=True, attempts=state['attempts']+1)
            origin.update(last_return=now,return_requested=True,reader_seen=True)
            # Confirm the view changed instead of assuming a click returned.
            if await returned_to_activity(page,origin):
                finish_checkpoint(page,origin)
                state.update(phase='feedback',reviewed=True,attempts=0,returned_at=now)
            return 'Reading loaded; returning to the question.'
        # Some variants expand a resource list before opening the actual reading.
        reading = await named_control(page, ('Read About the Concept', 'Read about this concept', 'Reading', 'Read'))
        if reading is not None and not state.get('returning') and state['attempts'] < 2:
            origin['capture_until']=now+5
            await reading.click(timeout=3000)
            state.update(last=now, attempts=state['attempts']+1)
            return 'Opening the required reading resource.'
        if await fallback_return(page,state.get('reading_origin')):
            state.update(last=now,returning=True)
            if await returned_to_activity(page,origin):
                finish_checkpoint(page,origin)
                state.update(phase='feedback',reviewed=True,attempts=0,returned_at=now)
            return 'Reading return recovered; rescanning feedback.'
        origin=state.get('reading_origin') or {}
        if origin.get('reload_used') and now-origin['started']>15:
            # Retain the exact origin while waiting; discarding it let the
            # generic scanner mistake the still-open reader for a new question.
            retry_at=origin.setdefault('retry_at',now+30)
            if now>=retry_at:
                state.update(attempts=0,returning=False)
                origin.update(reload_used=False,retry_at=now+30)
            return 'Reading return is delayed; retrying automatically after a short wait.'
        return 'Recuperando el regreso desde Reading.'

    if screen['required'] and not state.get('reviewed'):
        review = await named_control(page, ('Read About the Concept', 'review a resource', 'Reading'))
        if review is not None:
            from reading_navigation import checkpoint
            state['reading_origin']=await checkpoint(page)
            await review.click(timeout=3000)
            state.update(phase='reading', last=now, attempts=0,review_visits=state.get('review_visits',0)+1)
            return 'McGraw requires a review: opening the reading resource.'
        return 'McGraw requires a review, but no recognized reading link is available. Send a screenshot of the available resources.'

    next_control = await named_control(page, ('Next Question', 'Next', 'Continue'))
    if next_control is not None:
        if state['attempts'] >= 3:
            if now-state['last']<30:
                return 'Next is delayed; waiting before retrying the enabled control automatically.'
            state['attempts']=0
        await next_control.click(timeout=3000)
        state.update(last=now, attempts=state['attempts']+1, phase='next')
        _pending.pop(page, None)
        return 'Next Question clicked; waiting for the next question.'

    if screen['required']:
        # The platform may enable Next asynchronously after returning. Reopening
        # Reading each poll used to create an endless open/back flashing loop.
        if state.get('reviewed'):
            returned=state.setdefault('returned_at',now)
            if now-returned<(30 if state.get('review_visits',0)>=2 else 10):
                return 'Reading reviewed; waiting for McGraw to enable the next question.'
        review = await named_control(page, ('Read About the Concept', 'review a resource', 'Reading'))
        if review is not None:
            from reading_navigation import checkpoint
            state['reading_origin']=await checkpoint(page)
            await review.click(timeout=3000)
            state.update(phase='reading', last=now, attempts=0,review_visits=state.get('review_visits',0)+1)
            return 'McGraw requires a review: opening the reading resource.'
        return 'McGraw requires a review, but no recognized reading link is available. Send a screenshot of the available resources.'
    if not screen['feedback']:
        _feedback_navigation.pop(page, None)
        _pending.pop(page, None)
        return ''
    return 'Answer feedback detected; waiting for Next Question to become available.'


def allowed_mcgraw(surface):
    try:
        host = urlparse(surface.url).hostname or ""
    except ValueError:
        return False
    return any(host == domain or host.endswith("." + domain) for domain in MCGRAW_HOSTS)


def normalized(value):
    return " ".join(str(value).split()).casefold()


def formula_key(value):
    value = unicodedata.normalize('NFKC', str(value)).casefold()
    value = ''.join(c for c in value if unicodedata.category(c) != 'Cf')
    value = value.translate(str.maketrans({'−':'-', '–':'-', '—':'-'}))
    return re.sub(r'[\s^_{}]', '', value)


def matching_choice(requested, choices):
    matches = [c for c in choices if formula_key(c.text) == formula_key(requested)]
    if len(matches) != 1:
        reason = 'not detected' if not matches else f'{len(matches)} matching tiles detected'
        detected = '; '.join(f'{c.cid}: {c.text!r}' for c in choices)
        raise ValueError(f'Matching answer {requested!r}: {reason}. Read options: {detected}')
    return matches[0]


def matching_target(requested, names):
    matches = [n for n in names if formula_key(n) == formula_key(requested)]
    if len(matches) != 1:
        raise ValueError(f'Unknown or ambiguous matching target: {requested!r}; detected: {names!r}')
    return matches[0]


async def drop_verified(target, choice):
    # A drag preview can contain the answer before the application commits it.
    # Read immediately: rerendered/missing controls must not incur a 30s wait.
    texts = await target.evaluate_all("""els => {
        const textOf=__DRAG_TEXT__;
        if(els.length!==1)return [];
        const el=els[0];
        if([...el.getRootNode().querySelectorAll('[aria-grabbed="true"], [data-is-dragging="true"]')]
            .some(n=>{const r=n.getBoundingClientRect();return r.width>0 && r.height>0 && getComputedStyle(n).visibility!=='hidden';}))return [];
        return [textOf(el), ...[...el.querySelectorAll('[draggable],[aria-grabbed],[data-webqa-match-option-text],math,mjx-container,[data-webqa-cid]')]
            .map(textOf)];
    }""".replace('__DRAG_TEXT__',DRAG_TEXT_JS))
    wanted = formula_key(choice.text)
    return any(formula_key(text) == wanted for text in texts if text)


async def wait_for_drop(target, choice, refresh=None):
    stable = 0
    for _ in range(12):
        if refresh is not None:
            await refresh()
        if await drop_verified(target, choice):
            stable += 1
            if stable >= 3:
                return True
        else:
            stable = 0
        await asyncio.sleep(0.1)
    return False


async def matching_complete(frame):
    """Recognize committed manual placements without needing another model call."""
    for _ in range(3):
        states=await frame.locator('[data-webqa-match-target]').evaluate_all('''els=>els.map(el=>({
          name:el.getAttribute('data-webqa-match-target'),text:(el.innerText||'').trim(),
          choices:[el,...el.querySelectorAll('[data-webqa-match-option-text]')]
            .filter(x=>x.hasAttribute('data-webqa-match-option-text'))
            .map(x=>x.getAttribute('data-webqa-match-option-text')).filter(Boolean),
          held:!!el.getRootNode().querySelector('[aria-grabbed="true"]')
        }))''')
        if len(states)<2 or len({formula_key(s['name']) for s in states})!=len(states):
            return False
        if any(s['held'] or not s['choices'] or not s['text'] or
               re.search(r'\bdrop\s+zone\s+empty\b',s['text'],re.I) or
               formula_key(s['text'])==formula_key(s['name']) for s in states):
            return False
        await asyncio.sleep(0.1)
    return True


async def keyboard_drag_state(target, choice):
    return await target.evaluate_all("""(els,wanted) => {
        const textOf=__DRAG_TEXT__;
        if(els.length!==1)return null;
        const el=els[0],root=el.getRootNode();
        const key=value=>(value || '').normalize('NFKC').toLowerCase()
            .replace(/[−–—]/g,'-').replace(/[\\s\\u200b-\\u200f\\u2060\\ufeff^_{}]/g,'');
        const visible=n=>{const r=n.getBoundingClientRect(),s=getComputedStyle(n);
            return r.width>0 && r.height>0 && s.visibility!=='hidden' && s.display!=='none' && Number(s.opacity)!==0;};
        const active=root.activeElement || document.activeElement;
        const id=active?.getAttribute('aria-activedescendant');
        const indicated=id ? root.querySelector('#'+CSS.escape(id)) : null;
        // Keyboard drag portals often replace/hide the original node and do
        // not copy our CID. Read the visible held tile by its rendered label.
        const held=[...root.querySelectorAll('[aria-grabbed="true"],[data-is-dragging="true"],.cdk-drag-preview,.gu-mirror')]
            .filter(n=>visible(n) && key(textOf(n))===wanted);
        const tile=held.find(n=>n.matches('.cdk-drag-preview,.gu-mirror')) ||
            held.find(n=>n===active || n.contains(active)) || held[0];
        if(!tile)return {held:false,onTarget:false,marker:null};
        const a=tile.getBoundingClientRect(),b=el.getBoundingClientRect();
        const x=a.left+a.width/2,y=a.top+a.height/2;
        return {held:true,onTarget:active===el || el.contains(active) ||
            !!(indicated && (indicated===el || el.contains(indicated))) ||
            (x>b.left && x<b.right && y>b.top && y<b.bottom),
            marker:[Math.round(x),Math.round(y),id,active?.getAttribute('aria-label'),tile.getAttribute('aria-label')]};
    }""".replace('__DRAG_TEXT__',DRAG_TEXT_JS),formula_key(choice.text))


async def keyboard_match(page, source, target, choice, refresh=None):
    """Use McGraw's documented Space / arrows / Space interaction."""
    print(f'  Keyboard matching: {choice.text}')
    committed=False
    try:
        await source.scroll_into_view_if_needed(timeout=3000)
        if not await focus_drag_control(source):
            return False
        await page.keyboard.press('Space')
        pickup_until=time.monotonic()+.9
        state=None
        while time.monotonic()<pickup_until:
            state=await keyboard_drag_state(target,choice)
            if state and state['held']:break
            await asyncio.sleep(.05)
        if not state or not state['held']:
            return False
        count=await target.evaluate("el => el.getRootNode().querySelectorAll('[data-webqa-match-target],[data-webqa-match-option-text]').length",timeout=1200)
        steps=min(30,max(2,count+2))
        deadline=time.monotonic()+10
        for direction in ('ArrowUp','ArrowDown'):
            last_state=state['marker']
            unchanged=0
            for _ in range(steps):
                if time.monotonic()>=deadline:return False
                await page.keyboard.press(direction)
                # Wait for async movement/animation instead of assuming every
                # laptop can finish it in 120ms. Require two stable reads.
                until=min(deadline,time.monotonic()+.65)
                previous=None
                stable=0
                while time.monotonic()<until:
                    state=await keyboard_drag_state(target,choice)
                    if state and state['held']:
                        stable=stable+1 if state['marker']==previous else 0
                        previous=state['marker']
                        if stable>=2 and (state['onTarget'] or state['marker']!=last_state):break
                    await asyncio.sleep(.05)
                if not state or not state['held']:return False
                if state['onTarget']:
                    await page.keyboard.press('Space')
                    if await wait_for_drop(target,choice,refresh):
                        print('  Keyboard drop verified.')
                        committed=True
                        return True
                    return False
                unchanged=unchanged+1 if state['marker']==last_state else 0
                last_state=state['marker']
                if unchanged>=2:break
    except Exception as exc:
        print(f'  Keyboard matching: {type(exc).__name__}: {exc}')
    finally:
        if not committed:
            try:await page.keyboard.press('Escape')
            except Exception:pass
    return False


async def drag_match(page, source, target, choice, refresh=None, rebind=None):
    async def live_source():
        nonlocal source, choice
        if rebind is not None:
            source,choice=await rebind()
        labels=await source.evaluate_all("""els => {const textOf=__DRAG_TEXT__;return els.map(textOf);}""".replace('__DRAG_TEXT__',DRAG_TEXT_JS))
        if len(labels)!=1 or formula_key(labels[0])!=formula_key(choice.text):
            raise ValueError('Drag source changed during rerender; rescan required')
        return await source.get_attribute('draggable',timeout=1200)=='true'

    if await drop_verified(target, choice):
        return
    native=await live_source()
    if await keyboard_match(page, source, target, choice, refresh):
        return
    # Framework pointer widgets explicitly expose draggable=false. Native HTML5
    # and synthetic DataTransfer events cannot operate those widgets; repeating
    # both only adds scrolling, flicker and delay to the same failed gesture.
    if native:
        await live_source()
        print(f'  Dragging {choice.text}: native drag')
        try:
            await source.drag_to(target, timeout=3000)
        except Exception as exc:
            print(f'  Native drag: {type(exc).__name__}')
        finally:
            await page.mouse.up()
        if await wait_for_drop(target, choice, refresh):
            return
        await page.keyboard.press('Escape')
    await live_source()
    print('  Trying a continuous pointer path')
    try:
        await source.scroll_into_view_if_needed(timeout=2000)
        sx,sy=await drag_point(source)
        identity=await drag_identity(source)
        await page.mouse.move(sx,sy)
        await page.mouse.down()
        # Activate distance/delay based drag sensors before scrolling to target.
        await page.mouse.move(sx+12,sy+6,steps=8)
        await asyncio.sleep(0.2)
        await target.scroll_into_view_if_needed(timeout=2000)
        tx,ty=await drag_point(target,dragging=identity)
        await page.mouse.move(tx,ty,steps=24)
        await asyncio.sleep(0.2)
        await page.mouse.move(tx+2,ty+2,steps=3)
    except Exception as exc:
        print(f'  Pointer drag: {type(exc).__name__}: {exc}')
    finally:
        await page.mouse.up()
    if await wait_for_drop(target, choice, refresh):
        return
    await page.keyboard.press('Escape')
    if native:
        await live_source()
        print('  Trying HTML5 drag events with DataTransfer')
        transfer=None
        try:
            transfer=await source.evaluate_handle('el => new DataTransfer()',timeout=1200)
            payload={'dataTransfer':transfer}
            await source.dispatch_event('dragstart',payload,timeout=1200)
            await target.dispatch_event('dragenter',payload,timeout=1200)
            await target.dispatch_event('dragover',payload,timeout=1200)
            await target.dispatch_event('drop',payload,timeout=1200)
            await source.dispatch_event('dragend',payload,timeout=1200)
        except Exception as exc:
            print(f'  HTML5 drag: {type(exc).__name__}: {exc}')
        finally:
            if transfer is not None:
                await transfer.dispose()
        if await wait_for_drop(target, choice, refresh):
            return
        await page.keyboard.press('Escape')
    inspect = "els => els.map(el => ({tag:el.tagName, role:el.getAttribute('role'), draggable:el.getAttribute('draggable'), grabbed:el.getAttribute('aria-grabbed'), label:el.getAttribute('aria-label'), classes:String(el.className).slice(0,140), text:(el.innerText||'').slice(0,120)}))"
    details=await target.evaluate_all(inspect)
    source_details=await source.evaluate_all(inspect)
    raise ValueError(f'Drop was not registered by the supported controls. Source: {source_details}; Target: {details}')


def exact_choice(requested, choices):
    matches = [c for c in choices if normalized(c.text) == normalized(requested)]
    if not matches and re.search(r'\d', str(requested)):
        matches = [c for c in choices if formula_key(c.text) == formula_key(requested)]
    if not matches:
        # Ignore sentence-ending punctuation, preserving charges, bonds and
        # decimal points inside a value. Exact matches still take precedence.
        key=lambda value:formula_key(str(value).rstrip().rstrip('.!?')) if re.search(r'\d',str(value)) else normalized(str(value).rstrip().rstrip('.!?'))
        matches=[c for c in choices if key(c.text)==key(requested)]
    if len(matches) != 1:
        raise ValueError(f"Answer is missing or ambiguous: {requested!r}; read options: {[c.text for c in choices]!r}")
    return matches[0]


def by_attribute(frame, attribute, value):
    # CSS strings do not understand JSON's \\uXXXX escapes. Escape each code
    # point with CSS hexadecimal syntax, including quotes/newlines/backslashes.
    escaped = ''.join(f'\\{ord(c):x} ' for c in str(value))
    return frame.locator(f'[{attribute}="{escaped}"]')


async def selected(control):
    return await control.evaluate("el => typeof el.checked === 'boolean' ? el.checked : (el.getAttribute('aria-checked') === 'true' ? true : (el.getAttribute('aria-checked') === 'false' ? false : null))")


async def set_selection(control, wanted):
    state = await selected(control)
    if state is None:
        raise ValueError("Control has no verifiable checked state")
    if state != wanted:
        if await control.is_visible():
            await control.click(timeout=3000)
        else:
            # Styled native inputs can be hidden; their associated label owns
            # the visible click surface and dispatches the input's normal event.
            await control.evaluate("""el => {
                const label = el.closest('label') || (el.id && el.getRootNode().querySelector(`label[for="${CSS.escape(el.id)}"]`));
                if (!label || !label.getClientRects().length) throw Error('No visible input label');
                label.click();
            }""")
    for _ in range(10):
        if await selected(control) == wanted:
            return
        await asyncio.sleep(0.1)
    raise ValueError("Selection did not take effect")


async def placement_matches_answer(frame, question, answers):
    """Read-only completion check; never bypass a failed gesture by moving it."""
    try:
        if question.kind=='ordering' and len(answers)==len(question.choices):
            desired=[exact_choice(text,question.choices).cid for text in answers]
            return (len(set(desired))==len(desired) and await current_order(frame)==desired
                    and not await frame.locator('[aria-grabbed="true"]').count())
        if question.kind=='matching':
            names=await frame.locator('[data-webqa-match-target]').evaluate_all("els=>els.map(el=>el.getAttribute('data-webqa-match-target'))")
            pairs=[str(text).split('=>',1) for text in answers]
            if len(pairs)==len(names) and all(len(pair)==2 for pair in pairs):
                from types import SimpleNamespace
                resolved=[matching_target(pair[0],names) for pair in pairs]
                if names and len(set(resolved))==len(names):
                    return all([await drop_verified(by_attribute(frame,'data-webqa-match-target',name),SimpleNamespace(text=pair[1].strip())) for name,pair in zip(resolved,pairs)])
    except Exception:
        pass  # A stale/missing control cannot establish completion.
    return False


async def fill_mcgraw_answer(page, frame, question, answers):
    result = {"filled": False, "details": ""}
    interaction_key=(question.kind,getattr(question,'text',''),tuple(map(str,answers)),
                     tuple(sorted(formula_key(c.text) for c in question.choices)),
                     getattr(question,'html_hint','') if getattr(question,'has_visual',False) else '')
    previous=_failed_interactions.get(page)
    previous=previous if previous and previous['key']==interaction_key else None
    try:
        if not allowed_mcgraw(page) or not allowed_mcgraw(frame):
            raise ValueError("McGraw host not authorized")
        if not answers or any(not str(a).strip() for a in answers):
            raise ValueError("Empty answer")
        if previous and question.kind in {'matching','ordering'}:
            # A manual correction may have completed an earlier failed attempt.
            # Verify it before the retry guard, so a correct answer can advance.
            completed=await placement_matches_answer(frame,question,answers)
            if completed:
                _failed_interactions.pop(page,None)
                return {'filled':True,'details':'Completed placement verified after previous failure'}
            if previous['attempts']>=3:
                result['details']='Placement requires recovery after three verified failures.'
                result['recover']=True
                result['retry_after']=5
                return result
            remaining=previous['retry_at']-time.monotonic()
            if remaining>0:
                result['details']=f'Placement attempts temporarily stopped; automatic retry in {max(1,int(remaining))} seconds.'
                result['retry_after']=remaining
                return result
        kind = question.kind
        if kind in {"single_choice", "multiple_choice"}:
            if kind == "single_choice" and len(answers) != 1:
                raise ValueError("Single-choice requires exactly one answer")
            chosen = [exact_choice(a, question.choices).cid for a in answers]
            if len(set(chosen)) != len(chosen):
                raise ValueError("Duplicate answer")
            controls = [(c, by_attribute(frame, 'data-webqa-cid', c.cid)) for c in question.choices]
            # Preflight every control before making partial changes.
            for c, control in controls:
                if await control.count() != 1 or await selected(control) is None:
                    raise ValueError(f"Unverifiable control: {c.text}")
            for c, control in controls:
                if kind == "multiple_choice" or c.cid in chosen:
                    await set_selection(control, c.cid in chosen)
            for c, control in controls:
                if await selected(control) != (c.cid in chosen):
                    raise ValueError("Final selection does not match answer")
        elif kind in {"fill_blank", "text", "numeric", "essay"}:
            if len(answers) != len(question.choices):
                raise ValueError("Answer count must match field count")
            for choice, value in zip(question.choices, answers):
                control = by_attribute(frame, 'data-webqa-cid', choice.cid)
                await control.fill(str(value), timeout=3000)
                await control.press("Tab", timeout=3000)
                if await control.input_value() != str(value):
                    raise ValueError("Field value did not persist")
        elif kind == "select":
            if len(answers) != 1:
                raise ValueError("Dropdown requires one answer")
            choice = exact_choice(answers[0], question.choices)
            control = by_attribute(frame, 'data-webqa-select', question.qid)
            await control.select_option(value=choice.value, timeout=3000)
            if await control.input_value() != choice.value:
                raise ValueError("Dropdown value did not persist")
        elif kind == "ordering":
            await apply_ordering(page, frame, question, answers, exact_choice, refresh=True)
        elif kind == "matching":
            targets = frame.locator('[data-webqa-match-target]')
            target_names = await targets.evaluate_all("els => els.map(el => el.getAttribute('data-webqa-match-target'))")
            mappings = []
            for raw in answers:
                parts = str(raw).split("=>", 1)
                if len(parts) != 2:
                    raise ValueError("Matching requires TARGET => MATCH")
                name = matching_target(parts[0], target_names)
                mappings.append((name, parts[1].strip()))
            if len(mappings) != len(target_names) or len({m[0] for m in mappings}) != len(target_names):
                raise ValueError("All matching targets must have one answer")
            from mcgraw_adapter import extract_mcgraw_question
            from types import SimpleNamespace
            latest = question
            async def refresh():
                nonlocal latest
                found = await extract_mcgraw_question(frame)
                candidates=[q for q in found if q.kind=='matching']
                if len(candidates)!=1:
                    raise ValueError('Matching question changed during placement')
                names=await frame.locator('[data-webqa-match-target]').evaluate_all("els=>els.map(el=>el.getAttribute('data-webqa-match-target'))")
                if sorted(map(formula_key,names))!=sorted(map(formula_key,target_names)):
                    raise ValueError('Matching targets changed during placement')
                latest=candidates[0]
            # Validate all requested answers before moving any unplaced tile.
            for name, text in mappings:
                probe=SimpleNamespace(text=text,cid='')
                if not await drop_verified(by_attribute(frame,'data-webqa-match-target',name),probe):
                    matching_choice(text,question.choices)
            for name, text in mappings:
                await refresh()
                target = by_attribute(frame, 'data-webqa-match-target', name)
                probe=SimpleNamespace(text=text,cid='')
                if await drop_verified(target,probe):
                    continue
                choice=matching_choice(text,latest.choices)
                source = by_attribute(frame, 'data-webqa-cid', choice.cid)
                async def rebind():
                    await refresh()
                    fresh=matching_choice(text,latest.choices)
                    return by_attribute(frame,'data-webqa-cid',fresh.cid),fresh
                try:
                    await asyncio.wait_for(drag_match(page, source, target, choice, refresh, rebind),timeout=20)
                except asyncio.TimeoutError:
                    raise ValueError('Drag interaction timed out; releasing the gesture before retry') from None
            for name, text in mappings:
                if not await wait_for_drop(by_attribute(frame, 'data-webqa-match-target', name), SimpleNamespace(text=text,cid=''), refresh):
                    raise ValueError('A previously placed answer moved; submission stopped')
        else:
            raise ValueError(f"Unsupported interaction: {kind}; DOM example needed")
        result.update(filled=True, details="Answer applied and verified")
        _failed_interactions.pop(page,None)
    except Exception as exc:
        from recovery import release_input
        await release_input(page)
        result["details"] = str(exc)
        if question.kind in {'matching','ordering'}:
            attempts=(previous['attempts'] if previous else 0)+1
            result['retry_after']=min(5,attempts)
            _failed_interactions[page]={'key':interaction_key,'attempts':attempts,
                                      'retry_at':time.monotonic()+result['retry_after']}
            try:
                from drag_diagnostics import save_drag_diagnostic
                await save_drag_diagnostic(frame, question, answers, exc)
            except Exception:
                pass
    return result


async def unique_button(page, names):
    matches = []
    pattern = re.compile(r"^(?:" + "|".join(re.escape(n) for n in set(names)) + r")$", re.I)
    for frame in page.frames:
        if not allowed_mcgraw(frame):
            continue
        controls = frame.get_by_role('button', name=pattern)
        for i in range(await controls.count()):
            control = controls.nth(i)
            if await control.is_visible() and await control.is_enabled():
                matches.append(control)
    return matches[0] if len(matches) == 1 else None


async def submit_confidence(page, level, fingerprint):
    if not allowed_mcgraw(page) or page in _pending:
        return False
    if level not in {"High", "Medium", "Low"}:
        raise ValueError("MCGRAW_CONFIDENCE must be High, Medium, or Low")
    button = await unique_button(page, (level, level + " confidence"))
    if button is None:
        controls=[]
        for frame in getattr(page,'frames',()):
            if not allowed_mcgraw(frame):continue
            controls.extend(await frame.locator('button,[role="button"],input[type="button"]').evaluate_all('''els=>els.map(el=>({
              text:(el.innerText||el.value||'').trim(),label:el.getAttribute('aria-label')||'',
              visible:el.getBoundingClientRect().width>0 && el.getBoundingClientRect().height>0 && getComputedStyle(el).visibility!=='hidden',
              disabled:el.matches(':disabled')||el.getAttribute('aria-disabled')==='true'
            })).filter(x=>/high|medium|low|next question/i.test(x.text+' '+x.label))'''))
        key=(level,fingerprint,json.dumps(controls,sort_keys=True))
        if _confidence_wait.get(page,{}).get('key')!=key:
            message=f'Waiting for {level}: the confidence control is not uniquely enabled. No click was sent.'
            _confidence_wait[page]={'key':key,'message':message}
            print(message)
            if controls:
                from pathlib import Path
                Path(__file__).with_name('last_navigation_wait.json').write_text(
                    json.dumps({'level':level,'controls':controls},ensure_ascii=False,indent=2),encoding='utf-8')
        return False
    _confidence_wait.pop(page,None)
    # Record before clicking: a timeout must not cause a second submission.
    _pending[page] = {"fingerprint": fingerprint, "phase": "feedback",
                      "level": level, "attempts": 1, "last_click": time.monotonic()}
    if not allowed_mcgraw(page):
        return False
    try:
        await button.click(timeout=3000)
    except Exception as exc:
        print(f"Confidence click not confirmed; checking page state before retry: {exc}")
    print(f"Confidence submitted: {level}")
    return True


async def advance_pending(page, fingerprint):
    state = _pending.get(page)
    if state is None:
        return False
    if not allowed_mcgraw(page):
        del _pending[page]
        return False
    if fingerprint and fingerprint != state['fingerprint']:
        del _pending[page]
        return False
    if state['phase'] == 'feedback':
        button = await unique_button(page, ("Next", "Next Question", "Next question", "Continue"))
        if button is not None:
            try:
                await button.click(timeout=3000)
            except Exception as exc:
                print(f"Next click not confirmed: {exc}")
                return True
            state['phase'] = 'transition'
            print("Continuing; waiting for a changed question.")
        elif time.monotonic() - state['last_click'] >= 3 and state['attempts'] < 3:
            # Retry only while all three confidence controls are still enabled
            # on the same question, rather than assuming a click submitted it.
            levels = [await unique_button(page, (name, name + ' confidence'))
                      for name in ('High', 'Medium', 'Low')]
            if all(control is not None for control in levels):
                state['attempts'] += 1
                state['last_click'] = time.monotonic()
                await levels[('High', 'Medium', 'Low').index(state['level'])].click(timeout=3000)
                print(f"Retrying confidence on unchanged question ({state['attempts']}/3).")
        elif state['attempts'] == 3 and time.monotonic() - state['last_click'] >= 3:
            state['attempts'] += 1
            print("No transition after 3 confidence attempts. Check the page feedback; automatic retries stopped.")
    return True


def clear_navigation(page):
    _pending.pop(page, None)
    _feedback_navigation.pop(page, None)
    _confidence_wait.pop(page,None)
    _failed_interactions.pop(page,None)


def confidence_wait_message(page):
    return _confidence_wait.get(page,{}).get('message','Waiting for the page to enable confidence or show Next Question.')


def resume_interactions(page):
    _failed_interactions.pop(page,None)
