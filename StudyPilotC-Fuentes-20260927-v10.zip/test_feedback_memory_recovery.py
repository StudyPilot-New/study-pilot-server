import unittest
from playwright.async_api import async_playwright
from models import Answer,Choice,Question
from session_memory import SessionMemory,fill_correction,split_blanks


def question(count=2):
    text='The first ion is [Blank 1] and the second is [Blank 2].' if count==2 else 'The isomers are [Blank 1] isomers.'
    return Question('q',text,'fill_blank',[Choice(str(i),f'Blank {i+1}','text') for i in range(count)])


class CorrectionParsing(unittest.TestCase):
    def test_semicolon_and_numbered_fields_keep_exact_cardinality_and_order(self):
        q=question()
        self.assertEqual(fill_correction(q,['Na+; K+']),['Na+','K+'])
        self.assertEqual(fill_correction(q,['Field 2: K+','Field 1: Na+']),['Na+','K+'])
        self.assertEqual(split_blanks(q,['Blank 1: Na+\nBlank 2: K+']),['Na+','K+'])
        for shown in (['Na+; K+; Ca2+'],['Field 1: Na+; Field 1: K+'],['Na+',''],['Na+, K+']):
            with self.subTest(shown=shown):self.assertEqual(fill_correction(q,shown),[])

    def test_one_blank_alternatives_are_not_concatenated_or_assigned_to_fields(self):
        q=question(1)
        self.assertEqual(split_blanks(q,['structural; constitutional']),['structural; constitutional'])
        self.assertEqual(fill_correction(q,['structural; constitutional']),[])
        self.assertEqual(fill_correction(q,['structural','constitutional']),[])
        self.assertEqual(fill_correction(q,['structural']),['structural'])

    def test_only_rejected_combination_is_blocked_and_explicit_correction_wins(self):
        q=question();m=SessionMemory()
        m.learn(q,['Na +','K⁺'],False)
        self.assertTrue(m.is_rejected(q,['Na+','K+']))
        self.assertFalse(m.is_rejected(q,['Na+','Ca2+']))
        self.assertFalse(m.is_rejected(q,['Na+']))
        m.learn(q,['Na+','K+'],False,['Na+; K+'])
        self.assertEqual(m.recalled(q).answers,['Na+','K+'])
        self.assertFalse(m.is_rejected(q,['Na +','K⁺']))
        self.assertTrue(m.wrong[m.key(q)])  # Keep the observed history for audit.
        self.assertFalse(m.is_rejected(q,['Na-','K+']))


class FeedbackBrowser(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page()
        await self.page.route('https://learning.mheducation.com/**',lambda route:route.fulfill(content_type='text/html; charset=utf-8',body='<h1>Question</h1>'))
        await self.page.goto('https://learning.mheducation.com/test')

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def observe(self,html,submitted=None,q=None,delay=None):
        q=q or question();m=SessionMemory()
        m.stage(self.page,q,Answer(q.qid,q.kind,submitted or ['wrong','answer'],1))
        await self.page.set_content(html)
        if delay:await self.page.evaluate(delay)
        self.assertTrue(await m.observe(self.page))
        return m,q

    async def test_correct_panel_inputs_are_not_recorded_as_wrong_submission(self):
        m,q=await self.observe('<h1>Your Answer incorrect</h1><h2>Correct Answer</h2><div><input readonly value="Na+"><input readonly value="K+"></div><button>Next Question</button>')
        self.assertEqual(m.recalled(q).answers,['Na+','K+'])
        self.assertTrue(m.is_rejected(q,['wrong','answer']))
        self.assertFalse(m.is_rejected(q,['Na+','K+']))
        self.assertEqual(m.wrong[m.key(q)],[['wrong','answer']])

    async def test_delayed_semicolon_panel_is_complete_before_consumed(self):
        m,q=await self.observe('<h1>Your Answer incorrect</h1><section><div><h2>Correct Answers</h2></div><div id="answer"></div></section>',delay="setTimeout(()=>document.querySelector('#answer').textContent='Na+; K+',350)")
        self.assertEqual(m.recalled(q).answers,['Na+','K+'])

    async def test_waits_for_second_list_item_instead_of_learning_partial_panel(self):
        m,q=await self.observe('<h1>Your Answer incorrect</h1><h2>Correct Answers</h2><ul id="answers"><li>Na+</li></ul>',delay="setTimeout(()=>document.querySelector('#answers').insertAdjacentHTML('beforeend','<li>K+</li>'),350)")
        self.assertEqual(m.recalled(q).answers,['Na+','K+'])

    async def test_separate_numbered_correction_panels_preserve_field_numbers(self):
        m,q=await self.observe('<h1>Your Answer incorrect</h1><section><h2>Correct Answer for Field 2</h2><div>K+</div></section><section><h2>Correct Answer for Field 1</h2><div>Na+</div></section>')
        self.assertEqual(m.recalled(q).answers,['Na+','K+'])

    async def test_single_blank_list_of_alternatives_is_not_one_literal_answer(self):
        m,q=await self.observe('<h1>Your Answer incorrect</h1><h2>Correct Answers</h2><ul><li>structural</li><li>constitutional</li></ul>',submitted=['geometric'],q=question(1))
        self.assertIsNone(m.recalled(q))
        self.assertTrue(m.is_rejected(q,['geometric']))


if __name__=='__main__':unittest.main()
