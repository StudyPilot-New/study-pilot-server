import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch
from models import Question, Choice
from llm import Solver
from visual_question import solve_with_visual_evidence

class RecoveryTests(unittest.IsolatedAsyncioTestCase):
    async def test_review_bypasses_first_answer_but_is_cached(self):
        q=Question('q','What is the chemical formula of glucose?','single_choice',[Choice('a','C6H12O6','radio')])
        solver=Solver('test-key','test-model')
        request=AsyncMock(side_effect=[NS(status='completed',output_text='{"answers":[],"confidence":0.1}'),NS(status='completed',output_text='{"answers":["C6H12O6"],"confidence":0.98}')])
        solver.client=NS(responses=NS(create=request))
        with patch('visual_question.read_text_alternative',return_value=''):
            for _ in range(2):
                answer,_=await solve_with_visual_evidence(None,None,q,solver,None,False,False,0.6)
                self.assertEqual(answer.answers,['C6H12O6'])
        self.assertEqual(request.await_count,2)
        self.assertEqual(request.call_args.kwargs['reasoning'],{'effort':'medium'})

    async def test_failed_description_does_not_discard_captured_image(self):
        solver=NS(solve=AsyncMock(return_value=NS(confidence=.9,answers=['value'])))
        with patch('visual_question.read_text_alternative',return_value=''):
            answer,_=await solve_with_visual_evidence(None,None,'q',solver,b'image',False,True,.6)
        self.assertEqual(answer.answers,['value'])
        self.assertEqual(solver.solve.call_args.kwargs['image_png'],b'image')

if __name__=='__main__':unittest.main()
