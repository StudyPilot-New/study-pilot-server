"""Local full-text textbook retrieval; no network or third-party dependencies."""
from pathlib import Path
import re
import sqlite3

STOP = set('a an the is are was were be been being of in on at to for from by with and or as that this these those which what how why who when where does do did it its their they them following question answer select choose correct incorrect true false all none above below would could should can not most best'.split())


class BookReference:
    def __init__(self, path):
        self.path = Path(path).resolve()
        self.connection = None
        if self.path.is_file():
            self.connection = sqlite3.connect(self.path.as_uri() + '?mode=ro', uri=True)
            self.connection.execute('SELECT count(*) FROM passages').fetchone()

    def search(self, question, choices=(), limit=4):
        if self.connection is None:
            return []
        # Bind MATCH as data. Only normalized word tokens become query syntax.
        text = question + ' ' + ' '.join(choices)
        tokens = list(dict.fromkeys(t for t in re.findall(r'[a-zA-Z]{3,}', text.lower()) if t not in STOP))[:32]
        if not tokens:
            return []
        query = ' OR '.join('"' + t + '"' for t in tokens)
        rows = self.connection.execute(
            'SELECT page, text, bm25(passages) AS score FROM passages '
            'WHERE passages MATCH ? ORDER BY score LIMIT 20', (query,)).fetchall()
        results, pages = [], set()
        for page, content, score in rows:
            if page in pages:
                continue
            pages.add(page)
            results.append({'page':page, 'text':content})
            if len(results) >= limit:
                break
        return results

    def context(self, question, choices=()):
        hits = self.search(question, choices)
        if not hits:
            return '', []
        context = '\n\n'.join(f'[Biology 6th edition, PDF page {h["page"]}]\n{h["text"]}' for h in hits)
        return context, [h['page'] for h in hits]
