"""Client access configuration; an OpenAI key is never a shared-app token."""
import json
import os
import re
from pathlib import Path
from urllib.parse import urlsplit
from runtime_paths import APP_DIR, DATA_DIR

ROOT = APP_DIR


def shared_mode(root=ROOT):
    return (Path(root) / 'distribution.json').is_file() or bool(os.getenv('STUDY_PILOT_SERVER_URL'))


def server_url(value):
    value = str(value).strip().rstrip('/')
    parsed = urlsplit(value)
    try: parsed.port
    except ValueError: raise ValueError('El puerto de la dirección no es válido.') from None
    if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password
            or parsed.query or parsed.fragment or any(c.isspace() for c in value) or parsed.path not in ('', '/v1')):
        raise ValueError('La dirección del servidor debe ser HTTPS, sin usuario, contraseña ni parámetros.')
    return value if parsed.path == '/v1' else value + '/v1'


def validate_token(token):
    if not re.fullmatch(r'spc_[A-Za-z0-9_-]{40,100}', str(token)):
        raise ValueError('Introduce el código spc_ que te entregó el administrador, no una API key.')
    return token


def load_access(root=ROOT):
    root = Path(root)
    config = {}
    for path in (root / 'distribution.json', (DATA_DIR if root == ROOT else root) / 'access.json'):
        if path.is_file():
            try:
                item = json.loads(path.read_text(encoding='utf-8'))
                if not isinstance(item, dict): raise ValueError()
                config.update(item)
            except (ValueError, OSError):
                raise ValueError('Configuración de acceso inválida. Abre Mi cuenta y vuelve a entrar.') from None
    url = os.getenv('STUDY_PILOT_SERVER_URL') or config.get('server_url', '')
    token = os.getenv('STUDY_PILOT_ACCESS_TOKEN') or config.get('access_token', '')
    if not url or not token:
        raise ValueError('Falta activar tu acceso. Abre Mi cuenta y entra con tu correo y contraseña.')
    return server_url(url), validate_token(token)


def save_access(url, token, root=ROOT):
    data = {'server_url': server_url(url), 'access_token': validate_token(token.strip())}
    path = (DATA_DIR if Path(root) == ROOT else Path(root)) / 'access.json'
    temporary = path.with_suffix('.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        try: os.chmod(temporary, 0o600)
        except OSError: pass
        json.dump(data, handle, ensure_ascii=False, indent=2)
    temporary.replace(path)


def main():
    import getpass
    import httpx
    print('Study Pilot C - Activar acceso compartido')
    print('Tu administrador paga la API. Necesitas su URL y tu código individual.')
    try:
        url = server_url(input('URL HTTPS del servidor: '))
        token = validate_token(getpass.getpass('Código de acceso spc_ (no se muestra): ').strip())
        with httpx.Client(timeout=15, follow_redirects=False) as client:
            response = client.get(url + '/access', headers={'Authorization': 'Bearer ' + token})
        if response.status_code != 200:
            print('No se pudo activar el acceso. Revisa la URL y pide al administrador que compruebe tu código.')
            return 1
        data = response.json()
        if not isinstance(data,dict) or data.get('service') != 'study-pilot-c' or not data.get('active'):
            print('La dirección no corresponde a un servidor de Study Pilot C compatible.')
            return 1
        save_access(url, token)
        print('Acceso activado. Abre Iniciar Study Pilot C.bat.')
        return 0
    except (ValueError, OSError, httpx.HTTPError):
        print('No se pudo conectar o los datos no son válidos. Revisa la URL HTTPS y el código spc_.')
        return 1
    except (EOFError, KeyboardInterrupt):
        print('\nActivación cancelada.')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
