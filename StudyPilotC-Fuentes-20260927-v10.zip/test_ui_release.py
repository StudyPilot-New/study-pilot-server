"""Regression checks for the session form and compact browser panel."""
import json
from pathlib import Path
import tempfile
import tkinter as tk
import unittest
from unittest.mock import patch, MagicMock
from playwright.async_api import async_playwright
import desktop_ui
from desktop_ui import StudyPilot, validate_session_options
from overlay import update_overlay


class FormValidation(unittest.TestCase):
    def test_pacing_rejects_invalid_ranges_and_non_finite_confidence(self):
        for args in [('NaN','120','180'),('inf','120','180'),('.6','-1','180'),
                     ('.6','1.5','180'),('.6','1441','180'),('.6','120','0'),
                     ('.6','120','1001')]:
            with self.subTest(args=args), self.assertRaises(ValueError):
                validate_session_options(*args)
        self.assertEqual(validate_session_options('.6','120','180'),(.6,120,180))
        self.assertEqual(validate_session_options('.6','0','180'),(.6,0,180))


class DesktopControls(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=Path(self.temp.name)
        self.path_patch=patch.object(desktop_ui,'ROOT',self.path)
        self.path_patch.start()
        try:
            self.root=tk.Tk()
        except tk.TclError as exc:
            self.path_patch.stop();self.temp.cleanup()
            self.skipTest(str(exc))
        self.root.withdraw()
        self.app=StudyPilot(self.root)
        self.root.update_idletasks()
    def tearDown(self):
        if self.app.control:
            self.app.temp.cleanup()
        self.root.destroy()
        self.path_patch.stop();self.temp.cleanup()
    def test_session_form_defaults_and_error_reveals_settings(self):
        self.assertEqual(self.app.pacing_minutes.get(),'120')
        self.assertEqual(self.app.pacing_questions.get(),'180')
        self.assertIn('40 s/pregunta',self.app.pace_summary.get())
        self.assertFalse(self.app.book.get())
        self.app.pacing_questions.set('0')
        with patch.object(desktop_ui.subprocess,'Popen') as launch:
            self.app.start()
        launch.assert_not_called()
        self.assertEqual(self.app.notebook.select(),str(self.app.settings_tab))
        self.assertIn('entre 1 y 1000',self.app.detail.get())
        self.assertEqual(str(self.app.pause_button['state']),'disabled')
    def test_launch_persists_pacing_but_never_key(self):
        self.app.api.set('test-private-value')
        self.app.pacing_minutes.set('120');self.app.pacing_questions.set('180')
        proc=MagicMock();proc.stdout=iter([])
        with patch.object(desktop_ui.subprocess,'Popen',return_value=proc) as launch, \
             patch.object(desktop_ui.threading,'Thread'):
            self.app.start()
        env=launch.call_args.kwargs['env']
        self.assertEqual(env['PACING_MINUTES'],'120')
        self.assertEqual(env['PACING_QUESTIONS'],'180')
        prefs=(self.path/'desktop_settings.json').read_text()
        self.assertNotIn('test-private-value',prefs)
        self.assertNotIn('api',json.loads(prefs))
        self.assertEqual(json.loads(prefs)['pacing_questions'],'180')
        self.assertEqual(self.app.status.get(),'Iniciando navegador')
    def test_pause_and_resume_keep_existing_controls(self):
        self.app.process=MagicMock()
        self.app.control=self.path/'control.txt'
        self.app.temp=MagicMock()
        self.app.pause()
        self.assertEqual(self.app.control.read_text(),'pause')
        self.assertEqual(self.app.pause_button['text'],'Reanudar')
        self.app.pause()
        self.assertEqual(self.app.control.read_text(),'run')
        self.app.stop()
        self.assertEqual(self.app.control.read_text(),'stop')

    def test_live_pacing_writes_new_interval_without_relaunch(self):
        self.app.process=MagicMock()
        self.app.temp=MagicMock()
        self.app.control=self.path/'control.txt'
        self.app.pacing_mode.set('Por pregunta')
        self.app.pacing_seconds.set('25')
        with patch.object(desktop_ui.subprocess,'Popen') as launch:
            self.app.send_live_pacing()
            launch.assert_not_called()
        self.assertEqual(json.loads((self.path/'pacing.json').read_text()),{'minutes':75,'questions':180})
        self.assertIn('25 s/pregunta',self.app.pace_summary.get())
        self.assertEqual(json.loads((self.path/'desktop_settings.json').read_text())['pacing_seconds'],'25')
    def test_progress_counts_submission_not_repeated_placement(self):
        for line in ['McGraw fill: True','McGraw fill: True','Confidence submitted: Medium']:
            self.app.events.put(line)
        self.app.poll()
        self.assertEqual(self.app.total.get(),'1')
        self.app.events.put('No se pudo analizar la pregunta. Se reintentará.')
        self.app.poll()
        self.assertEqual(self.app.status.get(),'Reintentando el análisis')


class OverlayControls(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page(viewport={'width':1280,'height':800})
        await self.page.set_content('<button id="answer" style="position:fixed;right:16px;top:150px">Answer</button>')
    async def asyncTearDown(self):
        await self.browser.close();await self.pw.stop()
    async def test_compact_expand_escape_and_status_is_not_duplicated(self):
        status='Waiting for the next question'
        await update_overlay(self.page,'McGraw Hill',status,[{'type':'single choice','question':'Question?',
            'answer':'Example','confidence':.98,'explanation':'Explanation'}])
        root=self.page.locator('#webqa-overlay')
        toggle=root.get_by_role('button')
        self.assertEqual(await toggle.get_attribute('aria-expanded'),'false')
        self.assertLess((await root.bounding_box())['height'],100)
        self.assertEqual((await root.inner_text()).count(status),1)
        await toggle.click()
        self.assertEqual(await toggle.get_attribute('aria-expanded'),'true')
        self.assertIn('Example',await root.inner_text())
        await toggle.press('Escape')
        self.assertEqual(await toggle.get_attribute('aria-expanded'),'false')
        await toggle.click()
        await self.page.locator('#answer').focus()
        self.assertEqual(await toggle.get_attribute('aria-expanded'),'false')
    async def test_updates_keep_button_focus_and_escape_untrusted_text(self):
        item={'question':'<img src=x onerror="window.bad=true">','answer':'<script>alert(1)</script>',
              'type':'matching','confidence':1}
        await update_overlay(self.page,'Fixture','Ready',[item])
        toggle=self.page.locator('#webqa-overlay button')
        await toggle.click()
        await update_overlay(self.page,'Fixture','Applying',[item])
        self.assertTrue(await toggle.evaluate('(el)=>el===document.activeElement'))
        self.assertEqual(await self.page.locator('#webqa-overlay img,#webqa-overlay script').count(),0)
        self.assertIn('<script>alert(1)</script>',await self.page.locator('#webqa-overlay').inner_text())
    async def test_panel_fits_narrow_viewport(self):
        await self.page.set_viewport_size({'width':375,'height':600})
        await update_overlay(self.page,'Fixture','Ready',[])
        await self.page.locator('#webqa-overlay button').click()
        box=await self.page.locator('#webqa-overlay').bounding_box()
        self.assertGreaterEqual(box['x'],0)
        self.assertLessEqual(box['x']+box['width'],375)


if __name__=='__main__':unittest.main()
