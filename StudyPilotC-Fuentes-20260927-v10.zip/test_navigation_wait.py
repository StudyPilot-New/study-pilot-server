import unittest
from unittest.mock import AsyncMock,patch
from types import SimpleNamespace as NS
import mcgraw_actions as a


class Page:
    url='https://learning.mheducation.com/test'
    frames=[]


class NavigationWait(unittest.IsolatedAsyncioTestCase):
    async def test_disabled_wait_logs_once_and_resumes_when_enabled(self):
        page=Page();button=AsyncMock()
        with patch.object(a,'unique_button',side_effect=[None,None,button]),patch('builtins.print') as output:
            self.assertFalse(await a.submit_confidence(page,'Low',('q',)))
            self.assertFalse(await a.submit_confidence(page,'Low',('q',)))
            self.assertEqual(output.call_count,1)
            self.assertTrue(await a.submit_confidence(page,'Low',('q',)))
        button.click.assert_awaited_once()
        a.clear_navigation(page)

    async def test_next_without_feedback_heading_is_clicked_once(self):
        page=Page();button=AsyncMock()
        with patch.object(a,'screen_state',return_value={'feedback':False,'required':False,'textLength':10}),patch.object(a,'named_control',return_value=button):
            self.assertIn('Next Question clicked',await a.handle_feedback(page))
            self.assertIn('Waiting',await a.handle_feedback(page))
        button.click.assert_awaited_once()
        a.clear_navigation(page)

    async def test_no_enabled_next_or_confidence_does_not_click(self):
        page=Page()
        with patch.object(a,'screen_state',return_value={'feedback':False,'required':False,'textLength':10}),patch.object(a,'named_control',return_value=None):
            self.assertEqual(await a.handle_feedback(page),'')

if __name__=='__main__':unittest.main()
