"""Nonblocking real-time pacing. Estimated duration, never a platform timer."""
import math
import time


class SessionPacer:
    def __init__(self, minutes=120, questions=180, clock=time.monotonic):
        if not math.isfinite(minutes) or not 0 <= minutes <= 1440:
            raise ValueError('Duration must be between 0 and 1440 minutes')
        if not isinstance(questions, int) or not 1 <= questions <= 10000:
            raise ValueError('Estimated question count must be between 1 and 10000')
        self.minutes, self.questions, self.clock = minutes, questions, clock
        self.interval = minutes * 60 / questions
        self.completed = 0
        self.next_due = clock() + self.interval
        self.paused_at = None
        self.last_display = None

    def remaining(self):
        now = self.clock() if self.paused_at is None else self.paused_at
        return max(0, self.next_due - now)

    def reconfigure(self, minutes, questions):
        validated = SessionPacer(minutes, questions, self.clock)
        now = self.clock() if self.paused_at is None else self.paused_at
        elapsed = max(0, self.interval - self.remaining())
        self.minutes, self.questions, self.interval = validated.minutes, validated.questions, validated.interval
        self.next_due = now + max(0, self.interval - elapsed)
        self.last_display = None

    def submitted(self):
        self.completed += 1
        # Never catch up with a burst after a slow request or a failed question.
        self.next_due = max(self.next_due + self.interval, self.clock() + self.interval / 2)
        self.last_display = None

    def pause(self):
        if self.paused_at is None:
            self.paused_at = self.clock()

    def resume(self):
        if self.paused_at is not None:
            self.next_due += self.clock() - self.paused_at
            self.paused_at = None

    def message(self):
        seconds = math.ceil(self.remaining())
        return (f'Próxima respuesta en {seconds // 60:02d}:{seconds % 60:02d} · '
                f'{self.completed} enviadas · objetivo aproximado: {self.minutes:g} min / '
                f'{self.questions} preguntas. Las repeticiones pueden ampliar la sesión.')
