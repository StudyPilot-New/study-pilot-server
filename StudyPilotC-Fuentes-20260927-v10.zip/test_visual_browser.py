"""Regression tests with real Chrome: loaded figures and named popups."""
import unittest
from playwright.async_api import async_playwright
from visual_capture import capture_visual, enrich_visual_identity
from models import Question
from text_alternative import read_text_alternative


class VisualBrowserTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw = await async_playwright().start()
        self.browser = await self.pw.chromium.launch(channel='chrome', headless=True)
        self.context = await self.browser.new_context()
        self.page = await self.context.new_page()

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def test_sibling_figure_captured_without_overlay(self):
        await self.page.set_content('''<main><svg width="300" height="200">
        <rect width="300" height="200" fill="green"/></svg>
        <section data-webqa-qid="q">Which color?</section></main>
        <div id="webqa-overlay" style="position:fixed;inset:0;background:red">Wrong answer</div>''')
        images = await capture_visual(self.page.main_frame, 'q')
        import struct
        self.assertEqual(len(images), 1)
        self.assertEqual(struct.unpack('>II', images[0][16:24]), (300,200))
        import base64
        pixel = await self.page.evaluate('''async data => {
          const img=new Image();img.src='data:image/png;base64,'+data;await img.decode();
          const c=document.createElement('canvas');c.width=300;c.height=200;
          const ctx=c.getContext('2d');ctx.drawImage(img,0,0);
          return [...ctx.getImageData(150,100,1,1).data];
        }''',base64.b64encode(images[0]).decode())
        self.assertEqual(pixel[:3], [0,128,0])

    async def test_reused_description_and_unrelated_tab_preserved(self):
        await self.page.route('https://learning.mheducation.com/**',
            lambda route: route.fulfill(content_type='text/html', body='''
            <a href="#" onclick="const w=window.open('', 'description');
            w.document.open();w.document.write('<title>Text Alternative</title><h1>Figure Text Alternative</h1><p>Four fused carbon rings with hydroxyl substituents are visible.</p>');w.document.close();return false;">Text Alternative</a>'''))
        await self.page.goto('https://learning.mheducation.com/test')
        async with self.page.expect_popup() as event:
            await self.page.evaluate("""() => { const w=window.open('', 'description');
            w.document.write('<title>Text Alternative</title><body>Old question description</body>'); }""")
        existing = await event.value
        unrelated = await self.page.context.new_page()
        await unrelated.set_content('Unrelated work')
        result = await read_text_alternative(self.page,self.page.main_frame)
        self.assertIn('Four fused',result)
        self.assertFalse(existing.is_closed())
        self.assertFalse(unrelated.is_closed())

    async def test_multiple_figures_and_native_resolution(self):
        # A 600px source rendered at 150px must not lose its source detail.
        data = await self.page.evaluate('''() => {
          const c=document.createElement('canvas');c.width=600;c.height=400;
          c.getContext('2d').fillRect(0,0,600,400);return c.toDataURL();
        }''')
        await self.page.set_content(f'''<main><img src="{data}" width="150" height="100">
          <svg width="200" height="100"><circle cx="50" cy="50" r="40"/></svg>
          <section data-webqa-qid="q">Compare these figures.</section></main>''')
        images=await capture_visual(self.page.main_frame,'q')
        import struct
        self.assertEqual([struct.unpack('>II',x[16:24]) for x in images],[(600,400),(200,100)])

    async def test_broken_image_never_sent_as_valid_figure(self):
        await self.page.set_content('''<main><img width="200" height="120" src="data:image/png;base64,broken">
          <section data-webqa-qid="q">Identify the image.</section></main>''')
        with self.assertRaises(Exception):
            await capture_visual(self.page.main_frame,'q')

    async def test_canvas_change_invalidates_repeated_prompt(self):
        await self.page.set_content('''<main><canvas width="200" height="120"></canvas>
          <section data-webqa-qid="q">Identify the image.</section></main>''')
        first=Question('q','Identify the image.','fill_blank')
        await enrich_visual_identity(self.page.main_frame,first)
        await self.page.locator('canvas').evaluate("x=>x.getContext('2d').fillRect(0,0,100,100)")
        second=Question('q','Identify the image.','fill_blank')
        await enrich_visual_identity(self.page.main_frame,second)
        self.assertTrue(first.has_visual)
        self.assertNotEqual(first.html_hint,second.html_hint)


if __name__ == '__main__': unittest.main()
