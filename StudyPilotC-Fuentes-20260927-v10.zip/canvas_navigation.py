"""Advance Canvas only after stable verification of the current answer controls."""
import asyncio
import hashlib
import json
import re
import time
import unicodedata
from weakref import WeakKeyDictionary
from learning_adapter import extract_learning_questions


def _text(value):
    return " ".join(unicodedata.normalize('NFKC',str(value)).split()).casefold()


def question_identity(question):
    # DOM indexes/frame positions and answer order are not question identity.
    # Public Canvas IDs and the image identity distinguish repeated wording.
    payload=[question.kind,_text(question.text),
             sorted((c.control_type,_text(c.text)) for c in question.choices),
             question.html_hint or '']
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


async def current_question(frame, question):
    current=await extract_learning_questions(frame)
    expected=question_identity(question)
    matches=[]
    for fresh in current:
        if '|figure:' in question.html_hint:
            # Enrich only structurally equivalent candidates, never another
            # prompt merely because it acquired the same positional qid.
            if fresh.kind!=question.kind or _text(fresh.text)!=_text(question.text):continue
            from visual_capture import enrich_visual_identity
            await enrich_visual_identity(frame,fresh)
        if question_identity(fresh)==expected:matches.append(fresh)
    return matches[0] if len(matches)==1 else None


def _choice_key(value):
    value=_text(value).translate(str.maketrans({'−':'-','–':'-','—':'-'}))
    value=value.rstrip('.!?')
    # Math renderers split formulas between element/subscript nodes.
    if re.search(r'\d',value):value=re.sub(r'\s+','',value)
    return value


def expected_choices(question,answers):
    if not answers:return None
    matches=[]
    for answer in answers:
        candidates=[c for c in question.choices if _choice_key(c.text)==_choice_key(answer)]
        if len(candidates)!=1:return None
        matches.append(candidates[0].cid)
    expected=set(matches)
    if len(expected)!=len(answers) or (question.kind=='single_choice' and len(expected)!=1):return None
    return expected


def _root(frame,question):
    return frame.locator(f'[data-webqa-qid="{question.qid}"]')


def _fields(root):
    return root.locator('textarea[data-webqa-cid],input[data-webqa-cid],'
                        '[contenteditable="true"][data-webqa-cid]')


async def validate_answer(frame,question,answers):
    if not answers or any(not str(a).strip() for a in answers):return False
    fresh=await current_question(frame,question)
    if fresh is None:return False
    root=_root(frame,fresh)
    if await root.count()!=1:return False
    if fresh.kind in ('single_choice','multiple_choice'):
        return expected_choices(fresh,answers) is not None
    if fresh.kind=='text':return await _fields(root).count()==len(answers)
    if fresh.kind=='select':
        return len(answers)==1 and expected_choices(fresh,answers) is not None and await root.locator('select[data-webqa-cid]').count()==1
    return False


async def _selection_matches(frame,question,answers):
    fresh=await current_question(frame,question)
    if fresh is None:return False
    root=_root(frame,fresh)
    if await root.count()!=1:return False
    if fresh.kind in ('single_choice','multiple_choice'):
        expected=expected_choices(fresh,answers)
        return expected is not None and {c.cid for c in fresh.choices if c.checked}==expected
    if fresh.kind=='text':
        values=await _fields(root).evaluate_all("els=>els.map(e=>e.isContentEditable ? e.innerText : e.value)")
        normalize=lambda value:" ".join(unicodedata.normalize('NFKC',str(value)).split())
        return len(values)==len(answers) and [normalize(v) for v in values]==[normalize(a) for a in answers]
    if fresh.kind=='select' and len(answers)==1:
        expected=expected_choices(fresh,answers)
        if not expected:return False
        choice=next(c for c in fresh.choices if c.cid in expected)
        selects=root.locator('select[data-webqa-cid]')
        return await selects.count()==1 and await selects.input_value()==choice.value
    return False


async def answer_is_selected(frame,question,answers,stable_for=.55):
    if not answers or not await _selection_matches(frame,question,answers):return False
    # React can show checked immediately and revert it on a delayed render.
    # Never click Next based on that transient native state alone.
    until=time.monotonic()+stable_for
    while time.monotonic()<until:
        await asyncio.sleep(min(.12,max(.01,until-time.monotonic())))
        if not await _selection_matches(frame,question,answers):return False
    return True


async def _set_selection(control,wanted):
    info=await control.evaluate("e=>({native:e instanceof HTMLInputElement,checked:typeof e.checked==='boolean'?e.checked:e.getAttribute('aria-checked')==='true'})",timeout=1500)
    if info['checked']==wanted:return
    if info['native'] and await control.is_visible():
        await control.set_checked(wanted,timeout=1800)
    elif info['native']:
        # Styled Canvas inputs can be display:none while their labels are the
        # supported clickable surface. Use a real browser click on that label.
        handle=await control.evaluate_handle("""e=>{
            const visible=n=>{const r=n.getBoundingClientRect();return r.width>0 && r.height>0 && getComputedStyle(n).visibility!=='hidden';};
            const labels=[...e.labels||[]].filter(visible);
            return labels[0] || null;
        }""",timeout=1500)
        try:
            label=handle.as_element()
            if label is None:raise ValueError('La opción no tiene una etiqueta visible para seleccionarla.')
            await label.click(timeout=1800)
        finally:await handle.dispose()
    else:
        await control.click(timeout=1800)


async def restore_answer(frame,question,answers):
    if not await validate_answer(frame,question,answers):return False
    if question.kind in ('single_choice','multiple_choice'):
        # Reextract before every action: checking one choice can replace the
        # entire fieldset and change positional IDs for all remaining controls.
        labels=[c.text for c in question.choices]
        for label in labels:
            fresh=await current_question(frame,question)
            if fresh is None:return False
            expected=expected_choices(fresh,answers)
            if expected is None:return False
            matches=[c for c in fresh.choices if _choice_key(c.text)==_choice_key(label)]
            if len(matches)!=1:return False
            choice=matches[0];wanted=choice.cid in expected
            if question.kind=='single_choice' and not wanted:continue
            await _set_selection(_root(frame,fresh).locator(f'[data-webqa-cid="{choice.cid}"]'),wanted)
    elif question.kind=='text':
        for index,answer in enumerate(answers):
            fresh=await current_question(frame,question)
            if fresh is None:return False
            fields=_fields(_root(frame,fresh))
            if await fields.count()!=len(answers):return False
            await fields.nth(index).fill(str(answer),timeout=1800)
            # Blur through the keyboard; the input may have been remounted by
            # its onInput handler and no longer have the previous DOM marker.
            await getattr(frame,'page',frame).keyboard.press('Tab')
    elif question.kind=='select':
        fresh=await current_question(frame,question)
        if fresh is None:return False
        expected=expected_choices(fresh,answers)
        choice=next(c for c in fresh.choices if c.cid in expected)
        await _root(frame,fresh).locator('select[data-webqa-cid]').select_option(value=choice.value,timeout=1800)
    return await answer_is_selected(frame,question,answers)


class CanvasNavigation:
    def __init__(self,clock=time.monotonic):
        self.pages=WeakKeyDictionary();self.clock=clock

    def reset(self,page):self.pages.pop(page,None)

    def resume(self,page):
        state=self.pages.get(page)
        if state:
            state.update(attempts=0,clicked_at=None)
            for repair in state['repairs'].values():repair['after']=0

    def observe(self,page,fingerprint,pacer=None,found=None):
        if not fingerprint:return
        identities=tuple(sorted(question_identity(q) for _,_,q in found)) if found is not None else None
        previous=self.pages.get(page)
        same=previous and (previous.get('identities')==identities if identities is not None else previous['fingerprint']==fingerprint)
        if same:
            previous['fingerprint']=fingerprint
            return
        if previous and previous['clicked_at'] is not None and pacer is not None:pacer.submitted()
        retained=set(identities or ())
        self.pages[page]={'fingerprint':fingerprint,'identities':identities,
            'answers':{k:v for k,v in previous['answers'].items() if k in retained} if previous else {},
            'clicked_at':None,'attempts':0,
            'repair_cursor':0,
            'repairs':{k:v for k,v in previous['repairs'].items() if k in retained} if previous else {},
            'recovery':None,'last_recovery':previous.get('last_recovery',-1000) if previous else -1000}

    def remember(self,page,frame_index,question,signature,answers):
        state=self.pages.get(page)
        if state:
            key=question_identity(question)
            state['answers'][key]=list(answers)
            state['repairs'].setdefault(key,{'attempts':0,'after':self.clock()+.5,'reason':''})

    def take_recovery_request(self,page):
        state=self.pages.get(page)
        if not state:return None
        reason=state.get('recovery')
        state['recovery']=None
        return reason

    def _request_recovery(self,state,reason):
        if self.clock()-state['last_recovery']>=30:
            state['last_recovery']=self.clock();state['recovery']=reason

    async def advance(self,page,found,signature,pacer=None):
        state=self.pages.get(page)
        if not state or not found:return ''
        if pacer is not None and pacer.paused_at is not None:return pacer.message()
        if state['clicked_at'] is not None:
            delay=min(30,8*max(1,state['attempts']))
            left=delay-(self.clock()-state['clicked_at'])
            if left>0:return f'Canvas: Next pulsado; esperando la siguiente pregunta ({max(1,int(left))} s).'
            if state['attempts']>=3:self._request_recovery(state,'Next no produjo una transición confirmada.')
        keys=[question_identity(q) for _,_,q in found]
        if len(set(keys))!=len(keys):return 'Canvas: hay preguntas indistinguibles; volviendo a detectar sus controles.'
        # A failed remembered answer must not starve later unanswered questions.
        if any(key not in state['answers'] for key in keys):return ''
        waiting_message=''
        start=state.get('repair_cursor',0)%len(found)
        for offset in range(len(found)):
            position=(start+offset)%len(found)
            key=keys[position]
            _,frame,q=found[position]
            answers=state['answers'][key]
            if not await answer_is_selected(frame,q,answers):
                if await current_question(frame,q) is None:
                    return 'Canvas: la pregunta está cambiando; volviendo a detectar sus controles.'
                if not await validate_answer(frame,q,answers):
                    state['answers'].pop(key,None);state['repairs'].pop(key,None)
                    return ''
                repair=state['repairs'].setdefault(key,{'attempts':0,'after':0,'reason':''})
                if self.clock()<repair['after']:
                    left=max(1,int(repair['after']-self.clock()))
                    waiting_message=f"Canvas: reintento {repair['attempts']+1} de selección en {left} s. {repair.get('reason') or 'Verificando los controles actuales.'}"
                    continue
                repair['attempts']+=1
                repair['after']=self.clock()+min(10,2**min(repair['attempts']-1,4))
                # Rotate after each attempt. A control that keeps rejecting
                # selection must not prevent repairing other known answers.
                state['repair_cursor']=(position+1)%len(found)
                try:
                    restored=await restore_answer(frame,q,answers)
                    repair['reason']='Canvas no conservó la selección después de aplicarla.'
                except Exception as exc:
                    restored=False;repair['reason']=str(exc).splitlines()[0][:180] or type(exc).__name__
                if restored:return 'Canvas: selección restablecida; verificando antes de continuar.'
                if repair['attempts']>=3:self._request_recovery(state,repair['reason'])
                return f"Canvas: recuperando la selección (intento {repair['attempts']}). {repair['reason']}"
            state['repairs'].pop(key,None)
        if waiting_message:return waiting_message
        if pacer is not None and (pacer.paused_at is not None or pacer.remaining()>0):return pacer.message()
        candidates=[]
        for frame in page.frames:
            for role in ('button','link'):
                for button in await frame.get_by_role(role,name=re.compile(r'^\s*(?:Next(?:\s+Question)?|Siguiente(?:\s+pregunta)?)\s*[▶►›»→]?\s*$',re.I)).all():
                    if await button.is_visible() and await button.is_enabled() and await button.get_attribute('aria-disabled')!='true':candidates.append(button)
        if len(candidates)!=1:
            return 'Canvas: esperando un botón Next disponible y único. El envío final del cuestionario requiere revisión manual.'
        # Recheck after locating Next: never act on a newly rendered question.
        for key,(_,frame,q) in zip(keys,found):
            if not await answer_is_selected(frame,q,state['answers'][key]):return ''
        state['clicked_at']=self.clock();state['attempts']+=1
        try:await candidates[0].click(timeout=2500)
        except Exception:return 'Canvas: comprobando si Next respondió antes de reintentar.'
        return 'Canvas: Next pulsado; esperando la siguiente pregunta.'
