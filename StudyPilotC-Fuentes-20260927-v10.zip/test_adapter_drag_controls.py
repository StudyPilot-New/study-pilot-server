"""Local browser fixtures for semantic tile labels and transient drag previews."""
import unittest

from playwright.async_api import async_playwright

from mcgraw_adapter import extract_mcgraw_question


class AdapterDragControls(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw = await async_playwright().start()
        self.browser = await self.pw.chromium.launch(channel='chrome', headless=True)
        self.page = await self.browser.new_page(viewport={'width': 1300, 'height': 900})

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def matching_fixture(self):
        await self.page.set_content('''<h1>Matching Question</h1>
          <p>Match each structure to the description of its components.</p>
          <div class="dropzone" aria-label="Primary drop zone empty" style="height:80px;width:600px"></div>
          <div class="dropzone" aria-label="Secondary drop zone empty" style="height:80px;width:600px"></div>
          <div style="height:40px"></div><div id="bank"></div>''')

    async def test_matching_accessibility_helper_is_not_answer_text(self):
        await self.matching_fixture()
        await self.page.locator('#bank').evaluate('''el => {
          for (const [i, text] of ['Linear sequence of amino acids', 'Repetitive folding patterns'].entries()) {
            const tile = document.createElement('div');
            tile.setAttribute('role', 'button');
            tile.setAttribute('aria-grabbed', 'false');
            tile.setAttribute('aria-label', `Choice ${i + 1} of 2. ${text}`);
            tile.style.cssText = 'height:80px;width:600px';
            tile.innerHTML = `<span>Choice ${i + 1} of 2. ${text} toggle button</span><p>${text}</p>`;
            el.append(tile);
          }
        }''')
        question = (await extract_mcgraw_question(self.page.main_frame))[0]
        self.assertEqual([c.text for c in question.choices],
                         ['Linear sequence of amino acids', 'Repetitive folding patterns'])

    async def test_matching_refresh_binds_real_tile_instead_of_portal_preview(self):
        await self.matching_fixture()
        await self.page.locator('#bank').evaluate('''el => {
          el.innerHTML = '<div id="first" aria-grabbed="false" style="height:80px;width:600px">Linear sequence</div>' +
            '<div aria-grabbed="false" style="height:80px;width:600px">Repeated folding</div>';
        }''')
        question = (await extract_mcgraw_question(self.page.main_frame))[0]
        await self.page.locator('#first').evaluate('''el => {
          const preview = el.cloneNode(true);
          preview.id = 'preview';
          preview.className = 'cdk-drag-preview';
          preview.style.cssText += ';position:absolute;top:400px;left:650px';
          document.body.prepend(preview);
        }''')
        refreshed = (await extract_mcgraw_question(self.page.main_frame))[0]
        self.assertEqual([c.text for c in refreshed.choices], [c.text for c in question.choices])
        cid = next(c.cid for c in refreshed.choices if c.text == 'Linear sequence')
        self.assertEqual(await self.page.locator(f'[data-webqa-cid="{cid}"]').get_attribute('id'), 'first')
        self.assertIsNone(await self.page.locator('#preview').get_attribute('data-webqa-cid'))

    async def test_ordering_refresh_does_not_count_portal_preview_as_another_answer(self):
        await self.page.set_content('''<h1>Ordering Question</h1>
          <p>Place the stages in chronological order starting with the first.</p>
          <div id="list">
            <div id="first" tabindex="0" aria-grabbed="false" style="height:80px;width:600px">First stage</div>
            <div tabindex="0" aria-grabbed="false" style="height:80px;width:600px">Second stage</div>
            <div tabindex="0" aria-grabbed="false" style="height:80px;width:600px">Third stage</div>
          </div><p>Need help? Review resources.</p>''')
        question = (await extract_mcgraw_question(self.page.main_frame))[0]
        await self.page.locator('#first').evaluate('''el => {
          const preview = el.cloneNode(true);
          preview.id = 'preview';
          preview.className = 'gu-mirror';
          preview.style.cssText += ';position:absolute;top:175px;left:650px';
          document.body.append(preview);
        }''')
        refreshed = (await extract_mcgraw_question(self.page.main_frame))[0]
        self.assertEqual([c.text for c in refreshed.choices], [c.text for c in question.choices])
        self.assertEqual(await self.page.locator('[data-webqa-order-item]').count(), 3)
        self.assertIsNone(await self.page.locator('#preview').get_attribute('data-webqa-cid'))


if __name__ == '__main__':
    unittest.main()
