"""The app's real session panel must not intercept Canvas form interaction."""
import asyncio
from dataclasses import replace
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock,patch

from playwright.async_api import async_playwright

import app
from canvas_navigation import CanvasNavigation
from models import Answer
from overlay import update_overlay,page_controls_available


class CanvasOverlayRecovery(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.context=await self.browser.new_context(viewport={'width':1200,'height':850})
        await self.context.route('**/*',lambda route:route.fulfill(content_type='text/html',body='<main></main>'))
        self.page=await self.context.new_page()
        await self.page.goto('https://school.instructure.com/courses/42/quizzes/5/take')

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def check_covered_form(self,expanded):
        next_top=105 if expanded else 32
        await self.page.set_content('''<section class="question" data-question-id="covered-question"><p class="question_text">Choose the confirmation.</p>
<label style="position:fixed;right:50px;top:175px;width:170px;height:35px"><input type="radio" name="q">Confirm</label></section>
<button id="next" style="position:fixed;right:60px;top:'''+str(next_top)+'''px;width:110px;height:35px" onclick="window.nextClicks=(window.nextClicks||0)+1;window.selectedAtNext=document.querySelector('input').checked">Next</button>''')
        await update_overlay(self.page,'Canvas','Esperando que Canvas se estabilice.',[{
            'question':'Choose the confirmation.','answer':'Confirm','confidence':1,
            'explanation':'Fixture panel overlapping form controls.'}])
        if expanded:await self.page.locator('#webqa-overlay .pilot-toggle').click()
        before=await self.page.locator('#webqa-overlay').get_attribute('data-expanded')
        covered=await self.page.locator('#next').evaluate('e=>{const r=e.getBoundingClientRect();return !!document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)?.closest("#webqa-overlay")}')
        self.assertTrue(covered,'Fixture failed to position Next beneath the real session panel')
        async def answer(_page,_frame,question,*args,**kwargs):
            return Answer(question.qid,question.kind,['Confirm'],.99),''
        solve=AsyncMock(side_effect=answer)
        settings=replace(app.settings,mode='fill',use_vision='never',pacing_minutes=0,min_confidence=.6)
        with patch.object(app,'settings',settings),patch.object(app,'_canvas_navigation',CanvasNavigation()), \
             patch.object(app,'solve_with_visual_evidence',solve):
            await app.analyze_page(self.page,SimpleNamespace(memory=None),{})
        self.assertEqual(await self.page.evaluate('window.nextClicks||0'),1)
        self.assertTrue(await self.page.evaluate('window.selectedAtNext'))
        self.assertEqual(solve.await_count,1)
        self.assertEqual(await self.page.locator('#webqa-overlay').get_attribute('data-expanded'),before)
        self.assertEqual(await self.page.locator('#webqa-overlay').evaluate('e=>getComputedStyle(e).pointerEvents'),'auto')
        self.assertEqual(await self.page.locator('#webqa-overlay .pilot-toggle').evaluate('e=>getComputedStyle(e).pointerEvents'),'auto')
        self.assertTrue(await self.page.locator('#webqa-overlay').is_visible())

    async def test_expanded_panel_does_not_block_answer_or_next(self):
        await self.check_covered_form(True)

    async def test_collapsed_panel_does_not_block_next(self):
        await self.check_covered_form(False)

    async def test_guard_restores_interaction_after_error_and_cancellation(self):
        await update_overlay(self.page,'Canvas','Fixture status',[])
        await self.page.locator('#webqa-overlay .pilot-toggle').click()
        with self.assertRaises(RuntimeError):
            async with page_controls_available(self.page):
                self.assertEqual(await self.page.locator('#webqa-overlay').evaluate('e=>getComputedStyle(e).pointerEvents'),'none')
                raise RuntimeError('Fixture interaction failed')
        entered=asyncio.Event()
        async def blocked():
            async with page_controls_available(self.page):
                entered.set()
                await asyncio.Event().wait()
        task=asyncio.create_task(blocked())
        await asyncio.wait_for(entered.wait(),2)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):await task
        self.assertEqual(await self.page.locator('#webqa-interaction-style').count(),0)
        self.assertIsNone(await self.page.locator('#webqa-overlay').get_attribute('data-pilot-interacting'))
        self.assertEqual(await self.page.locator('#webqa-overlay').evaluate('e=>getComputedStyle(e).pointerEvents'),'auto')
        self.assertEqual(await self.page.locator('#webqa-overlay').get_attribute('data-expanded'),'true')


if __name__=='__main__':unittest.main()
