"""Local Canvas-style fixtures for accessible and remounted answer controls."""
import unittest

from playwright.async_api import async_playwright

from learning_adapter import extract_learning_questions


class CanvasDynamicControls(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw = await async_playwright().start()
        self.browser = await self.pw.chromium.launch(channel='chrome', headless=True)
        self.page = await self.browser.new_page()

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def test_native_inputs_inside_aria_wrappers_are_each_one_answer(self):
        await self.page.set_content('''<div class="question" id="question_42">
          <div class="question_text">Choose the matching example.</div>
          <label role="radio" aria-checked="false"><input type="radio" name="choice" value="a">Alpha</label>
          <label role="radio" aria-checked="false"><input type="radio" name="choice" value="b">Beta</label>
        </div><script>document.addEventListener('change',()=>{
          document.querySelectorAll('[role="radio"]').forEach(el=>el.setAttribute('aria-checked',String(el.querySelector('input').checked)));
        });</script>''')
        question = (await extract_learning_questions(self.page))[0]
        self.assertEqual([c.text for c in question.choices], ['Alpha', 'Beta'])
        self.assertEqual(await self.page.locator('input[data-webqa-cid]').count(), 2)
        self.assertEqual(await self.page.locator('label[data-webqa-cid]').count(), 0)
        await self.page.locator('input[value="b"]').check()
        fresh = (await extract_learning_questions(self.page))[0]
        self.assertEqual([c.text for c in fresh.choices if c.checked], ['Beta'])

    async def test_custom_button_radios_use_accessible_name_and_semantic_type(self):
        await self.page.set_content('''<div class="question">
          <div class="question_text">Choose the matching example.</div>
          <span id="alpha">Alpha</span><span id="details">example</span>
          <button role="radio" aria-labelledby="alpha details" aria-checked="false">○</button>
          <span id="beta">Beta example</span>
          <button role="radio" aria-labelledby="beta" aria-checked="true">●</button>
        </div>''')
        question = (await extract_learning_questions(self.page))[0]
        self.assertEqual(question.kind, 'single_choice')
        self.assertEqual([c.text for c in question.choices], ['Alpha example', 'Beta example'])
        self.assertEqual([c.control_type for c in question.choices], ['radio', 'radio'])
        self.assertEqual([c.checked for c in question.choices], [False, True])

    async def test_public_question_identity_survives_positional_cid_reassignment(self):
        def question(ident):
            return f'''<div class="question" data-question-id="{ident}" id="render-{ident}">
              <div class="question_text">Choose the matching example.</div>
              <label><input type="radio" name="{ident}">Alpha</label>
              <label><input type="radio" name="{ident}">Beta</label></div>'''
        await self.page.set_content(question('q-41') + question('q-42'))
        before = await extract_learning_questions(self.page)
        self.assertNotEqual(before[0].html_hint, before[1].html_hint)
        await self.page.locator('[data-question-id="q-41"]').evaluate('el=>el.remove()')
        await self.page.locator('[data-question-id="q-42"]').evaluate("el=>el.id='remounted-q-42'")
        after = (await extract_learning_questions(self.page))[0]
        self.assertNotEqual(before[1].qid, after.qid)
        self.assertEqual(before[1].html_hint, after.html_hint)
        self.assertIn('|question:q-42', after.html_hint)

    async def test_hidden_native_with_visible_label_remains_in_answer_set(self):
        await self.page.set_content('''<div class="question">
          <div class="question_text">Choose the matching example.</div>
          <input id="alpha" type="radio" name="choice" style="display:none"><label for="alpha">Alpha</label>
          <input id="beta" type="radio" name="choice" style="display:none"><label for="beta">Beta</label>
        </div>''')
        question = (await extract_learning_questions(self.page))[0]
        self.assertEqual([c.text for c in question.choices], ['Alpha', 'Beta'])
        await self.page.locator('label[for="beta"]').click()
        fresh = (await extract_learning_questions(self.page))[0]
        self.assertEqual([c.text for c in fresh.choices if c.checked], ['Beta'])


if __name__ == '__main__':
    unittest.main()
