import asyncio
import unittest
import time
from contextlib import ExitStack
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch

import app
import recovery
from models import Answer,Choice,Question


class Page:
    url='https://learning.mheducation.com/watchdog-fixture'


class WatchdogRecovery(unittest.IsolatedAsyncioTestCase):
    async def test_scan_timeout_cancels_before_reset_and_preserves_candidate(self):
        page=Page();events=[];seen={'q':'old'};candidate=object()
        app._solve_retries[page]={'q':{'candidate':candidate}}
        async def stuck(*args):
            try:
                await asyncio.Event().wait()
            finally:
                events.append('cancelled')
        async def reset(*args):
            events.append('reset');return True
        with patch.object(app,'choose_target_page',AsyncMock(return_value=page)),patch.object(app,'analyze_page',stuck),patch.object(recovery,'release_input',AsyncMock()) as release,patch.object(recovery,'recover_page',reset):
            self.assertEqual(await app.watch_cycle(object(),object(),seen,timeout=.025),(page,0))
        self.assertEqual(events,['cancelled','reset'])
        release.assert_awaited_once_with(page)
        self.assertFalse(seen)
        self.assertIs(app._solve_retries[page]['q']['candidate'],candidate)

    async def test_first_fill_timeout_reuses_fresh_analysis_without_recapturing(self):
        page=Page();frame=Page();seen={};events=[];fills=[]
        question=Question('q','Which label belongs here?','single_choice',
                          [Choice('a','First','radio'),Choice('b','Second','radio')])
        answer=Answer('q','single_choice',['First'],.99)
        async def fill(*args):
            fills.append(args[-1])
            if len(fills)==1:
                try:await asyncio.Event().wait()
                finally:events.append('cancelled')
            return {'filled':True,'details':'verified'}
        async def reset(*args):
            events.append('reset');return True
        with ExitStack() as stack:
            stack.enter_context(patch.object(app,'settings',replace(app.settings,
                mode='fill',mcgraw_auto=True,pacing_minutes=0,use_vision='always',min_confidence=.5)))
            stack.enter_context(patch.object(app,'choose_target_page',AsyncMock(return_value=page)))
            stack.enter_context(patch.object(app,'identify_site',AsyncMock(return_value=('McGraw Hill',True))))
            stack.enter_context(patch('question_resources.restore_question_resource',AsyncMock(return_value=True)))
            stack.enter_context(patch.object(app,'handle_feedback',AsyncMock(return_value='')))
            stack.enter_context(patch.object(app,'collect_questions_from_frames',AsyncMock(return_value=[(0,frame,question)])))
            stack.enter_context(patch.object(app,'advance_pending',AsyncMock(return_value=False)))
            stack.enter_context(patch.object(app,'has_text_alternative',AsyncMock(return_value=False)))
            capture=stack.enter_context(patch.object(app,'capture_visual',AsyncMock(return_value=[b'fixture-image'])))
            solve=stack.enter_context(patch.object(app,'solve_with_visual_evidence',AsyncMock(return_value=(answer,''))))
            stack.enter_context(patch.object(app,'allowed_mcgraw',return_value=True))
            stack.enter_context(patch.object(app,'extract_mcgraw_question',AsyncMock(return_value=[question])))
            stack.enter_context(patch.object(app,'enrich_visual_identity',AsyncMock()))
            stack.enter_context(patch.object(app,'fill_mcgraw_answer',fill))
            stack.enter_context(patch.object(app,'update_overlay',AsyncMock()))
            submit=stack.enter_context(patch.object(app,'submit_paced_confidence',AsyncMock(return_value=True)))
            stack.enter_context(patch.object(recovery,'release_input',AsyncMock()))
            stack.enter_context(patch.object(recovery,'recover_page',reset))
            self.assertEqual(await app.watch_cycle(object(),SimpleNamespace(),seen,timeout=.1),(page,0))
            self.assertEqual(events,['cancelled','reset'])
            self.assertIs(app._solve_retries[page]['0:q']['candidate'],answer)
            submit.assert_not_awaited()
            self.assertEqual(await app.watch_cycle(object(),SimpleNamespace(),seen,timeout=1),(page,1))
            solve.assert_awaited_once();capture.assert_awaited_once()
            submit.assert_awaited_once()
        self.assertEqual(fills,[['First'],['First']])
        self.assertEqual(seen,{'0:q':app.signature(question)})
        self.assertFalse(app._solve_retries.get(page))

    async def test_two_failed_scans_trigger_recovery_but_success_clears_streak(self):
        page=Page();seen={}
        with patch.object(app,'choose_target_page',AsyncMock(return_value=page)),patch.object(app,'analyze_page',AsyncMock(side_effect=[RuntimeError(),RuntimeError(),1,RuntimeError()])),patch.object(recovery,'release_input',AsyncMock()),patch.object(recovery,'recover_page',AsyncMock(return_value=True)) as reset:
            for _ in range(4):await app.watch_cycle(object(),object(),seen)
        self.assertEqual(reset.await_count,1)
        self.assertEqual(app._watch_errors[page],1)

    async def test_user_cancellation_releases_input_without_reloading(self):
        page=Page();entered=asyncio.Event()
        async def stuck(*args):
            entered.set();await asyncio.Event().wait()
        with patch.object(app,'choose_target_page',AsyncMock(return_value=page)),patch.object(app,'analyze_page',stuck),patch.object(recovery,'release_input',AsyncMock()) as release,patch.object(recovery,'recover_page',AsyncMock()) as reset:
            scan=asyncio.create_task(app.watch_cycle(object(),object(),{}))
            await entered.wait();scan.cancel()
            with self.assertRaises(asyncio.CancelledError):await scan
        release.assert_awaited_once_with(page)
        reset.assert_not_awaited()

    async def test_question_heading_without_controls_recovers_but_reading_does_not(self):
        page=Page();seen={};app._question_epochs[page]=('prior-question',)
        from contextlib import ExitStack
        with ExitStack() as stack:
            stack.enter_context(patch.object(app,'settings',replace(app.settings,mode='fill',mcgraw_auto=True)))
            stack.enter_context(patch.object(app,'identify_site',AsyncMock(return_value=('McGraw Hill',True))))
            stack.enter_context(patch('question_resources.restore_question_resource',AsyncMock(return_value=True)))
            stack.enter_context(patch.object(app,'handle_feedback',AsyncMock(return_value='')))
            stack.enter_context(patch.object(app,'collect_questions_from_frames',AsyncMock(return_value=[])))
            stack.enter_context(patch.object(app,'advance_pending',AsyncMock(return_value=False)))
            stack.enter_context(patch.object(app,'update_overlay',AsyncMock()))
            screen=stack.enter_context(patch('mcgraw_actions.screen_state',AsyncMock()))
            reset=stack.enter_context(patch.object(recovery,'recover_page',AsyncMock(return_value=True)))
            app._blank_since[page]=time.monotonic()-9
            screen.return_value={'textLength':200,'question':True,'feedback':False,'required':False}
            await app.analyze_page(page,SimpleNamespace(),seen)
            reset.assert_awaited_once()
            app._blank_since[page]=time.monotonic()-9
            screen.return_value={'textLength':200,'question':False,'feedback':False,'required':False}
            await app.analyze_page(page,SimpleNamespace(),seen)
            self.assertEqual(reset.await_count,1)


if __name__=='__main__':unittest.main()
