@echo off
setlocal
cd /d "%~dp0"
echo Study Pilot C - preparacion inicial
echo Necesitas Python 3.11 o superior y Google Chrome en este equipo.
echo.
if exist ".venv\Scripts\python.exe" goto dependencies
where py >nul 2>nul
if not errorlevel 1 goto python_launcher
where python >nul 2>nul
if errorlevel 1 goto missing_python
python -c "import sys, tkinter; sys.exit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 goto invalid_python
python -m venv .venv
if errorlevel 1 goto failed
goto dependencies
:python_launcher
py -3 -c "import sys, tkinter; sys.exit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 goto invalid_python
py -3 -m venv .venv
if errorlevel 1 goto failed
:dependencies
".venv\Scripts\python.exe" -m pip install -r requirements-release.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" verify_install.py
if errorlevel 1 goto failed
echo.
echo Instalacion lista. Abre "Iniciar Study Pilot C.bat".
if exist "distribution.json" (
  echo Ejecuta "Configurar acceso.bat" con la URL y el codigo que te entregaron.
) else (
  echo Escribe tu propia clave API en Ajustes de sesion.
)
pause
exit /b 0
:missing_python
echo No se encontro Python. Instala Python 3.11 o superior desde python.org.
echo Incluye Tcl/Tk y marca "Add python.exe to PATH" durante la instalacion.
pause
exit /b 1
:invalid_python
echo La instalacion requiere Python 3.11 o superior con Tcl/Tk.
echo Revisa tu instalacion de Python y vuelve a ejecutar este archivo.
pause
exit /b 1
:failed
echo.
echo No se pudo completar la instalacion. Revisa el mensaje anterior.
echo Comprueba tu conexion a Internet y que puedas escribir en esta carpeta.
pause
exit /b 1
