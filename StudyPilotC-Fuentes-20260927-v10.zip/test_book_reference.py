import sqlite3
import tempfile
import unittest
from pathlib import Path
from book_reference import BookReference

class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=Path(self.tmp.name)/'book.sqlite3'
        db=sqlite3.connect(self.path)
        db.execute('CREATE VIRTUAL TABLE passages USING fts5(page UNINDEXED,text)')
        db.executemany('INSERT INTO passages VALUES (?,?)',[(42,'Structural isomers differ in covalent bond arrangement.'),(42,'Another discussion of structural isomers.'),(80,'Mitochondria produce ATP through oxidative phosphorylation.')])
        db.commit();db.close()
        self.book=BookReference(self.path)
    def tearDown(self):
        self.book.connection.close()
        self.tmp.cleanup()
    def test_relevant_result(self):
        self.assertEqual(self.book.search('Where does oxidative phosphorylation produce ATP?')[0]['page'],80)
    def test_duplicate_pages_removed(self):
        self.assertEqual(len(self.book.search('structural isomers')),1)
    def test_page_attribution(self):
        context,pages=self.book.context('structural isomers')
        self.assertEqual(pages,[42]);self.assertIn('PDF page 42',context)
    def test_empty_query(self):self.assertEqual(self.book.search('What is the?'),[])
    def test_query_punctuation(self):self.book.search('" OR * - : structural isomers')
    def test_missing_file(self):self.assertEqual(BookReference(self.path.parent/'missing.db').search('biology'),[])

if __name__=='__main__':unittest.main()
