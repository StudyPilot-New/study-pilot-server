import unittest
from playwright.async_api import async_playwright
from learning_adapter import extract_learning_questions
from dom import fill_answer
from matcher import best_choice

class CanvasExtractionTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.pw=await async_playwright().start()
  self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
  self.page=await self.browser.new_page()
 async def asyncTearDown(self):
  await self.browser.close();await self.pw.stop()
 def question(self,ident,prompt,kind='radio'):
  return f'''<div class="question" id="question_{ident}"><h2>Question {ident}</h2>
   <div class="question_text">{prompt}<img alt="Question diagram" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"></div>
   <fieldset><legend>Group of answer choices</legend>
   <label><input type="{kind}" name="q{ident}" value="a">First option</label>
   <label><input type="{kind}" name="q{ident}" value="b">Second option</label></fieldset></div>'''
 async def test_canvas_nested_choices_keep_prompt_image_and_next_question(self):
  await self.page.set_content(self.question(1,'Ability is considered a(n) ______ and ______ attribute.'))
  q=(await extract_learning_questions(self.page))[0]
  self.assertEqual(q.text,'Ability is considered a(n) ______ and ______ attribute.')
  self.assertTrue(q.has_visual);self.assertEqual(q.kind,'single_choice')
  self.assertEqual([c.text for c in q.choices],['First option','Second option'])
  self.assertTrue((await fill_answer(self.page,q,['Second option'],best_choice))['filled'])
  self.assertEqual(await self.page.locator('input:checked').input_value(),'b')
  self.assertEqual(await self.page.locator('[data-webqa-qid] .question_text').count(),1)
  await self.page.set_content(self.question(2,'Choose a different example.'))
  next_q=(await extract_learning_questions(self.page))[0]
  self.assertNotEqual(q.text,next_q.text)
  self.assertTrue((await fill_answer(self.page,next_q,['First option'],best_choice))['filled'])
 async def test_separate_questions_and_multiple_selections(self):
  await self.page.set_content('<div data-question-id="wrapper">'+self.question(1,'Select both options.','checkbox')+self.question(2,'Choose one option.')+'</div>')
  found=await extract_learning_questions(self.page)
  self.assertEqual(len(found),2)
  self.assertEqual(found[0].kind,'multiple_choice')
  self.assertTrue((await fill_answer(self.page,found[0],['First option','Second option'],best_choice))['filled'])
  self.assertEqual(await self.page.locator('#question_1 input:checked').count(),2)
  self.assertEqual(await self.page.locator('#question_2 input:checked').count(),0)
 async def test_standalone_fieldset_aria_prompt_and_utility_rejection(self):
  await self.page.set_content('<p id="prompt">Which example applies?</p><fieldset aria-labelledby="prompt"><legend>Group of answer choices</legend><label><input type="radio">Example</label></fieldset>')
  self.assertEqual((await extract_learning_questions(self.page))[0].text,'Which example applies?')
  await self.page.set_content('<fieldset><legend>Group of answer choices</legend><label><input type="radio">Example</label></fieldset>')
  self.assertEqual(await extract_learning_questions(self.page),[])

if __name__=='__main__':unittest.main()
