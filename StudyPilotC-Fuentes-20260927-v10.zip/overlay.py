"""Compact, accessible in-page session panel."""
import asyncio
from contextlib import asynccontextmanager

OVERLAY_JS = r"""
(payload) => {
  const id = 'webqa-overlay';
  let root = document.getElementById(id);
  if (root && root.dataset.pilotVersion !== '2') { root.remove(); root = null; }
  if (!root) {
    root = document.createElement('aside');
    root.id = id;
    root.dataset.pilotVersion = '2';
    root.setAttribute('aria-label', 'Study Pilot C');
    root.innerHTML = `
      <style>
        #webqa-overlay {position:fixed;right:16px;top:16px;width:230px;max-width:calc(100vw - 32px);
          z-index:2147483647;box-sizing:border-box;background:#142c3c;color:#fff;
          border:1px solid #34566a;border-radius:14px;box-shadow:0 8px 26px #142c3c30;
          font:13px/1.5 'Segoe UI',system-ui,sans-serif;pointer-events:auto;text-align:left;}
        #webqa-overlay * {box-sizing:border-box;}
        #webqa-overlay button {font:600 13px/1.4 'Segoe UI',system-ui,sans-serif;color:#fff;
          background:transparent;cursor:pointer;border:0;letter-spacing:normal;text-transform:none;}
        #webqa-overlay button:focus-visible {outline:3px solid #a7f3d0;outline-offset:-4px;}
        #webqa-overlay .pilot-toggle {display:flex;align-items:center;justify-content:space-between;
          width:100%;min-height:48px;padding:12px 14px;gap:12px;text-align:left;border-radius:14px;}
        #webqa-overlay .pilot-toggle:hover {background:#24485d;}
        #webqa-overlay .pilot-brand {font-size:14px;font-weight:700;color:white;}
        #webqa-overlay .pilot-toggle-label {font-size:11px;font-weight:600;color:#a7f3d0;}
        #webqa-overlay .pilot-status {margin:0;padding:0 14px 12px;color:#c4d4df;
          font:12px/1.5 'Segoe UI',system-ui,sans-serif;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
        #webqa-overlay[data-expanded="true"] {width:360px;}
        #webqa-overlay[data-expanded="true"] .pilot-status {white-space:normal;}
        #webqa-overlay .pilot-panel {border-top:1px solid #34566a;padding:12px 14px;
          max-height:min(50vh,420px);overflow:auto;overscroll-behavior:contain;}
        #webqa-overlay .pilot-panel[hidden] {display:none!important;}
        #webqa-overlay .pilot-site {font-size:11px;font-weight:600;color:#a7f3d0;margin:0 0 12px;}
        #webqa-overlay .pilot-item+.pilot-item {border-top:1px solid #34566a;padding-top:14px;margin-top:14px;}
        #webqa-overlay .pilot-type {margin:0 0 4px;color:#c4d4df;font-size:11px;}
        #webqa-overlay .pilot-question {margin:0 0 9px;font-size:13px;color:#fff;}
        #webqa-overlay .pilot-answer {margin:0 0 6px;font-size:14px;font-weight:600;color:#a7f3d0;overflow-wrap:anywhere;}
        #webqa-overlay .pilot-confidence {margin:0;font-size:11px;color:#c4d4df;}
        #webqa-overlay .pilot-explanation {margin:9px 0 0;color:#e4edf3;font-size:12px;overflow-wrap:anywhere;}
        #webqa-overlay .pilot-empty {margin:0;color:#c4d4df;font-size:12px;}
      </style>
      <button type="button" class="pilot-toggle" aria-expanded="false" aria-controls="webqa-overlay-panel">
        <span class="pilot-brand">Study Pilot C</span><span class="pilot-toggle-label">Detalles</span>
      </button>
      <p class="pilot-status" role="status" aria-live="polite" aria-atomic="true"></p>
      <div id="webqa-overlay-panel" class="pilot-panel" hidden></div>`;
    document.documentElement.appendChild(root);
    const toggle = root.querySelector('button');
    const setExpanded = (expanded) => {
      root.dataset.expanded = String(expanded);
      toggle.setAttribute('aria-expanded', String(expanded));
      root.querySelector('.pilot-toggle-label').textContent = expanded ? 'Ocultar' : 'Detalles';
      root.querySelector('.pilot-panel').hidden = !expanded;
    };
    toggle.addEventListener('click', (event) => {
      event.stopPropagation();
      setExpanded(root.dataset.expanded !== 'true');
    });
    root.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && root.dataset.expanded === 'true') {
        event.preventDefault(); event.stopPropagation(); setExpanded(false); toggle.focus();
      }
    });
    // Keep the page's focused answer visible when keyboard navigation resumes.
    document.addEventListener('focusin', (event) => {
      if (root.hasAttribute('data-pilot-interacting')) return;
      if (!root.isConnected || root.contains(event.target) || root.dataset.expanded !== 'true') return;
      const a = root.getBoundingClientRect();
      const b = event.target.getBoundingClientRect?.();
      if (b && a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top)
        setExpanded(false);
    });
  }
  const status = String(payload.status || 'Esperando la próxima pregunta.');
  const statusNode = root.querySelector('.pilot-status');
  if (statusNode.textContent !== status) statusNode.textContent = status;
  statusNode.title = status;
  const panel = root.querySelector('.pilot-panel');
  const items = Array.isArray(payload.items) ? payload.items.slice(-3) : [];
  const key = JSON.stringify([payload.site, items]);
  if (root.dataset.contentKey === key) return;
  root.dataset.contentKey = key;
  const fragment = document.createDocumentFragment();
  const add = (parent, className, text) => {
    const element = document.createElement('p');
    element.className = className; element.textContent = String(text ?? ''); parent.appendChild(element);
  };
  add(fragment, 'pilot-site', payload.site || 'Sesión de estudio');
  if (!items.length) add(fragment, 'pilot-empty', 'Aquí aparecerán la respuesta y su explicación.');
  const types = {'single_choice':'Selección única','multiple_choice':'Selección múltiple',
    'fill_blank':'Completar','matching':'Emparejar','ordering':'Ordenar',
    'single choice':'Selección única','multiple choice':'Selección múltiple','fill blank':'Completar'};
  for (const item of items) {
    const card = document.createElement('section'); card.className = 'pilot-item';
    add(card, 'pilot-type', types[item.type] || item.type || 'Pregunta');
    add(card, 'pilot-question', String(item.question || '').slice(0, 280));
    add(card, 'pilot-answer', item.answer || 'Revisando la respuesta…');
    const confidence = Number(item.confidence);
    add(card, 'pilot-confidence', Number.isFinite(confidence)
      ? `Confianza: ${Math.round(Math.max(0, Math.min(1, confidence))*100)}%` : 'Confianza pendiente');
    if (item.explanation) add(card, 'pilot-explanation', String(item.explanation).slice(0, 600));
    fragment.appendChild(card);
  }
  panel.replaceChildren(fragment);
}
"""


async def update_overlay(page, site: str, status: str, items: list[dict]):
    try:
        await page.evaluate(OVERLAY_JS, {"site": site, "status": status, "items": items[-3:]})
    except Exception:
        pass


@asynccontextmanager
async def page_controls_available(page):
    """Let verified clicks pass through our panel without hiding or moving it."""
    try:
        await asyncio.wait_for(page.evaluate("""() => {
            const root=document.getElementById('webqa-overlay');
            if(!root)return;
            root.setAttribute('data-pilot-interacting','true');
            let style=document.getElementById('webqa-interaction-style');
            if(!style){style=document.createElement('style');style.id='webqa-interaction-style';document.documentElement.appendChild(style);}
            style.textContent='#webqa-overlay[data-pilot-interacting],#webqa-overlay[data-pilot-interacting] * {pointer-events:none!important;}';
        }"""),timeout=1.5)
        yield
    finally:
        try:
            await asyncio.wait_for(page.evaluate("""() => {
                document.getElementById('webqa-overlay')?.removeAttribute('data-pilot-interacting');
                document.getElementById('webqa-interaction-style')?.remove();
            }"""),timeout=1.5)
        except Exception:
            pass
