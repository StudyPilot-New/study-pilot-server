import unittest
from dataclasses import replace
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock,patch
from playwright.async_api import async_playwright

import app
from llm import Solver
from mcgraw_adapter import extract_mcgraw_question
from models import Answer,Choice,Question


HTML='''<main><h1>Multiple Choice Question</h1><p>Choose the pair specified by the study passage.</p>
<label style="display:block;margin:40px"><input type="radio" name="answer" value="a">Na+; K+</label>
<label style="display:block;margin:40px"><input type="radio" name="answer" value="b">Ca2+; Mg2+</label>
<button id="send" disabled>Medium</button></main><script>
window.sends=0;window.selected='';
document.querySelector('main').onchange=()=>document.querySelector('#send').disabled=false;
document.querySelector('#send').onclick=()=>{window.sends++;window.selected=document.querySelector('input:checked').value;
document.querySelector('main').innerHTML='<h1>Your Answer correct</h1><button id="next">Next Question</button>';
document.querySelector('#next').onclick=()=>document.querySelector('main').innerHTML='<h1>Next question loaded</h1>';};
</script>'''


def response(answers):
    import json
    return NS(status='completed',output_text=json.dumps({'answers':answers,'confidence':.99}))


class ApplicationRecovery(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page(viewport={'width':1200,'height':900})
        await self.page.route('https://learning.mheducation.com/**',lambda route:route.fulfill(content_type='text/html',body=HTML))
        await self.page.goto('https://learning.mheducation.com/recovery')
        self.settings=patch.object(app,'settings',replace(app.settings,pacing_minutes=0,use_vision='never',mode='fill',mcgraw_auto=True,mcgraw_confidence='Medium',min_confidence=.5))
        self.settings.start()

    async def asyncTearDown(self):
        self.settings.stop()
        await self.browser.close();await self.pw.stop()

    async def test_single_option_split_into_two_answers_gets_fresh_review_then_advances(self):
        solver=Solver('test-key','test-model')
        request=AsyncMock(side_effect=[response(['Na+','K+']),response(['Na+; K+'])])
        solver.client=NS(responses=NS(create=request));seen={}
        await app.analyze_page(self.page,solver,seen)
        self.assertFalse(seen)
        self.assertEqual(request.await_count,1)
        self.assertEqual(await self.page.evaluate('window.sends'),0)
        self.assertEqual(await self.page.locator('input:checked').count(),0)
        await app.analyze_page(self.page,solver,seen)
        self.assertEqual(request.await_count,1)
        for state in app._solve_retries[self.page].values():state['at']-=1000
        await app.analyze_page(self.page,solver,seen)
        self.assertEqual(request.await_count,2)
        self.assertEqual(await self.page.evaluate('[window.sends,window.selected]'),[1,'a'])
        self.assertIn('Independent recovery review',request.call_args.kwargs['input'][0]['content'][0]['text'])
        await app.analyze_page(self.page,solver,seen)
        self.assertIn('Next question loaded',await self.page.locator('body').inner_text())

    async def test_valid_recovered_answer_is_reused_after_mechanical_fill_failure(self):
        solver=Solver('test-key','test-model')
        q=(await extract_mcgraw_question(self.page.main_frame))[0]
        solver.memory.learn(q,['Na+; K+'],False)
        request=AsyncMock(side_effect=[response(['Na+; K+']),response(['Na+; K+']),response(['Ca2+; Mg2+'])])
        solver.client=NS(responses=NS(create=request));seen={}
        await app.analyze_page(self.page,solver,seen)
        self.assertEqual(request.await_count,2)
        for state in app._solve_retries[self.page].values():state['at']-=1000
        original_fill=app.fill_mcgraw_answer
        calls=0
        async def flaky_fill(*args):
            nonlocal calls
            calls+=1
            if calls==1:return {'filled':False,'details':'Selection did not take effect'}
            return await original_fill(*args)
        with patch.object(app,'fill_mcgraw_answer',side_effect=flaky_fill):
            await app.analyze_page(self.page,solver,seen)
            self.assertEqual(request.await_count,3)
            self.assertEqual(await self.page.evaluate('window.sends'),0)
            for state in app._solve_retries[self.page].values():state['at']-=1000
            await app.analyze_page(self.page,solver,seen)
        self.assertEqual(request.await_count,3)
        self.assertEqual(calls,2)
        self.assertEqual(await self.page.evaluate('[window.sends,window.selected]'),[1,'b'])
        self.assertTrue(solver.memory.is_rejected(q,['Na+; K+']))

    async def test_mechanical_recovery_keeps_analysis_and_does_not_recapture_or_scroll(self):
        solver=Solver('test-key','test-model');seen={}
        answer=Answer('mcgraw-current','single_choice',['Na+; K+'],.99)
        with patch.object(app,'settings',replace(app.settings,use_vision='always')), \
             patch.object(app,'capture_visual',AsyncMock(return_value=[b'figure'])) as capture, \
             patch.object(app,'solve_with_visual_evidence',AsyncMock(return_value=(answer,''))) as solve, \
             patch.object(app,'fill_mcgraw_answer',AsyncMock(side_effect=[
                 {'filled':False,'details':'Drop not registered','recover':True,'retry_after':2},
                 {'filled':True,'details':'verified'}])) as fill, \
             patch('recovery.recover_page',AsyncMock(return_value=True)):
            await app.analyze_page(self.page,solver,seen)
            self.assertFalse(seen)
            await app.analyze_page(self.page,solver,seen)
            self.assertEqual(fill.await_count,1)
            for state in app._solve_retries[self.page].values():state['at']-=1000
            await app.analyze_page(self.page,solver,seen)
            self.assertEqual(fill.await_count,2)
            self.assertEqual(solve.await_count,1)
            self.assertEqual(capture.await_count,1)

    def test_matching_fingerprint_survives_pool_and_placed_tile_reordering(self):
        a=Choice('old-a','Synthesis','matching');b=Choice('old-b','Hydrolysis','matching')
        first=Question('match','Match the reactions.','matching',[a,b],html_hint='mcgraw-dedicated')
        moved=replace(first,choices=[replace(b,cid='new-1'),replace(a,cid='new-2')])
        self.assertEqual(app.signature(first),app.signature(moved))
        self.assertNotEqual(app.signature(first),app.signature(replace(moved,text='A different question.')))


class GenericRecovery(unittest.IsolatedAsyncioTestCase):
    async def test_generic_retry_does_not_reference_mcgraw_resource_restore(self):
        class Page:
            url='https://example.com/practice'
        page=Page();frame=Page();q=Question('q','Choose the correct option.','single_choice',[Choice('a','First','radio'),Choice('b','Second','radio')])
        solver=NS(solve=AsyncMock(side_effect=[RuntimeError('temporary service error'),Answer('q','single_choice',['First'],.99)]))
        seen={}
        with patch.object(app,'settings',replace(app.settings,mode='assist',use_vision='never',highlight_recommendations=False)),patch.object(app,'identify_site',AsyncMock(return_value=('Practice',False))),patch.object(app,'collect_questions_from_frames',AsyncMock(return_value=[(0,frame,q)])),patch.object(app,'has_text_alternative',AsyncMock(return_value=False)),patch.object(app,'update_overlay',AsyncMock()),patch('question_resources.restore_question_resource',AsyncMock()) as restore,patch('question_resources.read_question_resource',AsyncMock()) as reading:
            await app.analyze_page(page,solver,seen)
            self.assertFalse(seen)
            for state in app._solve_retries[page].values():state['at']-=1000
            await app.analyze_page(page,solver,seen)
            self.assertTrue(seen)
            self.assertEqual(solver.solve.await_count,2)
            reading.assert_not_awaited();restore.assert_not_awaited()
            self.assertFalse(app._solve_retries.get(page))


if __name__=='__main__':unittest.main()
