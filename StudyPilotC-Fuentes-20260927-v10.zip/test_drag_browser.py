"""Chrome regressions for retained focus, live labels and committed ordering."""
import unittest
from types import SimpleNamespace as NS
from playwright.async_api import async_playwright
from mcgraw_actions import keyboard_match, exact_choice
from mcgraw_adapter import extract_mcgraw_question
from ordering import apply_ordering,current_order
from models import Choice,Question


class DragBrowser(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        from unittest.mock import patch,AsyncMock
        self.diagnostic_patch=patch('drag_diagnostics.save_drag_diagnostic',new=AsyncMock())
        self.diagnostic_patch.start()
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page(viewport={'width':1400,'height':1000})

    async def asyncTearDown(self):
        self.diagnostic_patch.stop()
        await self.browser.close()
        await self.pw.stop()

    async def test_matching_retained_focus_commits_instead_of_cancelling(self):
        await self.page.set_content('''<div data-webqa-match-target="Primary" style="position:absolute;left:450px;top:100px;width:400px;height:80px;border:1px solid"></div>
        <div data-webqa-match-target="Secondary" style="position:absolute;left:450px;top:200px;width:400px;height:80px;border:1px solid"></div>
        <div id="source" tabindex="0" data-webqa-cid="answer" style="position:absolute;left:450px;top:400px;width:400px;height:80px">The linear sequence of amino acids</div>
        <script>
          let held=false,index=2;window.keys=[];
          const source=document.querySelector('#source'),targets=[...document.querySelectorAll('[data-webqa-match-target]')];
          source.addEventListener('keydown',e=>{
            window.keys.push(e.code);e.preventDefault();
            if(e.code==='Space') {
              if(!held){held=true;source.setAttribute('aria-grabbed','true');}
              else {held=false;source.setAttribute('aria-grabbed','false');
                if(index<2){source.style.position='static';source.style.transform='';targets[index].append(source);}}
            }
            if(held && e.code==='ArrowUp') {index=Math.max(0,index-1);
              source.style.transform='translateY('+(targets[index].getBoundingClientRect().top-400)+'px)';}
            if(e.code==='Escape'){held=false;source.style.transform='';}
          });
        </script>''')
        result=await keyboard_match(self.page,self.page.locator('#source'),
            self.page.locator('[data-webqa-match-target="Primary"]'),
            NS(cid='answer',text='The linear sequence of amino acids'))
        self.assertTrue(result)
        self.assertEqual(await self.page.evaluate('window.keys'),['Space','ArrowUp','ArrowUp','Space'])
        self.assertEqual(await self.page.locator('[data-webqa-match-target="Primary"] #source').count(),1)

    async def test_extractor_uses_content_not_position_label(self):
        await self.page.set_content('''<h1>Matching Question</h1><p>Match each protein structure with its definition.</p>
          <div style="height:80px"></div>
          <div style="display:flex;gap:80px;height:100px"><span style="width:300px">Primary</span>
            <div class="dropzone" aria-label="Primary drop zone" style="width:500px;height:75px">
              <div draggable="true" tabindex="0" aria-label="position 2 of 3 list choices. Choice" style="height:70px">The linear sequence of amino acids</div>
            </div></div>
          <div style="display:flex;gap:80px;height:100px"><span style="width:300px">Secondary</span>
            <div class="dropzone" aria-label="Secondary drop zone" style="width:500px;height:75px"></div></div>
          <div style="margin-top:40px"><div draggable="true" tabindex="0" style="width:600px;height:80px" aria-label="position 1 of 1 list choices. Choice">Repetitive folding patterns such as a helix and a pleated sheet</div></div>
          <p>Need help? Review these concept resources.</p>''')
        questions=await extract_mcgraw_question(self.page.main_frame)
        self.assertEqual(len(questions),1)
        texts=[x.text for x in questions[0].choices]
        self.assertIn('The linear sequence of amino acids',texts)
        self.assertFalse(any('position ' in x for x in texts))

    async def test_ordering_nested_keyboard_handle(self):
        await self.page.set_content('''<div id="list">
          <div data-webqa-order-item="1" data-webqa-cid="a" style="height:80px"><button>Third</button></div>
          <div data-webqa-order-item="1" data-webqa-cid="b" style="height:80px"><button>First</button></div>
          <div data-webqa-order-item="1" data-webqa-cid="c" style="height:80px"><button>Second</button></div></div>
          <script>let held=null;document.addEventListener('keydown',e=>{
            const item=e.target.closest('[data-webqa-order-item]');if(!item)return;
            e.preventDefault();if(e.code==='Space')held=held?null:item;
            if(held && e.code==='ArrowUp' && held.previousElementSibling){
              held.parentElement.insertBefore(held,held.previousElementSibling);held.querySelector('button').focus();}
          });</script>''')
        q=Question('q','Rank first to third','ordering',[
            Choice('a','Third','ordering'),Choice('b','First','ordering'),Choice('c','Second','ordering')])
        await apply_ordering(self.page,self.page.main_frame,q,['First','Second','Third'],exact_choice)
        self.assertEqual(await current_order(self.page.main_frame),['b','c','a'])

    async def test_all_five_formulas_below_fixed_footer_are_read(self):
        await self.page.set_viewport_size({'width':1400,'height':700})
        await self.page.set_content('''<h1>Matching Question</h1>
          <p>Match each functional group with the correct chemical formula.</p>
          <div style="height:200px">
          <div class="dropzone" aria-label="Amino group drop zone" style="width:400px;height:80px"></div>
          <div class="dropzone" aria-label="Phosphate group drop zone" style="width:400px;height:80px"></div></div>
          <div style="margin-top:80px">
          <div draggable="true" style="width:400px;height:100px">−SO<sub>4</sub><sup>−</sup></div>
          <div draggable="true" style="width:400px;height:100px">−SH</div>
          <div draggable="true" style="width:400px;height:100px">−COOH</div>
          <div draggable="true" style="width:400px;height:100px">−PO<sub>4</sub><sup>2−</sup></div>
          <div draggable="true" style="width:400px;height:100px">−NH<sub>2</sub></div></div>
          <footer style="position:fixed;bottom:0;height:70px"><span>Rate your confidence to submit your answer.</span></footer>''')
        q=(await extract_mcgraw_question(self.page.main_frame))[0]
        self.assertEqual(len(q.choices),5)
        self.assertTrue(any('NH' in c.text for c in q.choices))
        before=[c.text for c in q.choices]
        await self.page.evaluate('window.scrollTo(0,document.body.scrollHeight)')
        after=(await extract_mcgraw_question(self.page.main_frame))[0]
        self.assertEqual([c.text for c in after.choices],before)

    async def test_math_renderers_do_not_duplicate_target(self):
        math='<math><semantics><mrow><mo>−</mo><mi>CH</mi><mn>3</mn></mrow><annotation encoding="application/x-tex">-CH3</annotation></semantics></math>'
        renderers=[
            '<mjx-container><span>− CH 3</span>'+math+'</mjx-container>',
            '<span class="katex"><span class="katex-html">− CH 3</span>'+math+'</span>',
            '<span class="MathJax">− CH 3</span>'+math,
            math,
        ]
        from mcgraw_actions import formula_key,matching_target
        for renderer in renderers:
            with self.subTest(renderer=renderer[:30]):
                await self.page.set_content('''<h1>Matching Question</h1><p>Match each chemical formula with the correct functional group.</p>
                  <div style="display:flex;gap:80px;height:100px"><div style="width:300px">'''+renderer+'''</div>
                  <div class="dropzone" aria-label="− CH 3 - CH 3 drop zone empty" style="width:500px;height:75px"></div></div>
                  <div style="display:flex;gap:80px;height:100px"><span style="width:300px">−OH</span>
                  <div class="dropzone" aria-label="−OH drop zone empty" style="width:500px;height:75px"></div></div>
                  <div draggable="true" style="margin-top:40px;width:500px;height:80px">Methyl group</div>
                  <div draggable="true" style="width:500px;height:80px">Hydroxyl group</div>''')
                q=(await extract_mcgraw_question(self.page.main_frame))[0]
                names=await self.page.locator('[data-webqa-match-target]').evaluate_all("els=>els.map(x=>x.getAttribute('data-webqa-match-target'))")
                self.assertEqual(formula_key(matching_target('−CH₃',names)),'-ch3')
                self.assertNotIn('CH 3 - CH 3',q.text)

    def test_target_variants_and_ambiguity(self):
        from mcgraw_actions import matching_target
        self.assertEqual(matching_target('-CH3',['− CH ₃','−COOH']),'− CH ₃')
        self.assertEqual(matching_target('−PO4²⁻',['−PO4^2−','−PO4−']),'−PO4^2−')
        for request,names in [('−PO4−',['−PO4²−']),('-CH3',['−CH₃','- CH3']),('−CH3',['−CH2−CH3'])]:
            with self.subTest(request=request,names=names),self.assertRaises(ValueError):
                matching_target(request,names)

    async def test_nested_tile_keeps_one_stable_control_id(self):
        await self.page.set_content('''<h1>Matching Question</h1>
          <div class="dropzone" aria-label="Amino group drop zone" style="width:400px;height:90px"></div>
          <div class="dropzone" aria-label="Phosphate group drop zone" style="width:400px;height:90px"></div>
          <div class="draggable-bank" style="margin-top:50px">
          <div draggable="true" style="width:500px;height:90px"><div class="drag-item-inner" style="height:80px">
          <mjx-container><span>− NH 2</span><math><mo>−</mo><mi>NH</mi><mn>2</mn></math></mjx-container><script type="math/mml"><math><mo>−</mo><mi>NH</mi><mn>2</mn></math></script></div></div>
          <div draggable="true" style="width:500px;height:90px">−PO₄²⁻</div></div>''')
        q=(await extract_mcgraw_question(self.page.main_frame))[0]
        from mcgraw_actions import matching_choice
        self.assertEqual(len(q.choices),2)
        choice=matching_choice('−NH₂',q.choices)
        control=self.page.locator(f'[data-webqa-cid="{choice.cid}"]')
        self.assertEqual(await control.count(),1)
        self.assertEqual(await control.get_attribute('draggable'),'true')

    def test_invisible_formula_characters_and_duplicate_diagnostic(self):
        from mcgraw_actions import matching_choice
        choice=Choice('a','−\u200bNH₂\u2060','drag-option')
        self.assertEqual(matching_choice('−NH2',[choice]).cid,'a')
        with self.assertRaisesRegex(ValueError,'2 matching tiles detected'):
            matching_choice('−NH₂',[choice,Choice('b','−NH2','drag-option')])
        with self.assertRaisesRegex(ValueError,'Read options:'):
            matching_choice('−NH2',[Choice('b','−SH','drag-option')])

    async def test_attribute_selectors_preserve_unicode_and_css_punctuation(self):
        from mcgraw_actions import by_attribute
        import json
        values=['−CO','−COOH','− CH 3','−OH','−PO₄²⁻','α helix',
                'a"b\\c\nnext','emoji 🧬','mcgraw-match-option-1']
        await self.page.set_content('<main></main>')
        await self.page.evaluate('''values=>{for(const value of values){
          const el=document.createElement('div');el.setAttribute('data-webqa-match-target',value);
          el.textContent=value;document.querySelector('main').append(el);
        }}''',values)
        # Reproduce the actual diagnostic: JSON escaping loses the minus sign.
        broken='[data-webqa-match-target='+json.dumps('−CO')+']'
        self.assertEqual(await self.page.locator(broken).count(),0)
        for value in values:
            with self.subTest(value=value):
                control=by_attribute(self.page.main_frame,'data-webqa-match-target',value)
                self.assertEqual(await control.count(),1)
                self.assertEqual(await control.get_attribute('data-webqa-match-target'),value)

    async def test_empty_accessibility_labels_are_not_completed_answers(self):
        from mcgraw_actions import matching_complete
        await self.page.set_content('''<h1>Matching Question</h1>
        <div class="dropzone" aria-label="Cellulose drop zone empty" data-webqa-match-option-text="Old answer" style="width:500px;height:80px">Cellulose drop zone empty.</div>
        <div class="dropzone" aria-label="Glycogen drop zone empty" style="width:500px;height:80px">Glycogen drop zone empty.</div>
        <div role="button" aria-grabbed="false" style="margin-top:50px;width:500px;height:80px">Unbranched</div>
        <div role="button" aria-grabbed="false" style="width:500px;height:80px">Highly branched</div>''')
        await extract_mcgraw_question(self.page.main_frame)
        self.assertFalse(await matching_complete(self.page.main_frame))
        self.assertEqual(await self.page.locator('.dropzone[data-webqa-match-option-text]').count(),0)
        await self.page.locator('.dropzone').nth(0).evaluate("el=>{el.textContent='Unbranched';el.setAttribute('aria-label','Cellulose drop zone has choice Unbranched');}")
        await extract_mcgraw_question(self.page.main_frame)
        self.assertFalse(await matching_complete(self.page.main_frame))

    async def test_four_drops_rerender_then_submit_and_next(self):
        from mcgraw_actions import fill_mcgraw_answer,submit_confidence,handle_feedback
        await self.page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body='''
        <meta charset="utf-8"><main id="app"></main><script>
        const names=['−CO','−COOH','− CH 3','−OH'];
        const answers=['Carbonyl group','Carboxyl group','Methyl group','Hydroxyl group','Aldehyde group'];
        const placed={};let held=null,index=4;window.commits=0;
        function render(){document.querySelector('#app').innerHTML='<h1>Matching Question</h1><p>Match each chemical formula with the correct functional group.</p>'+
          names.map((name,i)=>'<div style="display:flex;height:85px;gap:10px"><div style="width:300px">'+name+'</div><div class="drop-zone-brace" style="width:5px;height:70px"></div><div class="answer-box" style="width:500px;height:70px;border:1px solid">'+(placed[i]?'<div role="button" aria-grabbed="false" aria-label="'+(i===2?'-CH3':name)+' drop zone has choice '+placed[i]+'" style="width:400px;height:70px">'+placed[i]+'</div>':'')+'</div></div>').join('')+
          '<div style="margin-top:35px">'+answers.filter(x=>!Object.values(placed).includes(x)).map(x=>'<div role="button" aria-grabbed="false" tabindex="0" data-answer="'+x+'" style="width:500px;height:65px">'+x+'</div>').join('')+'</div>'+
          '<button id="submit" '+(Object.keys(placed).length===4?'':'disabled')+'>Medium</button>';
          document.querySelector('#submit').onclick=()=>{document.querySelector('#app').innerHTML='<h1>Your Answer correct</h1><button id="next">Next Question</button>';document.querySelector('#next').onclick=()=>document.querySelector('#app').innerHTML='<h1>Next question loaded</h1>';};
        }
        document.addEventListener('keydown',e=>{const source=e.target.closest('[data-answer]');if(!source)return;e.preventDefault();
          if(e.code==='Space') {if(!held){held=source;index=4;source.setAttribute('aria-grabbed','true');}
            else {if(index<4){placed[index]=held.dataset.answer;window.commits++;}held=null;render();}return;}
          if(held && e.code==='ArrowUp'){index=Math.max(0,index-1);
            const box=document.querySelectorAll('.answer-box')[index],b=box.getBoundingClientRect();
            held.style.transform='';const a=held.getBoundingClientRect();held.style.transform='translate('+(b.left-a.left)+'px,'+(b.top-a.top)+'px)';}
        });render();</script>'''))
        await self.page.goto('https://learning.mheducation.com/test')
        q=(await extract_mcgraw_question(self.page.main_frame))[0]
        widths=await self.page.locator('[data-webqa-match-target]').evaluate_all('els=>els.map(x=>x.getBoundingClientRect().width)')
        self.assertTrue(all(w>100 for w in widths),widths)
        mappings=['−CO => Carbonyl group','−COOH => Carboxyl group','−CH3 => Methyl group','−OH => Hydroxyl group']
        result=await fill_mcgraw_answer(self.page,self.page.main_frame,q,mappings)
        self.assertTrue(result['filled'],result)
        self.assertEqual(await self.page.evaluate('window.commits'),4)
        self.assertEqual(await self.page.locator('.answer-box').all_inner_texts(),['Carbonyl group','Carboxyl group','Methyl group','Hydroxyl group'])
        # Resume with two rows already filled and a newly rendered answer bank.
        await self.page.evaluate('delete placed[2];delete placed[3];render()')
        q=(await extract_mcgraw_question(self.page.main_frame))[0]
        result=await fill_mcgraw_answer(self.page,self.page.main_frame,q,mappings)
        self.assertTrue(result['filled'],result)
        self.assertEqual(await self.page.evaluate('window.commits'),6)
        # Retrying a complete question must not pick up already committed cards.
        q=(await extract_mcgraw_question(self.page.main_frame))[0]
        result=await fill_mcgraw_answer(self.page,self.page.main_frame,q,mappings)
        self.assertTrue(result['filled'],result)
        self.assertEqual(await self.page.evaluate('window.commits'),6)
        # A manual last placement must advance even with a cached question.
        import app
        from dataclasses import replace
        from unittest.mock import patch,AsyncMock
        from mcgraw_actions import matching_complete
        await self.page.evaluate('delete placed[3];render()')
        await extract_mcgraw_question(self.page.main_frame)
        self.assertFalse(await matching_complete(self.page.main_frame))
        await self.page.evaluate("placed[3]='Hydroxyl group';render()")
        found=await app.collect_questions_from_frames(self.page,is_study_platform=True)
        seen={f'{i}:{q.qid}':app.signature(q) for i,_,q in found}
        solver=NS(solve=AsyncMock())
        with patch.object(app,'settings',replace(app.settings,pacing_minutes=0,mode='fill',mcgraw_auto=True,mcgraw_confidence='Medium')):
            await app.analyze_page(self.page,solver,seen)
            await app.analyze_page(self.page,solver,seen)
        solver.solve.assert_not_awaited()
        self.assertIn('Next question loaded',await self.page.locator('body').inner_text())

if __name__=='__main__':unittest.main()
