"""Local startup checks: no API calls, no credentials in the report."""
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit


def activation(root):
    shared=(root/'distribution.json').is_file() or bool(os.getenv('STUDY_PILOT_SERVER_URL'))
    if not shared:
        return 'INFO: paquete de acceso directo. Este diagnóstico no comprueba la API key.', True
    data={}
    try:
        for name in ('distribution.json','access.json'):
            path=root/name
            if path.is_file():
                value=json.loads(path.read_text(encoding='utf-8'))
                if not isinstance(value,dict):raise ValueError()
                data.update(value)
        url=os.getenv('STUDY_PILOT_SERVER_URL') or data.get('server_url','')
        token=os.getenv('STUDY_PILOT_ACCESS_TOKEN') or data.get('access_token','')
        parsed=urlsplit(url)
        if parsed.scheme!='https' or not parsed.hostname or not re.fullmatch(r'spc_[A-Za-z0-9_-]{40,100}',str(token)):
            raise ValueError()
    except (ValueError,TypeError,OSError):
        return ('BLOQUEO: paquete Amigos sin acceso activado. Antes de abrir Chrome necesita el servidor '
                'desplegado, su URL HTTPS y un código spc_. Una API key no activa este paquete. '
                'Ejecuta Configurar acceso.bat cuando el administrador entregue esos datos.'),False
    return ('INFO: acceso compartido configurado localmente. No se verificó conexión ni vigencia del código.'),True


def diagnose(root):
    lines=['STUDY PILOT C - DIAGNÓSTICO DE INICIO',
           'No contiene claves, códigos de acceso, cookies ni enunciados. No consume API.']
    lines.append('Python: '+sys.version.split()[0])
    if sys.version_info<(3,11):lines.append('BLOQUEO: instala Python 3.11 o superior.')
    if not (root/'app.py').is_file():
        lines.append('BLOQUEO: coloca estos archivos en la carpeta que contiene app.py, no dentro del ZIP.')
        return lines
    for module in ('tkinter','openai','playwright','dotenv','rapidfuzz'):
        found=importlib.util.find_spec(module) is not None
        lines.append(('OK: ' if found else 'BLOQUEO: falta instalar ')+module)
    message,_=activation(root);lines.append(message)
    if importlib.util.find_spec('playwright') is None:
        lines.append('ACCIÓN: ejecuta Instalar Study Pilot C.bat y repite este diagnóstico.')
        return lines
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            browser=pw.chromium.launch(channel='chrome',headless=True,timeout=15000)
            try:lines.append('OK: Chrome abre en una prueba independiente sin ventana y sin perfil personal.')
            finally:browser.close()
    except Exception as exc:
        # Only classify internally. Raw exceptions can contain local private paths.
        message=str(exc).lower()
        if 'not found' in message or "doesn't exist" in message or 'executable' in message:
            lines.append('BLOQUEO: Chrome no está disponible para Playwright. Instala Google Chrome y repite.')
        else:
            lines.append('BLOQUEO: la prueba independiente de Chrome falló ('+type(exc).__name__+'). Revisa la instalación y permisos del equipo.')
    lines.append('Si Chrome pasa la prueba pero la app no abre: revisa los BLOQUEOS anteriores y el registro de la app. '
                 'Cierra otras sesiones de Study Pilot C que puedan estar usando su mismo perfil.')
    return lines


def main():
    root=Path(__file__).resolve().parent
    report='\n\n'.join(diagnose(root))+'\n'
    print(report)
    try:
        (root/'DIAGNOSTICO_INICIO.txt').write_text(report,encoding='utf-8')
        print('Resultado guardado en DIAGNOSTICO_INICIO.txt. Puedes compartir ese archivo.')
    except OSError:
        print('No se pudo guardar el archivo. Copia el texto de esta ventana.')


if __name__=='__main__':main()
