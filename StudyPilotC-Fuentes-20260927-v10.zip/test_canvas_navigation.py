import unittest
from playwright.async_api import async_playwright
from canvas_navigation import CanvasNavigation
from learning_adapter import extract_learning_questions
from dom import fill_answer
from matcher import best_choice
from pacing import SessionPacer

def signature(q):return q.text+'|'+q.kind+'|'+','.join(c.text for c in q.choices)

class CanvasNavigationTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.pw=await async_playwright().start();self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
  self.page=await self.browser.new_page();self.now=[0];self.nav=CanvasNavigation(clock=lambda:self.now[0])
 async def asyncTearDown(self):await self.browser.close();await self.pw.stop()
 async def setup_question(self,buttons='<button id="next" onclick="window.clicks=(window.clicks||0)+1">Next</button>',checkbox=False):
  kind='checkbox' if checkbox else 'radio'
  await self.page.set_content(f'<div class="question"><div class="question_text">Pick the examples.</div><fieldset><legend>Group of answer choices</legend><label><input type="{kind}" name="x">Alpha</label><label><input type="{kind}" name="x">Beta</label></fieldset></div>'+buttons)
  q=(await extract_learning_questions(self.page))[0];found=[(0,self.page.main_frame,q)]
  self.nav.observe(self.page,((0,q.qid,signature(q)),))
  return q,found
 async def remember(self,q,answers):
  await fill_answer(self.page,q,answers,best_choice);self.nav.remember(self.page,0,q,signature(q),answers)
  # Initial fill has a short repair deferral. Advance this deliberately frozen
  # clock before simulating a later loss of selection.
  self.now[0]+=1
 async def test_next_once_and_transition_resets_pacing(self):
  q,found=await self.setup_question();await self.remember(q,['Alpha'])
  pacer=SessionPacer(1,2,clock=lambda:self.now[0])
  self.assertIn('Próxima',await self.nav.advance(self.page,found,signature,pacer))
  self.assertIsNone(await self.page.evaluate('window.clicks'))
  pacer.reconfigure(0,2)
  self.assertIn('Next pulsado',await self.nav.advance(self.page,found,signature,pacer))
  for _ in range(3):await self.nav.advance(self.page,found,signature,pacer)
  self.assertEqual(await self.page.evaluate('window.clicks'),1)
  self.nav.observe(self.page,(),pacer);self.assertEqual(pacer.completed,0)
  await self.page.locator('.question_text').evaluate("e=>e.textContent='The second question.'")
  next_q=(await extract_learning_questions(self.page))[0]
  new=((0,next_q.qid,signature(next_q)),)
  self.nav.observe(self.page,new,pacer);self.nav.observe(self.page,new,pacer)
  self.assertEqual(pacer.completed,1)
  self.assertEqual(await self.nav.advance(self.page,[(0,self.page.main_frame,next_q)],signature,pacer),'')
 async def test_missing_disabled_duplicate_and_final_controls_never_clicked(self):
  for buttons in ('<button onclick="window.clicks=1">Submit Quiz</button>', '<button disabled>Next</button>', '<button>Next</button><button>Next</button>'):
   self.nav.reset(self.page);q,found=await self.setup_question(buttons);await self.remember(q,['Alpha'])
   self.assertIn('esperando un botón',await self.nav.advance(self.page,found,signature))
   self.assertIsNone(await self.page.evaluate('window.clicks'))
 async def test_incomplete_multiselect_is_restored_before_next(self):
  q,found=await self.setup_question(checkbox=True);await self.remember(q,['Alpha','Beta'])
  await self.page.get_by_label('Beta',exact=True).uncheck()
  self.assertIn('restablecida',await self.nav.advance(self.page,found,signature))
  self.assertIsNone(await self.page.evaluate('window.clicks'))
  self.assertTrue(await self.page.get_by_label('Beta',exact=True).is_checked())
  await self.nav.advance(self.page,found,signature)
  self.assertEqual(await self.page.evaluate('window.clicks'),1)
 async def test_stale_question_is_rescanned_without_applying_old_answer(self):
  q,found=await self.setup_question();await self.remember(q,['Alpha'])
  await self.page.locator('.question_text').evaluate("e=>e.textContent='A changed question.'")
  await self.page.locator('input').evaluate_all('els=>els.forEach(e=>e.checked=false)')
  self.assertIn('volviendo a detectar',await self.nav.advance(self.page,found,signature))
  self.assertEqual(await self.page.locator('input:checked').count(),0)
  self.assertIsNone(await self.page.evaluate('window.clicks'))
 async def test_hidden_checked_template_does_not_block_verified_selection(self):
  q,found=await self.setup_question();await self.remember(q,['Alpha'])
  await self.page.locator('.question').evaluate("e=>e.insertAdjacentHTML('beforeend','<div style=\"display:none\"><input type=checkbox checked></div>')")
  self.assertIn('Next pulsado',await self.nav.advance(self.page,found,signature))
  self.assertEqual(await self.page.evaluate('window.clicks'),1)
 async def test_extra_checkbox_is_removed_and_remounted_controls_are_rebound(self):
  q,found=await self.setup_question(checkbox=True);await self.remember(q,['Alpha'])
  await self.page.get_by_label('Beta',exact=True).check()
  await self.page.locator('fieldset').evaluate('e=>e.outerHTML=e.outerHTML')
  self.assertIn('restablecida',await self.nav.advance(self.page,found,signature))
  self.assertTrue(await self.page.get_by_label('Alpha',exact=True).is_checked())
  self.assertFalse(await self.page.get_by_label('Beta',exact=True).is_checked())
  await self.nav.advance(self.page,found,signature)
  self.assertEqual(await self.page.evaluate('window.clicks'),1)
 async def test_persistent_selection_failure_backs_off_and_recovers_without_manual_reset(self):
  q,found=await self.setup_question();await self.remember(q,['Alpha'])
  await self.page.locator('input').evaluate_all("els=>els.forEach(e=>{e.checked=false;e.onclick=()=>{window.repairs=(window.repairs||0)+1;return false;}})")
  self.assertIn('recuperando',await self.nav.advance(self.page,found,signature))
  await self.nav.advance(self.page,found,signature)
  self.assertEqual(await self.page.evaluate('window.repairs'),1)
  self.assertIsNone(await self.page.evaluate('window.clicks'))
  await self.page.locator('input').evaluate_all('els=>els.forEach(e=>e.onclick=null)')
  self.now[0]=2
  self.assertIn('restablecida',await self.nav.advance(self.page,found,signature))
  await self.nav.advance(self.page,found,signature)
  self.assertEqual(await self.page.evaluate('window.clicks'),1)
 async def test_bounded_retry_and_paused_session(self):
  q,found=await self.setup_question();await self.remember(q,['Alpha'])
  pacer=SessionPacer(0,2,clock=lambda:self.now[0]);pacer.pause()
  await self.nav.advance(self.page,found,signature,pacer);self.assertIsNone(await self.page.evaluate('window.clicks'))
  pacer.resume();await self.nav.advance(self.page,found,signature,pacer)
  self.now[0]=9;await self.nav.advance(self.page,found,signature,pacer)
  self.now[0]=18;self.assertIn('esperando la siguiente pregunta',await self.nav.advance(self.page,found,signature,pacer))
  self.assertEqual(await self.page.evaluate('window.clicks'),2)
  self.now[0]=25;self.assertIn('Next pulsado',await self.nav.advance(self.page,found,signature,pacer))
  self.assertEqual(await self.page.evaluate('window.clicks'),3)
  self.now[0]=49;await self.nav.advance(self.page,found,signature,pacer)
  self.assertEqual(await self.page.evaluate('window.clicks'),4)
  self.assertIsNotNone(self.nav.take_recovery_request(self.page))
 async def test_engine_advances_after_fill_and_does_not_resolve_during_transition(self):
  from unittest.mock import AsyncMock,patch
  from types import SimpleNamespace
  from dataclasses import replace
  from models import Answer
  import app
  q,_=await self.setup_question()
  answer=Answer(q.qid,q.kind,['Alpha'],1)
  solve=AsyncMock(return_value=(answer,''))
  config=replace(app.settings,mode='fill',pacing_minutes=0,use_vision='never',min_confidence=.6)
  with patch.object(app,'settings',config),patch.object(app,'identify_site',AsyncMock(return_value=('Canvas',False))),patch.object(app,'solve_with_visual_evidence',solve):
   seen={};solver=SimpleNamespace(memory=None)
   await app.analyze_page(self.page,solver,seen)
   self.assertEqual(await self.page.evaluate('window.clicks'),1)
   await app.analyze_page(self.page,solver,seen)
   self.assertEqual(solve.await_count,1)
   self.assertEqual(await self.page.evaluate('window.clicks'),1)
   await self.page.locator('.question_text').evaluate("e=>e.textContent='Another question.'")
   await self.page.locator('input').evaluate_all('els=>els.forEach(e=>e.checked=false)')
   await app.analyze_page(self.page,solver,seen)
   self.assertEqual(solve.await_count,2)
   self.assertEqual(await self.page.evaluate('window.clicks'),2)

if __name__=='__main__':unittest.main()
