import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock
from playwright.async_api import async_playwright
from models import Answer
from llm import Solver
from mcgraw_adapter import extract_mcgraw_question
from mcgraw_actions import fill_mcgraw_answer

class LearningBrowser(unittest.IsolatedAsyncioTestCase):
    async def test_formula_correction_ignores_hidden_mathml_source(self):
        from models import Question,Choice
        from session_memory import SessionMemory
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page()
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body='<h1>Question</h1>'))
                await page.goto('https://learning.mheducation.com/test')
                q=Question('formula','What is the chemical formula of glucose?','single_choice',[Choice('a','C6H6','radio'),Choice('b','C6H12O6','radio')])
                memory=SessionMemory();memory.stage(page,q,Answer(q.qid,q.kind,['C6H6'],1))
                math='<math><mi>C</mi><mn>6</mn><mi>H</mi><mn>12</mn><mi>O</mi><mn>6</mn><annotation encoding="text/plain">not answer source</annotation></math>'
                await page.set_content('<h1>Your Answer incorrect</h1><h2>Correct Answer</h2><div><span class="MathJax"><span>C 6 H 12 O 6</span>'+math+'</span><script type="math/mml">'+math+'</script></div>')
                self.assertTrue(await memory.observe(page))
                self.assertEqual(memory.recalled(q).answers,['C6H12O6'])
                self.assertTrue(memory.is_rejected(q,['C6H6']))
            finally:await browser.close()

    async def test_two_boxes_then_observed_correction_overrides_cache(self):
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page(viewport={'width':1400,'height':900})
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body='''
                <h1>Fill in the Blank Question</h1><p style="margin-top:40px">Mutations within genes can alter the
                <span style="display:contents"><input type="text"><input type="text"></span>
                sequence of a polypeptide and thereby affect protein function.</p>'''))
                await page.goto('https://learning.mheducation.com/test')
                q=(await extract_mcgraw_question(page.main_frame))[0]
                self.assertEqual(len(q.choices),2)
                self.assertIn('[Blank 1] [Blank 2]',q.text)
                solver=Solver('test-key','test-model')
                request=AsyncMock(return_value=NS(status='completed',output_text='{"answers":["amino acid"],"confidence":0.99}'))
                solver.client=NS(responses=NS(create=request))
                answer=await solver.solve(q)
                self.assertEqual(answer.answers,['amino','acid'])
                result=await fill_mcgraw_answer(page,page.main_frame,q,answer.answers)
                self.assertTrue(result['filled'],result)
                self.assertEqual(await page.locator('input').evaluate_all('els=>els.map(x=>x.value)'),['amino','acid'])
                # The feedback must be consumed before navigation removes it.
                solver.memory.stage(page,q,Answer(q.qid,q.kind,['wrong','term'],0.99))
                await page.set_content('<h1>Your Answer incorrect</h1><h2>Correct Answer</h2><div>amino acid</div><button>Next Question</button>')
                self.assertTrue(await solver.memory.observe(page))
                self.assertFalse(await solver.memory.observe(page))
                self.assertEqual((await solver.solve(q)).answers,['amino','acid'])
                self.assertEqual(request.await_count,1)
            finally:await browser.close()

    async def test_delayed_nested_feedback_is_recalled_with_shuffled_options(self):
        from models import Question,Choice,Answer
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page()
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body='<h1>Question</h1>'))
                await page.goto('https://learning.mheducation.com/test')
                q=Question('old','What is the formula?','single_choice',[Choice('a','C6H6','radio'),Choice('b','C6H12O6','radio')])
                solver=Solver('test-key','test-model')
                solver.client=NS(responses=NS(create=AsyncMock(side_effect=AssertionError('Correction should bypass API'))))
                solver.memory.stage(page,q,Answer(q.qid,q.kind,['C6H6'],1))
                await page.set_content('<h1>Your Answer <span>incorrect</span></h1><section><div><h2><span>Correct Answer</span></h2></div><div id="correction"></div></section>')
                await page.evaluate("setTimeout(()=>document.querySelector('#correction').textContent='C 6 H 12 O 6',400)")
                self.assertTrue(await solver.memory.observe(page))
                repeated=Question('new','  What is the formula? ','single_choice',[Choice('x','C₆H₁₂O₆','radio'),Choice('y','C₆H₆','radio')])
                self.assertEqual((await solver.solve(repeated)).answers,['C6H12O6'])
                self.assertTrue(solver.memory.is_rejected(repeated,['C 6 H 6']))
                self.assertFalse(await solver.memory.observe(page))
            finally:await browser.close()

    async def test_multiple_selection_feedback_replays_complete_combination(self):
        from models import Answer
        first='Condensation reactions and dehydration synthesis occur when two or more molecules combine to form a larger molecule.'
        second='Dehydration synthesis is a specific type of condensation reaction involving the loss of a water molecule.'
        options=['Condensation reactions typically must occur before dehydration synthesis occurs.',first,'Condensation reactions are the reverse of dehydration synthesis.',second]
        def html(values):
            return '<h1>Multiple Select Question</h1><p>Select all that apply</p><p>Which describes condensation reactions and dehydration synthesis?</p>'+''.join('<label style="display:block;margin:30px"><input type="checkbox">'+x+'</label>' for x in values)
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page(viewport={'width':1400,'height':900})
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body=html(options)))
                await page.goto('https://learning.mheducation.com/test')
                q=(await extract_mcgraw_question(page.main_frame))[0]
                self.assertEqual(q.kind,'multiple_choice')
                solver=Solver('test-key','test-model')
                solver.client=NS(responses=NS(create=AsyncMock(side_effect=AssertionError('Use session correction'))))
                solver.memory.stage(page,q,Answer(q.qid,q.kind,[second],1))
                await page.set_content('<h1>Your Answer incorrect</h1><h2>Correct Answers</h2><div><div>'+first+'</div><div>'+second+'</div></div>')
                self.assertTrue(await solver.memory.observe(page))
                await page.set_content(html(list(reversed(options))))
                repeated=(await extract_mcgraw_question(page.main_frame))[0]
                answer=await solver.solve(repeated)
                self.assertEqual(set(answer.answers),{first,second})
                result=await fill_mcgraw_answer(page,page.main_frame,repeated,answer.answers)
                self.assertTrue(result['filled'],result)
                self.assertEqual(await page.locator('input:checked').count(),2)
                self.assertTrue(solver.memory.is_rejected(repeated,[second]))
                self.assertFalse(solver.memory.is_rejected(repeated,[second,first]))
            finally:await browser.close()

if __name__=='__main__':unittest.main()
