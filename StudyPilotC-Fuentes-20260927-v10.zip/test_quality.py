import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock,patch
from quality import quality_environment
from llm import Solver
from models import Question,Choice

class QualityTests(unittest.IsolatedAsyncioTestCase):
    async def test_high_effort_survives_review_and_budget_reaches_sdk(self):
        env=quality_environment('Mayor precisión')
        solver=Solver('test-key','test-model',fast_mode=False,reasoning_effort=env['FAST_REASONING'],max_output_tokens=int(env['FAST_MAX_OUTPUT_TOKENS']))
        request=AsyncMock(return_value=NS(status='completed',output_text='{"answers":["Correct"],"confidence":0.9}'))
        solver.client=NS(responses=NS(create=request))
        q=Question('q','Which option?','single_choice',[Choice('a','Correct','radio')])
        await solver.solve(q,review=True)
        self.assertEqual(request.call_args.kwargs['reasoning']['effort'],'high')
        self.assertEqual(request.call_args.kwargs['max_output_tokens'],4096)
    def test_unknown_preset_rejected_and_environment_not_shared(self):
        with self.assertRaises(ValueError):quality_environment('unlimited')
        settings=quality_environment('Equilibrado');settings['FAST_REASONING']='changed'
        self.assertEqual(quality_environment('Equilibrado')['FAST_REASONING'],'medium')
