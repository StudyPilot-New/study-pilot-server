import unittest
from unittest.mock import patch
from playwright.async_api import async_playwright
import question_resources as resources
from mcgraw_actions import _pending, _feedback_navigation

QUESTION = '''<h1>Multiple Choice Question</h1><p style="margin:40px 0">Which term describes the displayed structure?</p>
<label><input type="radio" name="q">First option</label><br>
<label><input type="radio" name="q">Second option</label>'''
READING_TEXT = ('Structural differences change how the atoms are connected. '
                'Compare the connections between atoms in both molecules before choosing the term. '
                'This paragraph is the concept resource visible to the student.')


class QuestionResources(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page(viewport={'width':1280,'height':900})
        self.timeout=patch.multiple(resources,READ_TIMEOUT=1.5,RETURN_TIMEOUT=.6,POLL_INTERVAL=.04)
        self.timeout.start()
    async def asyncTearDown(self):
        self.timeout.stop()
        await self.browser.close();await self.pw.stop()
    async def load(self,html,host='learning.mheducation.com'):
        await self.page.route('https://'+host+'/**',lambda r:r.fulfill(content_type='text/html',body=html))
        await self.page.goto('https://'+host+'/resource-test')
    async def reading_fixture(self,broken_back=False):
        import json
        html='''<meta charset="utf-8"><main id="content"></main><script>
        window.reads=0;window.returns=0;window.allowReturn=ALLOW;
        const question=QUESTION;
        function showQuestion(){document.querySelector('#content').innerHTML=question+'<button id="reading">Read About the Concept</button>';
          document.querySelector('#reading').onclick=()=>{window.reads++;showReading();};}
        function showReading(){document.querySelector('#content').innerHTML='<button id="back">To Questions</button><article id="book">Loading...</article><nav>PRIVATE NAVIGATION TEXT</nav><footer>PRIVATE FOOTER TEXT</footer><div id="webqa-overlay">PRIVATE OVERLAY TEXT</div><p hidden>PRIVATE HIDDEN TEXT</p>';
          document.querySelector('#back').onclick=()=>{window.returns++;if(window.allowReturn)showQuestion();};
          setTimeout(()=>document.querySelector('#book').textContent=READING,250);}
        showQuestion();</script>'''
        await self.load(html.replace('QUESTION',json.dumps(QUESTION)).replace('READING',json.dumps(READING_TEXT)).replace('ALLOW','false' if broken_back else 'true'))
    async def test_waits_for_reading_and_returns_to_same_question(self):
        await self.reading_fixture()
        sentinel={'phase':'untouched'}
        _pending[self.page]=sentinel.copy();_feedback_navigation[self.page]=sentinel.copy()
        text=await resources.read_question_resource(self.page)
        self.assertIn(READING_TEXT,text)
        self.assertNotIn('PRIVATE',text)
        self.assertNotIn('Loading',text)
        self.assertEqual(await self.page.evaluate('[reads,returns]'),[1,1])
        self.assertEqual(await self.page.get_by_role('button',name='Read About the Concept').count(),1)
        self.assertEqual(_pending[self.page],sentinel)
        self.assertEqual(_feedback_navigation[self.page],sentinel)
        self.assertNotIn(self.page,resources._pending_returns)
        self.assertNotIn(self.page,resources._completed_reads)
    async def test_wrong_host_and_no_resource_do_not_click(self):
        await self.load(QUESTION+'<button onclick="window.clicked=true">Reading</button>',host='example.com')
        self.assertEqual(await resources.read_question_resource(self.page),'')
        self.assertIsNone(await self.page.evaluate('window.clicked'))
        await self.load(QUESTION+'<button onclick="window.clicked=true">Next Question</button>')
        self.assertEqual(await resources.read_question_resource(self.page),'')
        self.assertIsNone(await self.page.evaluate('window.clicked'))
    async def test_new_tab_resource_returns_and_closes_only_its_popup(self):
        await self.page.context.route('https://learning.mheducation.com/book',lambda r:r.fulfill(content_type='text/html',body='<article>'+READING_TEXT+'</article>'))
        await self.load(QUESTION+'<a href="https://learning.mheducation.com/book" target="_blank" onclick="window.clicked=true">Reading</a>')
        self.assertEqual(await resources.read_question_resource(self.page),READING_TEXT)
        self.assertEqual(len(self.page.context.pages),1)
        self.assertTrue(await self.page.evaluate('window.clicked'))
    async def test_delayed_return_remains_pending_and_resumes_without_submitting(self):
        await self.reading_fixture(broken_back=True)
        self.assertEqual(await resources.read_question_resource(self.page),'')
        self.assertIn(self.page,resources._pending_returns)
        self.assertEqual(await self.page.get_by_role('button',name='To Questions',exact=True).count(),1)
        await self.page.evaluate('window.allowReturn=true')
        resources._pending_returns[self.page]['last_click']-=4
        self.assertTrue(await resources.restore_question_resource(self.page))
        self.assertNotIn(self.page,resources._pending_returns)
        self.assertEqual(await self.page.locator('input:checked').count(),0)
        self.assertEqual(await self.page.evaluate('window.returns'),2)
        self.assertEqual(await resources.read_question_resource(self.page),READING_TEXT)
        self.assertEqual(await self.page.evaluate('window.reads'),1)
        self.assertNotIn(self.page,resources._completed_reads)
    async def test_completed_reading_is_discarded_for_another_question(self):
        await self.reading_fixture(broken_back=True)
        self.assertEqual(await resources.read_question_resource(self.page),'')
        await self.page.evaluate('window.allowReturn=true')
        resources._pending_returns[self.page]['last_click']-=4
        self.assertTrue(await resources.restore_question_resource(self.page))
        self.assertIn(self.page,resources._completed_reads)
        await self.page.set_content(QUESTION.replace('displayed structure','new structure'))
        self.assertEqual(await resources.read_question_resource(self.page),'')
        self.assertNotIn(self.page,resources._completed_reads)
    async def test_delayed_context_can_be_consumed_without_reopening(self):
        await self.reading_fixture(broken_back=True)
        self.assertEqual(await resources.read_question_resource(self.page),'')
        await self.page.evaluate('window.allowReturn=true')
        resources._pending_returns[self.page]['last_click']-=4
        self.assertTrue(await resources.restore_question_resource(self.page))
        self.assertEqual(await resources.consume_question_resource(self.page),READING_TEXT)
        self.assertEqual(await resources.consume_question_resource(self.page),'')
        self.assertEqual(await self.page.evaluate('window.reads'),1)
    async def test_feedback_is_left_to_feedback_navigation(self):
        await self.load(QUESTION+'<h2>Your Answer incorrect</h2><button onclick="window.clicked=true">Reading</button>')
        self.assertEqual(await resources.read_question_resource(self.page),'')
        self.assertIsNone(await self.page.evaluate('window.clicked'))


if __name__=='__main__':unittest.main()
