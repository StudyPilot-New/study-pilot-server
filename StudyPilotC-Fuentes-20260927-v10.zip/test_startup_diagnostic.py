import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from diagnosticar_inicio import activation


class StartupDiagnosticTests(unittest.TestCase):
    def test_unactivated_friend_package_is_identified_without_reading_api_key(self):
        with tempfile.TemporaryDirectory() as temp,patch.dict(os.environ,{},clear=True):
            root=Path(temp)
            (root/'distribution.json').write_text('{"mode":"shared","server_url":""}')
            (root/'.env').write_text('OPENAI_API_KEY=PRIVATE_TEST_SECRET')
            message,valid=activation(root)
            self.assertFalse(valid);self.assertIn('sin acceso activado',message)
            self.assertNotIn('PRIVATE_TEST_SECRET',message)

    def test_configured_friend_and_direct_packages(self):
        with tempfile.TemporaryDirectory() as temp,patch.dict(os.environ,{},clear=True):
            root=Path(temp)
            self.assertIn('acceso directo',activation(root)[0])
            (root/'distribution.json').write_text('{}')
            (root/'access.json').write_text('{"server_url":"https://example.com","access_token":"spc_'+('x'*43)+'"}')
            message,valid=activation(root)
            self.assertTrue(valid);self.assertNotIn('spc_',message)


if __name__=='__main__':unittest.main()
