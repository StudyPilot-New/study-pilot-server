from text_alternative import read_text_alternative


async def solve_with_visual_evidence(page, frame, question, solver, image,
                                     image_failed, has_alternative, minimum, recovery_attempt=0, recovery_hint="", resource_context=""):
    alternative = ''
    if has_alternative:
        alternative = await read_text_alternative(page, frame)
        if not alternative and not image:
            print('Neither image nor description is available; waiting for evidence.')
            return None, ''
    if image_failed and not alternative:
        return None, ''
    if recovery_attempt:
        # A scheduled recovery must not recycle the same cached low-confidence review.
        answer = await solver.solve(question, image_png=image, text_alternative=alternative,
                                    review=True, recovery_attempt=recovery_attempt,
                                    recovery_hint=recovery_hint, resource_context=resource_context)
        return answer, alternative
    answer = await solver.solve(question, image_png=image, text_alternative=alternative)
    if answer.confidence < minimum and not alternative:
        alternative = await read_text_alternative(page, frame)
        if alternative:
            answer = await solver.solve(question, image_png=image, text_alternative=alternative)
    if (answer.confidence < minimum or not getattr(answer, "answers", [True])):
        answer = await solver.solve(question, image_png=image, text_alternative=alternative, review=True)
    return answer, alternative
