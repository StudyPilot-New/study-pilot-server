import unittest
from unittest.mock import AsyncMock,patch
from types import SimpleNamespace as NS
import tkinter as tk
import mcgraw_actions as a
from desktop_ui import StudyPilot

class Matching(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.keyboard_patch=patch.object(a,'keyboard_match',return_value=False)
        self.keyboard_patch.start()
    def tearDown(self):self.keyboard_patch.stop()
    def test_formula_formats_preserve_charge(self):
        self.assertEqual(a.formula_key('−NH₂'),a.formula_key('-NH2'))
        self.assertEqual(a.formula_key('−PO₄²⁻'),a.formula_key('-PO4^2-'))
        self.assertNotEqual(a.formula_key('-PO4^2-'),a.formula_key('-PO4^3-'))
    async def test_success_does_not_drag_twice(self):
        source,target,page=AsyncMock(),AsyncMock(),AsyncMock()
        with patch.object(a,'drop_verified',return_value=False),patch.object(a,'wait_for_drop',return_value=True):
            await a.drag_match(page,source,target,NS(text='NH2'))
        source.drag_to.assert_awaited_once();page.mouse.down.assert_not_awaited()
    async def test_pointer_fallback_releases_mouse(self):
        source,target,page=AsyncMock(),AsyncMock(),AsyncMock()
        source.drag_to.side_effect=TimeoutError()
        source.bounding_box.return_value={'x':0,'y':200,'width':80,'height':40}
        target.bounding_box.return_value={'x':100,'y':20,'width':80,'height':40}
        with patch.object(a,'drop_verified',return_value=False),patch.object(a,'wait_for_drop',side_effect=[False,True]),patch.object(a.asyncio,'sleep',new=AsyncMock()):
            await a.drag_match(page,source,target,NS(text='NH2'))
        page.mouse.down.assert_awaited_once()
        # Release both a timed-out native drag and the pointer fallback.
        self.assertEqual(page.mouse.up.await_count,2)
    async def test_existing_drop_is_not_repeated(self):
        source=AsyncMock()
        with patch.object(a,'drop_verified',return_value=True):
            await a.drag_match(AsyncMock(),source,AsyncMock(),NS(text='NH2'))
        source.drag_to.assert_not_awaited()

    async def test_html5_fallback_disposes_transfer(self):
        source,target,page=AsyncMock(),AsyncMock(),AsyncMock()
        source.bounding_box.return_value={'x':0,'y':200,'width':80,'height':40}
        target.bounding_box.return_value={'x':100,'y':20,'width':80,'height':40}
        transfer=AsyncMock();source.evaluate_handle.return_value=transfer
        with patch.object(a,'drop_verified',return_value=False),patch.object(a,'wait_for_drop',side_effect=[False,False,True]),patch.object(a.asyncio,'sleep',new=AsyncMock()):
            await a.drag_match(page,source,target,NS(text='NH2'))
        self.assertEqual([call.args[0] for call in target.dispatch_event.await_args_list],['dragenter','dragover','drop'])
        transfer.dispose.assert_awaited_once()

class KeyboardMatching(unittest.IsolatedAsyncioTestCase):
    async def test_space_arrows_space_at_verified_target(self):
        source,target,page=AsyncMock(),AsyncMock(),AsyncMock()
        source.evaluate.return_value=True
        target.evaluate.side_effect=[3,False,True]
        with patch.object(a,'wait_for_drop',return_value=True),patch.object(a.asyncio,'sleep',new=AsyncMock()):
            self.assertTrue(await a.keyboard_match(page,source,target,NS(text='Unbranched')))
        self.assertEqual([c.args[0] for c in page.keyboard.press.await_args_list],['Space','ArrowUp','ArrowUp','Space'])
    async def test_unknown_destination_cancels_without_drop(self):
        source,target,page=AsyncMock(),AsyncMock(),AsyncMock()
        source.evaluate.return_value=True;target.evaluate.side_effect=[3]+[False]*10
        with patch.object(a.asyncio,'sleep',new=AsyncMock()):
            self.assertFalse(await a.keyboard_match(page,source,target,NS(text='Unbranched')))
        keys=[c.args[0] for c in page.keyboard.press.await_args_list]
        self.assertEqual(keys.count('Space'),1);self.assertEqual(keys[-1],'Escape')

class Desktop(unittest.TestCase):
    def test_build_and_validate_without_starting_browser(self):
        try:
            root=tk.Tk()
        except tk.TclError as exc:
            self.skipTest('Tcl/Tk runtime unavailable: '+str(exc))
        root.withdraw()
        try:
            app=StudyPilot(root);root.update_idletasks()
            self.assertEqual(root.title(),'Study Pilot C')
            app.minimum.set('invalid');app.start()
            self.assertIsNone(app.process)
            self.assertIn('entre 0 y 1',app.detail.get())
            self.assertEqual(app.pause_button['state'],'disabled')
        finally:root.destroy()

if __name__=='__main__':unittest.main()
