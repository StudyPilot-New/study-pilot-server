import unittest
from playwright.async_api import async_playwright
from mcgraw_adapter import extract_mcgraw_question
from mcgraw_actions import fill_mcgraw_answer

class FormulaRadioBrowser(unittest.IsolatedAsyncioTestCase):
    async def test_formula_renderers_select_only_glucose(self):
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(channel='chrome', headless=True)
            try:
                page = await browser.new_page(viewport={'width':1400,'height':900})
                for renderer in ('mjx-container', 'katex', 'native', 'mathjax-source'):
                    with self.subTest(renderer=renderer):
                        rows=[]
                        for i, counts in enumerate(((6,6,0),(5,10,5),(3,6,2),(6,12,6))):
                            tokens=[(e,n) for e,n in zip('CHO',counts) if n]
                            visual=' '.join(f'{e} {n}' for e,n in tokens)
                            math='<math>'+''.join(f'<msub><mi>{e}</mi><mn>{n}</mn></msub>' for e,n in tokens)+'</math>'
                            if renderer=='mathjax-source': content=f'<span class="MathJax"><span>{visual}</span>{math}</span><script type="math/mml">{math}</script>'
                            elif renderer=='native': content=math
                            elif renderer=='katex': content=f'<span class="katex"><span>{visual}</span>{math}</span>'
                            else: content=f'<mjx-container><span>{visual}</span>{math}</mjx-container>'
                            rows.append(f'<label style="display:block;margin:28px 20px"><input type="radio" name="answer" value="{i}">{content}</label>')
                        html='<meta charset="utf-8"><h1>Multiple Choice Question</h1><p style="margin:40px 0">What is the chemical formula of glucose?</p>'+''.join(rows)
                        await page.route('https://learning.mheducation.com/**', lambda r:r.fulfill(content_type='text/html; charset=utf-8',body=html))
                        await page.goto('https://learning.mheducation.com/test')
                        questions=await extract_mcgraw_question(page.main_frame)
                        self.assertEqual(len(questions),1)
                        q=questions[0]
                        self.assertEqual(len(q.choices),4,[c.text for c in q.choices])
                        result=await fill_mcgraw_answer(page,page.main_frame,q,['C 6 H 12 O 6'])
                        self.assertTrue(result['filled'],(result,[c.text for c in q.choices]))
                        self.assertEqual(await page.locator('input:checked').evaluate_all('els=>els.map(e=>e.value)'),['3'])
                        await page.unroute('https://learning.mheducation.com/**')
            finally:
                await browser.close()

if __name__=='__main__': unittest.main()
