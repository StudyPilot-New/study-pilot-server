"""Explicit, bounded reasoning presets for the existing configured model."""
QUALITY_PRESETS={
    'Rápido': {'FAST_MODE':'true','FAST_REASONING':'none','FAST_MAX_OUTPUT_TOKENS':'512','VISUAL_REASONING':'medium'},
    'Equilibrado': {'FAST_MODE':'false','FAST_REASONING':'medium','FAST_MAX_OUTPUT_TOKENS':'2048','VISUAL_REASONING':'medium'},
    'Mayor precisión': {'FAST_MODE':'false','FAST_REASONING':'high','FAST_MAX_OUTPUT_TOKENS':'4096','VISUAL_REASONING':'high'},
}

def quality_environment(name):
    if name not in QUALITY_PRESETS:raise ValueError('Selecciona una opción válida de potencia de IA.')
    return QUALITY_PRESETS[name].copy()
