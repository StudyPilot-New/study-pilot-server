"""Presentation layer. Keep session behavior in desktop_ui."""
import tkinter as tk
from tkinter import ttk

NAVY = '#142c3c'
PAPER = '#f1f5f7'
INK = '#162b3c'
MUTED = '#536579'
TEAL = '#087f73'
MINT = '#a7f3d0'
BORDER = '#d8e2e8'


def build_dashboard(app):
    root = app.root
    width = min(1180, max(900, root.winfo_screenwidth()-80))
    height = min(840, max(620, root.winfo_screenheight()-100))
    root.geometry(f'{width}x{height}')
    root.minsize(900, 620)
    root.configure(bg=PAPER)
    style = ttk.Style(root)
    style.configure('Pilot.TNotebook', background=PAPER, borderwidth=0)
    style.configure('Pilot.TNotebook.Tab', padding=(20, 11), font=('Segoe UI', 10, 'bold'),
                    background='#e3ebef', foreground=MUTED)
    style.map('Pilot.TNotebook.Tab', background=[('selected', 'white')],
              foreground=[('selected', TEAL)])
    style.configure('TCombobox', padding=8, fieldbackground='#f7f9fc',
                    bordercolor='#8795a5', arrowcolor=INK, font=('Segoe UI', 10))
    style.map('TCombobox', fieldbackground=[('readonly', '#f7f9fc')],
              foreground=[('readonly', INK)])
    style.configure('TCheckbutton', background='white', foreground=INK, font=('Segoe UI', 10))

    side = tk.Frame(root, bg=NAVY, width=188)
    side.pack(side='left', fill='y')
    side.pack_propagate(False)
    mark = tk.Canvas(side, width=48, height=48, bg=NAVY, highlightthickness=0)
    mark.pack(anchor='w', padx=24, pady=(30, 14))
    mark.create_rectangle(1, 1, 47, 47, fill=MINT, outline='')
    mark.create_line(12, 32, 24, 12, 36, 32, 24, 25, 12, 32,
                     fill=NAVY, width=2, joinstyle='round')
    app.label(side, 'Study Pilot C', 16, 'white', True).pack(anchor='w', padx=24)
    app.label(side, 'TU SESIÓN, A TU RITMO', 8, '#b3c7d4', True).pack(anchor='w', padx=24, pady=(7, 32))
    footer = tk.Frame(side, bg=NAVY)
    footer.pack(side='bottom', fill='x', padx=24, pady=24)
    app.label(footer, 'Siempre en control', 10, MINT, True).pack(anchor='w')
    app.label(footer, 'Puedes pausar o detener\nla sesión cuando quieras.', 9,
              '#b3c7d4', justify='left').pack(anchor='w', pady=(7, 0))

    main = tk.Frame(root, bg=PAPER)
    main.pack(side='left', fill='both', expand=True, padx=24, pady=22)
    app.label(main, 'Tu espacio de estudio', 24, INK, True).pack(anchor='w')
    app.label(main, 'Un ritmo claro. Cada paso, a la vista.', 11, MUTED).pack(anchor='w', pady=(5, 18))
    hero = tk.Frame(main, bg=NAVY, padx=22, pady=17)
    hero.pack(fill='x')
    app.label(hero, 'SESIÓN ACTUAL', 9, MINT, True).pack(anchor='w')
    tk.Label(hero, textvariable=app.status, bg=NAVY, fg='white',
             font=('Segoe UI', 20, 'bold'), anchor='w').pack(fill='x', pady=(7, 6))
    detail = tk.Label(hero, textvariable=app.detail, bg=NAVY, fg='#c4d4df',
                      font=('Segoe UI', 10), justify='left', anchor='w')
    detail.pack(fill='x')
    hero.bind('<Configure>', lambda e: detail.configure(wraplength=max(300, e.width-44)))

    strip = tk.Frame(main, bg=PAPER)
    strip.pack(fill='x', pady=14)
    for i, (caption, variable, size) in enumerate([
        ('RESPUESTAS ENVIADAS', app.total, 20),
        ('TIEMPO TRANSCURRIDO', app.elapsed, 20),
        ('RITMO PREVISTO', app.pace_summary, 11),
    ]):
        strip.columnconfigure(i, weight=1, uniform='stats')
        card = tk.Frame(strip, bg='white', padx=14, pady=12,
                        highlightbackground=BORDER, highlightthickness=1)
        card.grid(row=0, column=i, sticky='nsew', padx=(0, 10 if i<2 else 0))
        app.label(card, caption, 8, MUTED, True).pack(anchor='w')
        tk.Label(card, textvariable=variable, bg='white', fg=INK,
                 font=('Segoe UI', size, 'bold'), anchor='w').pack(fill='x', pady=(5, 0))
    commands = tk.Frame(main, bg=PAPER)
    commands.pack(fill='x', pady=(0, 16))
    app.start_button = app.button(commands, 'Abrir actividad', app.start, True)
    app.start_button.pack(side='left')
    app.pause_button = app.button(commands, 'Pausar', app.pause)
    app.pause_button.pack(side='left', padx=10)
    app.stop_button = app.button(commands, 'Detener', app.stop)
    app.stop_button.pack(side='left')
    app.recover_button = app.button(commands, 'Recuperar', app.recover)
    app.recover_button.pack(side='left', padx=10)
    app.pause_button['state'] = app.stop_button['state'] = 'disabled'
    settings_tip = tk.Label(main, textvariable=app.detail, bg=PAPER, fg=MUTED,
                            font=('Segoe UI', 10), justify='left', anchor='w')
    main.bind('<Configure>', lambda e: settings_tip.configure(wraplength=max(300, e.width)))

    notebook = app.notebook = ttk.Notebook(main, style='Pilot.TNotebook')
    notebook.pack(fill='both', expand=True)
    activity = tk.Frame(notebook, bg='white', padx=18, pady=16)
    settings = app.settings_tab = tk.Frame(notebook, bg='white')
    notebook.add(activity, text='Actividad')
    notebook.add(settings, text='Ajustes de sesión')
    from onboarding import build_guide
    build_guide(app, notebook)
    from account_login import build_account
    from shared_access import shared_mode
    if shared_mode(): build_account(app, notebook)
    nav_buttons = []
    navigation=[('Mi sesión',0),('Ajustes avanzados',1),('Guía de inicio',2)]
    if shared_mode(): navigation.append(('Mi cuenta',3))
    for label, index in navigation:
        button = tk.Button(side, text=label, command=lambda n=index: notebook.select(n),
                           anchor='w', bg=NAVY, fg='#c4d4df', font=('Segoe UI', 11, 'bold'),
                           relief='flat', bd=0, padx=24, pady=14, cursor='hand2',
                           activebackground='#24485d', activeforeground='white',
                           highlightthickness=2, highlightcolor=MINT, highlightbackground=NAVY)
        button.pack(fill='x', pady=2)
        nav_buttons.append(button)
    def select_nav(_=None):
        is_settings = notebook.index('current') != 0
        if is_settings:
            hero.pack_forget(); strip.pack_forget()
            settings_tip.pack(fill='x', before=commands, pady=(0, 14))
        else:
            settings_tip.pack_forget()
            hero.pack(fill='x', before=commands)
            strip.pack(fill='x', before=commands, pady=14)
        for i, button in enumerate(nav_buttons):
            selected = notebook.index('current') == i
            button.configure(bg='#24485d' if selected else NAVY,
                             fg='white' if selected else '#c4d4df')
    notebook.bind('<<NotebookTabChanged>>', select_nav)
    select_nav()
    app.label(activity, 'Inicio rápido', 12, INK, True).pack(anchor='w')
    app.label(activity, 'Pega el enlace de Canvas o de tu plataforma. Después, pulsa Abrir actividad.',
              10, MUTED, wraplength=570, justify='left').pack(anchor='w',pady=(4,8))
    app.entry(activity,app.url).pack(fill='x',ipady=7,pady=(0,10))
    pace=tk.Frame(activity,bg='white');pace.pack(fill='x',pady=(0,10))
    app.label(pace,'Ritmo · cambios en vivo',10,INK,True).grid(row=0,column=0,columnspan=4,sticky='w')
    app.label(pace,'Calcular ritmo por',8,MUTED).grid(row=1,column=0,sticky='w',pady=(8,0))
    ttk.Combobox(pace,textvariable=app.pacing_mode,values=['Duración total','Por pregunta'],state='readonly',width=17).grid(row=2,column=0,padx=(0,8),pady=6)
    pace_entries=[]
    for column,(caption,var) in enumerate([('Segundos/pregunta',app.pacing_seconds),('Minutos totales',app.pacing_minutes),('Preguntas estimadas',app.pacing_questions)],1):
        app.label(pace,caption,8,MUTED).grid(row=1,column=column,sticky='w',pady=(8,0))
        entry=app.entry(pace,var,width=12)
        entry.grid(row=2,column=column,sticky='ew',padx=4,ipady=7)
        pace_entries.append(entry)
        pace.columnconfigure(column,weight=1)
    def show_pacing_mode(*_):
        per_question=app.pacing_mode.get()=='Por pregunta'
        pace_entries[0].configure(state='normal' if per_question else 'disabled')
        pace_entries[1].configure(state='disabled' if per_question else 'normal')
    app.pacing_mode.trace_add('write',show_pacing_mode)
    show_pacing_mode()
    app.label(activity,'Elige qué parámetro usar. El resumen cambia al escribir; el ritmo se aplica en vivo. El análisis puede tardar más.',9,MUTED,wraplength=600,justify='left').pack(anchor='w',pady=(0,8))
    app.label(activity, 'Inicia sesión con tu universidad en el nuevo Chrome y abre la actividad allí.',
              9, MUTED, wraplength=570, justify='left').pack(anchor='w',pady=(0,12))
    app.label(activity, 'Actividad reciente', 12, INK, True).pack(anchor='w')
    app.label(activity, 'Respuestas, recuperaciones y tiempos de espera de esta sesión.',
              9, MUTED).pack(anchor='w', pady=(5, 12))
    logframe = tk.Frame(activity, bg='#f6f8fa')
    logframe.pack(fill='both', expand=True)
    app.log = tk.Text(logframe, bg='#f6f8fa', fg='#334b60', font=('Consolas', 10),
                      relief='flat', padx=14, pady=12, wrap='word', state='disabled', height=5,
                      highlightthickness=1, highlightbackground=BORDER, highlightcolor=TEAL)
    app.log.pack(side='left', fill='both', expand=True)
    scroll = ttk.Scrollbar(logframe, command=app.log.yview)
    scroll.pack(side='right', fill='y')
    app.log['yscrollcommand'] = scroll.set

    canvas = tk.Canvas(settings, bg='white', highlightthickness=0)
    canvas.pack(side='left', fill='both', expand=True)
    scrollbar = ttk.Scrollbar(settings, command=canvas.yview)
    scrollbar.pack(side='right', fill='y')
    canvas.configure(yscrollcommand=scrollbar.set)
    form = tk.Frame(canvas, bg='white', padx=20, pady=18)
    window = canvas.create_window((0, 0), window=form, anchor='nw')
    form.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
    canvas.bind('<Configure>', lambda e: canvas.itemconfigure(window, width=e.width))
    def wheel(event):
        canvas.yview_scroll(-int(event.delta/120) if abs(event.delta)>=120 else (-1 if event.delta>0 else 1), 'units')
        return 'break'
    def reveal_focus(event):
        widget = event.widget
        if widget is form: return
        y = widget.winfo_rooty()-form.winfo_rooty()
        height = max(1, form.winfo_height())
        low, high = canvas.yview()
        if y < low*height:
            canvas.yview_moveto(max(0, (y-10)/height))
        elif y+widget.winfo_height() > high*height:
            canvas.yview_moveto(max(0, (y+widget.winfo_height()+10-canvas.winfo_height())/height))
    def heading(text, row, caption=None):
        app.label(form, text, 12, INK, True).grid(row=row, column=0, columnspan=4,
                                                sticky='w', pady=(0 if row==0 else 18, 5))
        if caption:
            app.label(form, caption, 9, MUTED, wraplength=590, justify='left').grid(
                row=row+1, column=0, columnspan=4, sticky='w', pady=(0, 10))
    def field(title, variable, row, column=0, span=1, **kwargs):
        app.label(form, title, 9, MUTED).grid(row=row, column=column, columnspan=span, sticky='w')
        entry = app.entry(form, variable, **kwargs)
        entry.grid(row=row+1, column=column, columnspan=span, sticky='ew',
                   ipady=8, pady=(5, 10), padx=(0, 10 if column+span<4 else 0))
        return entry
    heading('Ritmo de estudio', 0,
            'Espacia las respuestas durante el tiempo previsto. La duración final depende de las preguntas y los reintentos.')
    app.pacing_minutes_entry = field('Duración prevista · minutos', app.pacing_minutes, 2, 0, 2)
    app.pacing_questions_entry = field('Preguntas estimadas', app.pacing_questions, 2, 2, 2)
    app.label(form, '120 min y 180 preguntas: aproximadamente 40 s por pregunta. Usa 0 min para desactivar la espera.',
              9, MUTED, wraplength=590, justify='left').grid(row=4, column=0, columnspan=4, sticky='w')
    heading('Preferencias de la sesión', 5, 'Los cambios se aplican al iniciar la próxima sesión.')
    field('Página inicial · opcional', app.url, 7, 0, 4)
    for col, (name, variable, values) in enumerate([
        ('Modo', app.mode, ['fill', 'assist']),
        ('Confianza al enviar', app.confidence, ['High', 'Medium', 'Low']),
        ('Lectura de imágenes', app.vision, ['auto', 'always', 'never']),
    ]):
        app.label(form, name, 9, MUTED).grid(row=9, column=col, sticky='w')
        ttk.Combobox(form, textvariable=variable, values=values, state='readonly', width=12).grid(
            row=10, column=col, sticky='ew', padx=(0, 10), pady=(5, 10))
    field('Confianza mínima · 0–1', app.minimum, 9, 3, width=8)
    app.label(form, 'fill: aplicar respuestas · assist: mostrar sugerencias', 9, MUTED).grid(
        row=11, column=0, columnspan=4, sticky='w', pady=(0, 10))
    ttk.Checkbutton(form, text='Consultar mi libro de referencia', variable=app.book).grid(
        row=12, column=0, columnspan=4, sticky='w')
    from shared_access import shared_mode
    if shared_mode():
        heading('Conexión compartida', 13, 'Entra con tu correo y contraseña en Mi cuenta. No necesitas una API key.')
    else:
        heading('Conexión', 13, 'La clave es opcional si ya está configurada. No se guarda en los ajustes de la app.')
        field('Clave de API', app.api, 15, 0, 4, show='•')
    heading('Potencia de la IA', 17, 'Mayor precisión dedica más razonamiento y puede tardar y consumir más API. No garantiza todas las respuestas.')
    from quality import QUALITY_PRESETS
    ttk.Combobox(form,textvariable=app.quality,values=list(QUALITY_PRESETS),state='readonly').grid(
        row=19,column=0,columnspan=4,sticky='ew',pady=(4,10))
    app.label(form,'Se aplica al iniciar la próxima sesión y conserva el modelo configurado.',9,MUTED).grid(
        row=20,column=0,columnspan=4,sticky='w')
    for col in range(4): form.columnconfigure(col, weight=1, uniform='fields')
    def bind_form(widget):
        widget.bind('<MouseWheel>', wheel, add='+')
        widget.bind('<FocusIn>', reveal_focus, add='+')
        for child in widget.winfo_children(): bind_form(child)
    bind_form(form)
    canvas.bind('<MouseWheel>', wheel)
