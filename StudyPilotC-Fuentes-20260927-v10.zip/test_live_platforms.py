import unittest
import asyncio
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from playwright.async_api import async_playwright
from pacing import SessionPacer
from live_pacing import values,write_update
from live_pacing import watch_updates
from learning_adapter import extract_learning_questions
from dom import fill_answer
from matcher import best_choice
from site_policy import platform_from_url


class LivePacingTests(unittest.TestCase):
    def test_adjust_current_wait_without_resetting_count(self):
        now=[0];pacer=SessionPacer(120,180,clock=lambda:now[0]);pacer.completed=4
        now[0]=10;pacer.reconfigure(60,180)
        self.assertEqual(pacer.remaining(),10);self.assertEqual(pacer.completed,4)
        pacer.reconfigure(0,180);self.assertEqual(pacer.remaining(),0)

    def test_adjust_while_paused(self):
        now=[0];pacer=SessionPacer(120,180,clock=lambda:now[0])
        now[0]=10;pacer.pause();now[0]=100;pacer.reconfigure(180,180)
        self.assertEqual(pacer.remaining(),50);pacer.resume();self.assertEqual(pacer.remaining(),50)

    def test_mode_conversion_validation_and_atomic_file(self):
        self.assertEqual(values('Por pregunta',20,120,180),{'minutes':60,'questions':180})
        for seconds in ('nan','inf',-1,3601):
            with self.assertRaises(ValueError):values('Por pregunta',seconds,120,180)
        with TemporaryDirectory() as directory:
            write_update(Path(directory)/'control.txt',values('Por pregunta',20,120,180))
            self.assertIn('60.0',(Path(directory)/'pacing.json').read_text())

    def test_host_identity_has_domain_boundaries(self):
        self.assertEqual(platform_from_url('https://school.instructure.com/courses/1'),'Canvas')
        self.assertIsNone(platform_from_url('https://instructure.com.attacker.example/'))
        self.assertIsNone(platform_from_url('https://example.com/?blackboard.com'))


class LiveWatcherTests(unittest.IsolatedAsyncioTestCase):
    async def test_engine_receives_changes_and_ignores_incomplete_values(self):
        with TemporaryDirectory() as directory:
            control=Path(directory)/'control.txt'
            received=[]
            event=asyncio.Event()
            def apply(data):
                received.append(data);event.set()
            task=asyncio.create_task(watch_updates(control,apply))
            try:
                write_update(control,{'minutes':120,'questions':180})
                await asyncio.wait_for(event.wait(),2)
                event.clear()
                write_update(control,{'minutes':60,'questions':180})
                await asyncio.wait_for(event.wait(),2)
                event.clear()
                control.with_name('pacing.json').write_text('{')
                await asyncio.sleep(.3)
                self.assertFalse(event.is_set())
                self.assertEqual(received,[{'minutes':120,'questions':180},{'minutes':60,'questions':180}])
            finally:
                task.cancel()
                with self.assertRaises(asyncio.CancelledError):await task


class SemanticFixtureTests(unittest.IsolatedAsyncioTestCase):
    async def test_platform_wrappers_multiselect_and_two_fields(self):
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page()
                for wrapper in ('class="question"','class="que"','data-question-id="pearson"','data-testid="question"'):
                    await page.set_content(f'<div {wrapper}><h3>Select the two vowels</h3><label><input type="checkbox">A</label><label><input type="checkbox">B</label><label><input type="checkbox">E</label></div>')
                    questions=await extract_learning_questions(page)
                    self.assertEqual(len(questions),1);self.assertEqual(questions[0].kind,'multiple_choice')
                    result=await fill_answer(page,questions[0],['A','E'],best_choice)
                    self.assertTrue(result['filled']);self.assertEqual(await page.locator('input:checked').count(),2)
                await page.set_content('<div class="que"><h3>Complete amino acid</h3><input type="text"><input type="text"></div>')
                question=(await extract_learning_questions(page))[0]
                self.assertFalse((await fill_answer(page,question,['amino acid'],best_choice))['filled'])
                self.assertTrue((await fill_answer(page,question,['amino','acid'],best_choice))['filled'])
                self.assertEqual(await page.locator('input').nth(1).input_value(),'acid')
                await page.set_content('<fieldset><legend>Log into university</legend><input type="email"><input type="password"></fieldset>')
                self.assertEqual(await extract_learning_questions(page),[])
            finally:await browser.close()


if __name__=='__main__':unittest.main()
