"""One desktop executable; the engine runs as a separate hidden process."""
import sys


def self_test():
    import asyncio
    import json
    from pathlib import Path
    import tkinter as tk
    import httpx
    import openai
    import app
    from runtime_paths import DATA_DIR
    from playwright.async_api import async_playwright
    result={'imports':True,'tk':False,'chrome':False,'data_writable':False}
    root=tk.Tk();root.withdraw();root.update();root.destroy();result['tk']=True
    async def browser_check():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True,args=['--disable-gpu'])
            page=await browser.new_page()
            await page.set_content('<button>Ready</button>')
            result['chrome']=await page.get_by_role('button',name='Ready').count()==1
            await browser.close()
    asyncio.run(browser_check())
    report=DATA_DIR/'diagnostico-ejecutable.json'
    result['data_writable']=True
    report.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)
    return 0 if all(result.values()) else 1


if __name__=='__main__':
    if sys.stdout is not None:sys.stdout.reconfigure(line_buffering=True,encoding='utf-8',errors='replace')
    if '--engine' in sys.argv:
        sys.argv.remove('--engine')
        from app import main
        main()
    elif '--self-test' in sys.argv:
        raise SystemExit(self_test())
    else:
        from desktop_ui import main
        main()
