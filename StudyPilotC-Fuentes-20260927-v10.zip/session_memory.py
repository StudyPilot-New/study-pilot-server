"""Session-only, question-specific corrections observed from platform feedback."""
import asyncio
import unicodedata
import hashlib
import json
import re
from weakref import WeakKeyDictionary
from models import Answer


def split_blanks(question, answers):
    answers=[str(x).strip() for x in answers]
    count=len(question.choices)
    if question.kind=='fill_blank' and len(answers)==1 and count>1:
        # Delimiters represent fields only when every field is accounted for.
        # Never split on commas, signs, or arbitrary words in separate blanks.
        text=answers[0]
        labels=list(re.finditer(r'\b(?:field|blank)\s*(\d+)\s*[:.)-]\s*',text,re.I))
        if labels:
            numbered={}
            prefix=text[:labels[0].start()].strip(' ;\r\n')
            for index,label in enumerate(labels):
                end=labels[index+1].start() if index+1<len(labels) else len(text)
                value=text[label.end():end].strip(' ;\r\n')
                number=int(label.group(1))
                if number in numbered or not value:break
                numbered[number]=value
            else:
                if not prefix and set(numbered)==set(range(1,count+1)):
                    return [numbered[index] for index in range(1,count+1)]
            return answers
        separated=re.split(r'\s*;\s*|[\r\n]+',text)
        if len(separated)==count and all(part.strip() for part in separated):
            return [part.strip() for part in separated]
    if question.kind=='fill_blank' and answers and len(set(answers))==1 and count>1:
        adjacent=r'\[Blank\s+1\]' + ''.join(r'\s*\[Blank\s+'+str(i)+r'\]' for i in range(2,count+1))
        words=answers[0].split()
        if re.search(adjacent,question.text,re.I) and len(words)==count:
            return words
    return answers


def fill_correction(question, shown):
    """Read a complete field mapping, refusing ambiguous accepted-term lists."""
    values=[str(value).strip() for value in shown]
    if not values or not all(values):return []
    if len(question.choices)==1:
        # A list of alternatives is not one literal answer. Wait for an explicit
        # single correction rather than concatenating alternative terms.
        if len(values)!=1 or re.search(r';|[\r\n]',values[0]):return []
        return values
    # Preserve Field N labels long enough to validate and order the whole map.
    if any(re.search(r'\b(?:field|blank)\s*\d+\s*[:.)-]',value,re.I) for value in values):
        values=split_blanks(question,['; '.join(values)])
        if any(re.search(r'\b(?:field|blank)\s*\d+\s*[:.)-]',value,re.I) for value in values):return []
    else:
        values=split_blanks(question,values)
    return values if len(values)==len(question.choices) and all(values) else []


def canonical(text):
    text=unicodedata.normalize('NFKC',str(text)).casefold()
    text=''.join(c for c in text if unicodedata.category(c)!='Cf')
    text=re.sub(r'[−–—]','-',text)
    return ' '.join(text.split())


def option_key(text):
    value=canonical(text).rstrip('.!?')
    # Charge-only formulas such as Na+ also have equivalent spaced renderings.
    formula=bool(re.search(r'\d',value) or re.fullmatch(r'[a-z\s]+[+-]',value))
    return re.sub(r'[\s^_{}]','',value) if formula else value


class SessionMemory:
    def __init__(self):
        self.correct={}
        self.wrong={}
        self.pending=WeakKeyDictionary()

    def key(self,q):
        options=[] if q.kind=='fill_blank' else sorted(option_key(c.text) for c in q.choices)
        visual=q.html_hint.rsplit('|figure:',1)[-1] if q.has_visual else ''
        payload=[q.kind,canonical(q.text),len(q.choices),options,visual]
        return hashlib.sha256(json.dumps(payload,ensure_ascii=False).encode()).hexdigest()

    def stage(self,page,q,answer):
        self.pending[page]=(q,list(answer.answers))

    def learn(self,q,submitted,correct,shown=None):
        key=self.key(q)
        if not correct:
            self.wrong.setdefault(key,[])
            if submitted not in self.wrong[key]:self.wrong[key].append(list(submitted))
            self.correct.pop(key,None)
        candidate=fill_correction(q,shown) if shown and q.kind=='fill_blank' else split_blanks(q,shown or (submitted if correct else []))
        if shown and q.kind=='multiple_choice':
            # A correction panel may return the entire list as one text block.
            # Consume full option texts only, never substring-match a partial list.
            remaining=canonical(' '.join(shown))
            selected=[]
            while remaining:
                remaining=remaining.lstrip(' ;,•\n')
                matches=[c.text for c in q.choices if remaining.startswith(canonical(c.text))
                         and (len(remaining)==len(canonical(c.text)) or
                              remaining[len(canonical(c.text))] in ' ;,•')]
                if len(matches)!=1:break
                selected.append(matches[0])
                remaining=remaining[len(canonical(matches[0])):]
            candidate=selected if not remaining and len(set(selected))==len(selected) else []
        valid=bool(candidate)
        if q.kind=='fill_blank':valid=valid and len(candidate)==len(q.choices)
        elif q.kind in {'single_choice','multiple_choice','select'}:
            if q.kind in {'single_choice','select'} and len(candidate)!=1:
                valid=False
            mapped=[]
            for value in candidate:
                matches=[c.text for c in q.choices if option_key(c.text)==option_key(value)]
                if len(matches)!=1:
                    valid=False
                    break
                mapped.append(matches[0])
            if len(set(map(option_key,mapped)))!=len(mapped):valid=False
            if valid:candidate=mapped
        else:valid=valid and correct and not shown  # Only accepted submissions; do not guess structured mappings from prose.
        if valid:self.correct[key]=candidate

    def recalled(self,q):
        values=self.correct.get(self.key(q))
        return Answer(q.qid,q.kind,list(values),1.0,'Previously accepted or shown as correct by McGraw in this session.') if values else None

    def is_rejected(self,q,answers):
        key=lambda values:tuple(sorted(option_key(x) for x in values)) if q.kind=='multiple_choice' else tuple(option_key(x) for x in values)
        accepted=self.correct.get(self.key(q))
        if accepted and key(answers)==key(accepted):return False
        return any(key(answers)==key(old) for old in self.wrong.get(self.key(q),[]))

    async def observe(self,page):
        if page not in self.pending:return False
        from mcgraw_actions import allowed_mcgraw
        q,submitted=self.pending[page]
        for frame in page.frames:
            if not allowed_mcgraw(frame):continue
            script=r'''() => {
              const visible=el=>!!el && el.getBoundingClientRect().width>0 && el.getBoundingClientRect().height>0 && getComputedStyle(el).visibility!=='hidden' && !el.closest('#webqa-overlay');
              let text=document.body.innerText;const overlay=document.querySelector('#webqa-overlay');
              if(overlay)text=text.replace(overlay.innerText,'');
              const result=text.match(/Your\s+Answer\s*(incorrect|correct)/i);
              if(!result)return null;
              const headingPattern=/^Correct Answers?(?:\s+(?:for\s+)?(?:Field|Blank)\s+\d+)?\s*:?$/i;
              const headings=[...document.querySelectorAll('h1,h2,h3,h4,p,div,span')]
                .filter(el=>visible(el)&&headingPattern.test(el.innerText.trim()));
              const leaves=headings.filter(el=>!headings.some(other=>other!==el&&el.contains(other)));
              const read=el=>{
                  const clone=el.cloneNode(true);
                  // Original MathML source scripts and annotations are not
                  // part of the answer the platform shows to the student.
                  clone.querySelectorAll('script,style,template,annotation,annotation-xml,[hidden],[aria-live],[role="status"],.sr-only,.visually-hidden').forEach(x=>x.remove());
                  for(const renderer of clone.querySelectorAll('mjx-container,.MathJax,.katex')) {
                    const math=renderer.querySelector('math');
                    if(math)renderer.replaceWith(document.createTextNode(math.textContent));
                  }
                  clone.querySelectorAll('li,p,div,br').forEach(x=>x.append(document.createTextNode('\n')));
                  return clone.textContent.replace(/[ \t]+/g,' ').replace(/\n\s*\n/g,'\n').trim();
              };
              const panels=[];const used=new Set();
              for(const heading of leaves) {
                for(let node=heading,depth=0;node && depth<4;node=node.parentElement,depth++) {
                  const sibling=node.nextElementSibling;
                  if(!visible(sibling) || used.has(sibling))continue;
                  const shown=read(sibling);
                  if(/^(Next Question|Need help|Rate your confidence)/i.test(shown) || headings.some(h=>sibling===h || sibling.contains(h)))continue;
                  const fields=[...(sibling.matches('input,textarea')?[sibling]:sibling.querySelectorAll('input,textarea'))].filter(visible).map(el=>el.value.trim());
                  const rows=[...sibling.querySelectorAll('li')].filter(el=>visible(el)&&!el.querySelector('li'));
                  const children=[...sibling.children].filter(visible);
                  let parts=[];
                  if(fields.length)parts=fields;
                  else if(rows.length)parts=rows.map(read);
                  else if(children.length>1 && children.every(el=>/^(P|DIV)$/.test(el.tagName)))parts=children.map(read);
                  else if(shown)parts=[shown];
                  const number=heading.innerText.match(/(?:Field|Blank)\s+(\d+)/i);
                  if(number && parts.length===1)parts=['Field '+number[1]+': '+parts[0]];
                  panels.push({shown,parts});used.add(sibling);break;
                }
              }
              return {correct:result[1].toLowerCase()==='correct',shown:panels.map(p=>p.shown).join('\n').slice(0,2000),parts:panels.flatMap(p=>p.parts).slice(0,30)};
            }'''
            data=await frame.evaluate(script)
            if not data:continue
            # Feedback and its answer panel can render in separate updates.
            for _ in range(8):
                values=data.get('parts') or ([data['shown']] if data['shown'] else [])
                ready=bool(fill_correction(q,values)) if q.kind=='fill_blank' else bool(values)
                if data['correct'] or ready:break
                await asyncio.sleep(0.25)
                updated=await frame.evaluate(script)
                if not updated:break
                data=updated
            # The staged tuple is the answer that was actually applied. Inputs
            # in Correct Answer can replace the original inputs during feedback;
            # treating those values as the submission would reject the correction.
            values=data.get('parts') or ([data['shown']] if data['shown'] else [])
            self.learn(q,submitted,data['correct'],values or None)
            self.pending.pop(page,None)
            print('Session memory: feedback recorded; '+('correction available.' if self.key(q) in self.correct else 'rejected answer will not be reused.'))
            return True
        return False
