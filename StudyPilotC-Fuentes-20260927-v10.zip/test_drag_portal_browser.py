"""Real pointer capture/portal regressions missing from the simple drop fixtures."""
import asyncio
import unittest
from types import SimpleNamespace as NS
from playwright.async_api import async_playwright
from mcgraw_actions import drag_match,keyboard_match
from ordering import apply_ordering,drag_point
from mcgraw_actions import exact_choice
from models import Question,Choice


class DragPortalBrowser(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw=await async_playwright().start()
        self.browser=await self.pw.chromium.launch(channel='chrome',headless=True)
        self.page=await self.browser.new_page(viewport={'width':1300,'height':850})

    async def asyncTearDown(self):
        await self.browser.close()
        await self.pw.stop()

    async def test_pointer_capture_portal_preview_inside_scrolled_iframe(self):
        await self.page.set_content('<iframe style="position:absolute;left:130px;top:90px;width:950px;height:500px;border:0"></iframe>')
        frame=self.page.frames[1]
        await frame.set_content('''<div id="pane" style="height:350px;width:900px;overflow:auto;margin:40px 0;position:relative">
          <div id="target" data-webqa-match-target="2" style="height:100px;margin:5px;border:1px solid"> </div>
          <div style="height:450px"></div>
          <div id="source" draggable="false" data-webqa-cid="answer" style="height:620px;width:890px;border:1px solid">Synthesis</div>
          <div style="height:20px"></div></div>
          <script>
          const source=document.querySelector('#source'),target=document.querySelector('#target');let ghost=null,held=false,offset=0;window.drops=0;
          source.addEventListener('pointerdown',e=>{held=true;source.setPointerCapture(e.pointerId);const r=source.getBoundingClientRect();offset=e.clientY-r.top;
            ghost=source.cloneNode(true);ghost.removeAttribute('id');ghost.removeAttribute('data-webqa-cid');ghost.className='cdk-drag-preview';
            ghost.setAttribute('aria-grabbed','true');Object.assign(ghost.style,{position:'fixed',zIndex:'9999',left:r.left+'px',top:r.top+'px',pointerEvents:'auto'});document.body.append(ghost);});
          source.addEventListener('pointermove',e=>{if(held){ghost.style.top=(e.clientY-offset)+'px';}});
          source.addEventListener('pointerup',e=>{if(!held)return;const r=target.getBoundingClientRect();
            if(e.clientX>=r.left&&e.clientX<=r.right&&e.clientY>=r.top&&e.clientY<=r.bottom){target.textContent='Synthesis';window.drops++;}
            held=false;ghost.remove();ghost=null;});
          </script>''')
        await drag_match(self.page,frame.locator('#source'),frame.locator('#target'),NS(cid='answer',text='Synthesis'))
        self.assertEqual(await frame.evaluate('window.drops'),1)
        self.assertEqual(await frame.locator('.cdk-drag-preview').count(),0)
        self.assertGreater(await frame.locator('#pane').evaluate('el=>el.scrollHeight'),800)

    async def test_delayed_keyboard_pickup_portal_without_original_cid(self):
        await self.page.set_content('''<div data-webqa-match-target="1" id="target" style="position:absolute;left:400px;top:80px;width:400px;height:70px"></div>
          <div id="source" tabindex="0" aria-grabbed="false" data-webqa-cid="answer" style="position:absolute;left:400px;top:360px;width:400px;height:70px">Synthesis</div>
          <script>const source=document.querySelector('#source'),target=document.querySelector('#target');let pending=null,held=null,moved=false;window.cancelled=0;window.commits=0;
          document.addEventListener('keydown',e=>{e.preventDefault();
            if(e.code==='Space'&&!held){pending=setTimeout(()=>{pending=null;held=source.cloneNode(true);held.removeAttribute('id');held.removeAttribute('data-webqa-cid');
              held.className='cdk-drag-preview';held.setAttribute('aria-grabbed','true');source.remove();document.body.append(held);held.focus();},260);}
            else if(e.code==='Space'&&held){if(moved){held.setAttribute('aria-grabbed','false');held.style.position='static';target.append(held);held=null;window.commits++;}}
            if(e.code==='ArrowUp'&&held)setTimeout(()=>{held.style.top='80px';moved=true;},230);
            if(e.code==='Escape'){window.cancelled++;clearTimeout(pending);if(held){held.remove();held=null;}if(!source.isConnected)document.body.append(source);}
          });</script>''')
        # McGraw repeats this accessibility announcement in a rendered helper;
        # the portal has no CID/recorded text and must retain semantic identity.
        await self.page.locator('#source').evaluate("""el=>{
            el.setAttribute('aria-label','Choice 2 of 4. Synthesis');
            el.innerHTML='<span>Choice 2 of 4. Synthesis toggle button</span><p>Synthesis</p>';
        }""")
        result=await keyboard_match(self.page,self.page.locator('#source'),self.page.locator('#target'),NS(cid='answer',text='Synthesis'))
        self.assertTrue(result)
        self.assertEqual(await self.page.evaluate('[window.commits,window.cancelled]'),[1,0])

    async def test_unrelated_overlay_remains_a_blocker_during_drag(self):
        await self.page.set_content('''<div id="target" style="width:500px;height:100px">Destination</div>
          <div style="position:fixed;inset:0;z-index:10">An unrelated dialog</div>''')
        with self.assertRaisesRegex(ValueError,'covered'):
            await drag_point(self.page.locator('#target'),dragging={'cid':'answer','text':'Synthesis','rfd':None})
        await self.page.locator('div').nth(1).evaluate("el=>{el.className='cdk-drag-preview';el.textContent='A different tile';}")
        with self.assertRaisesRegex(ValueError,'covered'):
            await drag_point(self.page.locator('#target'),dragging={'cid':'answer','text':'Synthesis','rfd':None})

    async def test_keyboard_portal_moves_while_focus_stays_on_original_placeholder(self):
        await self.page.set_content('''<div data-webqa-match-target="1" id="target" style="position:absolute;left:400px;top:80px;width:400px;height:70px"></div>
          <div id="source" tabindex="0" aria-grabbed="false" data-webqa-cid="answer" style="position:absolute;left:400px;top:360px;width:400px;height:70px">Synthesis</div>
          <script>const source=document.querySelector('#source'),target=document.querySelector('#target');let ghost=null;window.commits=0;
          source.onkeydown=e=>{e.preventDefault();
            if(e.code==='Space'&&!ghost){ghost=source.cloneNode(true);ghost.removeAttribute('id');ghost.removeAttribute('data-webqa-cid');ghost.className='cdk-drag-preview';
              ghost.setAttribute('aria-grabbed','true');source.setAttribute('aria-grabbed','true');document.body.append(ghost);}
            else if(e.code==='Space'&&ghost){source.setAttribute('aria-grabbed','false');ghost.setAttribute('aria-grabbed','false');ghost.style.position='static';target.append(ghost);ghost=null;window.commits++;}
            if(e.code==='ArrowUp'&&ghost)ghost.style.top='80px';
            if(e.code==='Escape'){if(ghost)ghost.remove();ghost=null;source.setAttribute('aria-grabbed','false');}
          };</script>''')
        self.assertTrue(await keyboard_match(self.page,self.page.locator('#source'),self.page.locator('#target'),NS(cid='answer',text='Synthesis')))
        self.assertEqual(await self.page.evaluate('window.commits'),1)

    async def test_ordering_waits_for_delayed_keyboard_pickup_and_movement(self):
        await self.page.set_content('''<div id="list">
          <div tabindex="0" data-webqa-order-item="1" data-webqa-cid="c" style="height:80px">Third</div>
          <div tabindex="0" data-webqa-order-item="1" data-webqa-cid="a" style="height:80px">First</div>
          <div tabindex="0" data-webqa-order-item="1" data-webqa-cid="b" style="height:80px">Second</div></div>
          <script>let held=null,pending=null;window.commits=0;
          document.addEventListener('keydown',e=>{e.preventDefault();const item=e.target.closest('[data-webqa-order-item]');if(!item)return;
            if(e.code==='Space'&&!held){pending=setTimeout(()=>{held=item;item.setAttribute('aria-grabbed','true');},260);}
            else if(e.code==='Space'&&held){held.setAttribute('aria-grabbed','false');held=null;window.commits++;}
            if(e.code==='ArrowUp'&&held){const moving=held;setTimeout(()=>{if(moving.previousElementSibling)moving.parentElement.insertBefore(moving,moving.previousElementSibling);moving.focus();},230);}
            if(e.code==='Escape'){clearTimeout(pending);if(held)held.setAttribute('aria-grabbed','false');held=null;}
          });</script>''')
        question=Question('q','Order the items','ordering',[Choice('c','Third','ordering'),Choice('a','First','ordering'),Choice('b','Second','ordering')])
        await apply_ordering(self.page,self.page.main_frame,question,['First','Second','Third'],exact_choice)
        self.assertEqual(await self.page.locator('#list>div').all_inner_texts(),['First','Second','Third'])
        self.assertEqual(await self.page.evaluate('window.commits'),2)


if __name__=='__main__':unittest.main()
