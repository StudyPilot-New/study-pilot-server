"""Canvas analysis retries and multi-question progress on local browser fixtures."""
import time
import unittest
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from playwright.async_api import async_playwright

import app
from canvas_navigation import CanvasNavigation
from models import Answer


def question(ident, prompt):
    return f'''<section class="question" data-question-id="{ident}">
      <div class="question_text">{prompt}</div>
      <label><input type="radio" name="{ident}" value="Alpha">Alpha</label>
      <label><input type="radio" name="{ident}" value="Beta">Beta</label>
    </section>'''


class CanvasAnalysisRecovery(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pw = await async_playwright().start()
        self.browser = await self.pw.chromium.launch(channel='chrome', headless=True)
        self.context = await self.browser.new_context()
        await self.context.route('**/*', lambda route: route.fulfill(
            content_type='text/html', body='<main id="quiz"></main>'))
        self.page = await self.context.new_page()
        await self.page.goto('https://fixture.instructure.com/courses/42/quizzes/5/take')
        self.seen = {}
        self.solver = SimpleNamespace(memory=None)
        self.solve = AsyncMock()
        self.overlay = AsyncMock()
        self.navigator = CanvasNavigation()
        settings = replace(app.settings, mode='fill', use_vision='never',
                           pacing_minutes=0, min_confidence=.6)
        self.patches = [
            patch.object(app, 'settings', settings),
            patch.object(app, '_canvas_navigation', self.navigator),
            patch.object(app, 'solve_with_visual_evidence', self.solve),
            patch.object(app, 'update_overlay', self.overlay),
        ]
        for item in self.patches:
            item.start()

    async def asyncTearDown(self):
        for item in reversed(self.patches):
            item.stop()
        await self.browser.close()
        await self.pw.stop()

    async def load(self, content):
        await self.page.set_content(content + '''
          <button onclick="window.nextClicks++">Next</button>
          <script>window.nextClicks=0;</script>''')

    async def scan(self):
        return await app.analyze_page(self.page, self.solver, self.seen)

    def expire_retries(self):
        for retry in app._solve_retries[self.page].values():
            retry['at'] = time.monotonic() - 1

    async def assert_retry_then_correct(self, first):
        await self.load(question('first', 'Choose the matching example.'))
        corrected = Answer('learning-0', 'single_choice', ['Beta'], .99)
        self.solve.side_effect = [(first, ''), (corrected, '')]
        await self.scan()
        self.assertEqual(self.solve.await_count, 1)
        self.assertEqual(await self.page.locator('input:checked').count(), 0)
        self.assertEqual(await self.page.evaluate('window.nextClicks'), 0)
        self.assertFalse(self.seen, 'An unusable analysis must not be cached as completed')
        retries = app._solve_retries[self.page]
        self.assertEqual(len(retries), 1)
        retry = next(iter(retries.values()))
        self.assertGreater(retry['at'], time.monotonic())
        self.assertNotIn('candidate', retry)
        await self.scan()
        self.assertEqual(self.solve.await_count, 1, 'The scheduled delay must prevent immediate reanalysis')
        self.assertEqual(await self.page.evaluate('window.nextClicks'), 0)
        self.assertFalse(self.seen)
        self.expire_retries()
        await self.scan()
        self.assertEqual(self.solve.await_count, 2)
        self.assertEqual(self.solve.await_args.kwargs['recovery_attempt'], 1)
        self.assertEqual(await self.page.locator('input:checked').input_value(), 'Beta')
        self.assertEqual(await self.page.evaluate('window.nextClicks'), 1)
        self.assertFalse(app._solve_retries.get(self.page))
        self.assertTrue(self.seen)
        self.assertFalse(any('Paused on this question' in str(call.args)
                             for call in self.overlay.await_args_list))

    async def test_low_confidence_analysis_is_automatically_retried(self):
        await self.assert_retry_then_correct(Answer('learning-0', 'single_choice', ['Alpha'], .2))

    async def test_empty_answer_is_automatically_retried(self):
        await self.assert_retry_then_correct(Answer('learning-0', 'single_choice', [], .99))

    async def test_missing_analysis_is_automatically_retried(self):
        await self.assert_retry_then_correct(None)

    async def test_invalid_single_choice_shape_is_reanalyzed_without_partial_selection(self):
        await self.assert_retry_then_correct(Answer('learning-0', 'single_choice', ['Alpha', 'Beta'], .99))

    async def test_failed_remembered_selection_does_not_starve_another_question(self):
        await self.load(question('first', 'First prompt: choose the matching example.') +
                        question('second', 'Second prompt: choose the matching example.'))
        calls = []

        async def analyze(_page, _frame, current, *args, **kwargs):
            key = 'first' if current.text.startswith('First prompt:') else 'second'
            calls.append(key)
            confident = key == 'first' or calls.count('second') > 1
            return Answer(current.qid, current.kind, ['Alpha' if key == 'first' else 'Beta'],
                          .99 if confident else .2), ''

        self.solve.side_effect = analyze
        await self.scan()
        self.assertEqual(calls, ['first', 'second'])
        self.assertEqual(await self.page.locator('input[name="first"]:checked').input_value(), 'Alpha')
        self.assertEqual(await self.page.locator('input[name="second"]:checked').count(), 0)
        self.assertEqual(await self.page.evaluate('window.nextClicks'), 0)
        # The framework loses the first answer and refuses its next repair.
        # The second question still needs a fresh analysis after its delay.
        await self.page.locator('input[name="first"]').evaluate_all(
            'els=>els.forEach(el=>{el.checked=false;el.onclick=()=>false;})')
        self.expire_retries()
        await self.scan()
        self.assertEqual(calls, ['first', 'second', 'second'])
        self.assertEqual(await self.page.locator('input[name="second"]:checked').input_value(), 'Beta')
        self.assertEqual(await self.page.locator('input[name="first"]:checked').count(), 0)
        self.assertEqual(await self.page.evaluate('window.nextClicks'), 0,
                         'An unresolved earlier answer must still block Next')


if __name__ == '__main__':
    unittest.main()
