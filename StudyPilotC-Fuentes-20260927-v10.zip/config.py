from dataclasses import dataclass
from pathlib import Path
import os
from dotenv import load_dotenv
from runtime_paths import DATA_DIR

load_dotenv(DATA_DIR / '.env')

def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}

@dataclass(frozen=True)
class Settings:
    api_key: str = os.getenv("OPENAI_API_KEY", "")
    model: str = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
    start_url: str = os.getenv("START_URL", "about:blank")
    headless: bool = _bool("HEADLESS", False)
    browser_channel: str = os.getenv("BROWSER_CHANNEL", "chrome")
    compatibility_mode: bool = _bool('CHROME_COMPATIBILITY',True)
    profile_dir: Path = Path(os.getenv("PROFILE_DIR", str(DATA_DIR / '.browser_profile')))

    # Generic pages: assist or fill.
    mode: str = os.getenv("MODE", "assist").strip().lower()

    mcgraw_auto: bool = _bool("MCGRAW_AUTO", True)
    mcgraw_confidence: str = os.getenv("MCGRAW_CONFIDENCE", "Medium").strip().title()

    book_reference: bool = _bool("BOOK_REFERENCE", True)
    book_index: Path = Path(os.getenv("BOOK_INDEX", str(DATA_DIR / "biology_reference.sqlite3")))

    # Vision: never | auto | always.
    use_vision: str = os.getenv("USE_VISION", "auto").strip().lower()
    min_confidence: float = float(os.getenv("MIN_CONFIDENCE", "0.60"))
    fast_mode: bool = _bool("FAST_MODE", True)
    fast_reasoning: str = os.getenv("FAST_REASONING", "none").strip().lower()
    fast_max_output_tokens: int = int(os.getenv("FAST_MAX_OUTPUT_TOKENS", "180"))
    poll_seconds: float = float(os.getenv("POLL_SECONDS", "0.20"))

    # Real time between responses: 180 estimated questions over 120 minutes.
    # Zero minutes disables pacing; errors/repeats can extend the estimate.
    pacing_minutes: float = float(os.getenv("PACING_MINUTES", "120"))
    pacing_questions: int = int(os.getenv("PACING_QUESTIONS", "180"))

    # McGraw/education adapter behavior.
    highlight_recommendations: bool = _bool("HIGHLIGHT_RECOMMENDATIONS", True)
    show_explanation: bool = _bool("SHOW_EXPLANATION", True)

settings = Settings()
