import unittest
from models import Question,Choice,Answer
from session_memory import SessionMemory,split_blanks

def question(text='The isomers are [Blank 1] isomers.',count=1,visual=False,hint=''):
    return Question('q',text,'fill_blank',[Choice(str(i),'Blank '+str(i+1),'text') for i in range(count)],visual,hint)

class MemoryTests(unittest.TestCase):
    def test_rejected_synonym_replaced_by_shown_term(self):
        m=SessionMemory();q=question()
        m.learn(q,['constitutional'],False,['structural'])
        self.assertEqual(m.recalled(q).answers,['structural'])
        self.assertEqual(m.wrong[m.key(q)],[['constitutional']])
    def test_wrong_without_correction_does_not_invent_one(self):
        m=SessionMemory();q=question();m.learn(q,['constitutional'],False)
        self.assertIsNone(m.recalled(q))
    def test_separate_images_and_sessions(self):
        m=SessionMemory();q=question(visual=True,hint='figure-one')
        m.learn(q,['structural'],True)
        self.assertIsNone(m.recalled(question(visual=True,hint='figure-two')))
        self.assertIsNone(SessionMemory().recalled(q))
    def test_two_adjacent_words_split_in_order(self):
        q=question('Mutations alter the [Blank 1] [Blank 2] sequence.',2)
        self.assertEqual(split_blanks(q,['amino acid']),['amino','acid'])
        self.assertEqual(split_blanks(q,['amino acid','amino acid']),['amino','acid'])
        m=SessionMemory();m.learn(q,['wrong','word'],False,['amino acid'])
        self.assertEqual(m.recalled(q).answers,['amino','acid'])
    def test_nonadjacent_boxes_not_split_blindly(self):
        q=question('[Blank 1] differs from [Blank 2].',2)
        self.assertEqual(split_blanks(q,['amino acid']),['amino acid'])
        m=SessionMemory();m.learn(q,['wrong','word'],False,['amino acid'])
        self.assertIsNone(m.recalled(q))

    def test_visual_correction_survives_adapter_hint_changes(self):
        m=SessionMemory();q=question(visual=True,hint='adapter-one|figure:same-image')
        m.learn(q,['constitutional'],False,['structural'])
        repeated=question(visual=True,hint='adapter-two|figure:same-image')
        self.assertEqual(m.recalled(repeated).answers,['structural'])
        self.assertTrue(m.is_rejected(repeated,['constitutional']))
        self.assertIsNone(m.recalled(question(visual=True,hint='adapter-two|figure:other-image')))

    def test_correction_matches_charges_and_sentence_punctuation(self):
        m=SessionMemory()
        q=Question('q','Choose the molecule.','single_choice',[Choice('a','amino acid.','radio'),Choice('b','fatty acid.','radio')])
        m.learn(q,['fatty acid'],False,['amino acid'])
        self.assertEqual(m.recalled(q).answers,['amino acid.'])
        repeated=Question('q2',q.text,q.kind,[Choice('x','amino acid','radio'),Choice('y','fatty acid','radio')])
        self.assertTrue(m.is_rejected(repeated,['fatty acid.']))
        charged=Question('charge','Which formula?','single_choice',[Choice('x','PO₄²−','radio'),Choice('y','PO₄−','radio')])
        m.learn(charged,['PO4-'],False,['PO4^2-'])
        self.assertEqual(m.recalled(charged).answers,['PO₄²−'])

    def test_single_choice_never_learns_multiple_options(self):
        m=SessionMemory();q=Question('q','Choose an answer.','single_choice',[Choice('a','One','radio'),Choice('b','Two','radio')])
        m.learn(q,['Two'],False,['One','Two'])
        self.assertIsNone(m.recalled(q))

if __name__=='__main__':unittest.main()
