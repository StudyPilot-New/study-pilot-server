import unittest
from dataclasses import replace
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, patch
from playwright.async_api import async_playwright
from models import Answer
from pacing import SessionPacer
import app
import mcgraw_actions


class PacingTests(unittest.TestCase):
    def test_180_responses_span_two_hours_without_real_sleep(self):
        now=[0.0]
        pacer=SessionPacer(120,180,clock=lambda:now[0])
        for i in range(180):
            self.assertEqual(pacer.remaining(),40)
            now[0]+=40
            self.assertEqual(pacer.remaining(),0)
            pacer.submitted()
        self.assertEqual(now[0],7200)
        self.assertEqual(pacer.completed,180)

    def test_pause_and_slow_question_never_cause_catchup_burst(self):
        now=[0]
        pacer=SessionPacer(clock=lambda:now[0])
        now[0]=10
        pacer.pause()
        now[0]=1000
        self.assertEqual(pacer.remaining(),30)
        pacer.resume()
        self.assertEqual(pacer.remaining(),30)
        now[0]=2000
        pacer.submitted()
        self.assertEqual(pacer.remaining(),20)  # Retains a real gap after a delay.

    def test_model_latency_does_not_accumulate_for_every_question(self):
        now=[0.0]
        pacer=SessionPacer(120,180,clock=lambda:now[0])
        for _ in range(180):
            now[0]+=pacer.remaining()+5  # Five seconds to solve and apply.
            pacer.submitted()
        self.assertEqual(now[0],7205)

    def test_invalid_inputs_and_disabled_pacing(self):
        for minutes,questions in [(float('nan'),180),(-1,180),(120,0),(120,1.5)]:
            with self.assertRaises(ValueError):SessionPacer(minutes,questions)
        self.assertEqual(SessionPacer(0,180).remaining(),0)


class PacingBrowser(unittest.IsolatedAsyncioTestCase):
    async def test_wait_answer_feedback_next_and_wait_again(self):
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page(viewport={'width':1200,'height':900})
                html='''<main></main><script>
                let serial=0;window.sent=0;
                function question(){document.querySelector('main').innerHTML='<h1>Multiple Choice Question</h1><p>Which option is correct in example '+(++serial)+'?</p><label style="display:block;margin:40px"><input type="radio" name="answer">Correct</label><label style="display:block;margin:40px"><input type="radio" name="answer">Other</label><button id="confidence" disabled>Medium</button>';
                document.querySelector('main').onchange=()=>document.querySelector('#confidence').disabled=false;
                document.querySelector('#confidence').onclick=()=>{window.sent++;document.querySelector('main').innerHTML='<h1>Your Answer correct</h1><button id="next">Next Question</button>';document.querySelector('#next').onclick=question;};}question();</script>'''
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body=html))
                await page.goto('https://learning.mheducation.com/pacing-test')
                now=[0]
                pacer=SessionPacer(120,180,clock=lambda:now[0])
                app._pacers[page]=pacer
                solver=NS(solve=AsyncMock(return_value=Answer('q','single_choice',['Correct'],1)))
                settings=replace(app.settings,mode='fill',mcgraw_auto=True,mcgraw_confidence='Medium',use_vision='never',pacing_minutes=120,pacing_questions=180)
                with patch.object(app,'settings',settings):
                    seen={}
                    await app.analyze_page(page,solver,seen)
                    solver.solve.assert_not_awaited()
                    self.assertIn('00:40',await page.locator('#webqa-overlay').inner_text())
                    now[0]=40
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(await page.evaluate('window.sent'),1)
                    self.assertEqual(pacer.completed,1)
                    await app.analyze_page(page,solver,seen)
                    mcgraw_actions._feedback_navigation[page]['last']-=3
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(solver.solve.await_count,1)
                    now[0]=80
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(await page.evaluate('window.sent'),2)
            finally:
                await browser.close()
