@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\pythonw.exe" (
  start "" ".venv\Scripts\pythonw.exe" "desktop_ui.py"
  exit /b
)
where python >nul 2>nul
if %errorlevel% equ 0 (
  python "desktop_ui.py"
  exit /b
)
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 "desktop_ui.py"
  exit /b
)
echo No se encontro Python. Abre tu entorno de Python y ejecuta: python desktop_ui.py
pause
