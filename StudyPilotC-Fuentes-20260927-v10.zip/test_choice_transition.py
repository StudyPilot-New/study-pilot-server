import unittest
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock,patch
from dataclasses import replace
from playwright.async_api import async_playwright
from models import Choice,Answer
import app
from mcgraw_actions import exact_choice

class ChoiceTransition(unittest.IsolatedAsyncioTestCase):
    def test_punctuation_is_unique_and_charge_is_preserved(self):
        choices=[Choice('a','amino acid.','radio'),Choice('b','fatty acid.','radio')]
        self.assertEqual(exact_choice('amino acid',choices).cid,'a')
        with self.assertRaises(ValueError):exact_choice('acid',choices)
        with self.assertRaises(ValueError):exact_choice('NH3',[Choice('a','NH3+','radio')])
        with self.assertRaises(ValueError):exact_choice('amino acid',[Choice('a','amino acid.','radio'),Choice('b','amino acid!','radio')])

    async def test_next_question_after_failure_and_revisit_are_processed(self):
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page(viewport={'width':1400,'height':900})
                def html(prompt,values):return '<h1>Multiple Choice Question</h1><p style="margin:40px">'+prompt+'</p>'+''.join('<label style="display:block;margin:30px"><input type="radio" name="q">'+v+'</label>' for v in values)
                first=html('The organic molecule is an example of what?',['fatty acid.','amino acid.'])
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body=first))
                await page.goto('https://learning.mheducation.com/test')
                solver=NS(solve=AsyncMock(side_effect=[Answer('q','single_choice',['amino acid'],1),Answer('q','single_choice',['absent'],1),Answer('q','single_choice',['amino acid'],1)]))
                seen={}
                with patch.object(app,'settings',replace(app.settings,mode='fill',pacing_minutes=0,mcgraw_auto=True,use_vision='never')),patch.object(app,'submit_confidence',new=AsyncMock(return_value=True)):
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(await page.locator('input:checked').count(),1)
                    await page.set_content(html('What is the chemical formula of glucose?',['C6H6','C6H12O6']))
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(await page.locator('input:checked').count(),0)
                    await page.set_content(first)
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(await page.locator('input:checked').count(),1)
                    self.assertEqual(solver.solve.await_count,3)
            finally:await browser.close()

    async def test_transient_solver_failure_waits_then_recovers(self):
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            try:
                page=await browser.new_page(viewport={'width':1200,'height':900})
                html='<h1>Multiple Choice Question</h1><p>Which answer is correct?</p><label style="display:block;margin:40px"><input type="radio" name="q">Correct</label><label style="display:block;margin:40px"><input type="radio" name="q">Other</label>'
                await page.route('https://learning.mheducation.com/**',lambda r:r.fulfill(content_type='text/html',body=html))
                await page.goto('https://learning.mheducation.com/test')
                solver=NS(solve=AsyncMock(side_effect=[RuntimeError('temporary outage'),Answer('q','single_choice',['Correct'],1)]))
                with patch.object(app,'settings',replace(app.settings,mode='fill',pacing_minutes=0,mcgraw_auto=True,use_vision='never')),patch.object(app,'submit_confidence',new=AsyncMock(return_value=True)):
                    seen={}
                    await app.analyze_page(page,solver,seen)
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(solver.solve.await_count,1)
                    self.assertEqual(await page.locator('input:checked').count(),0)
                    for retry in app._solve_retries[page].values():retry['at']-=100
                    await app.analyze_page(page,solver,seen)
                    self.assertEqual(solver.solve.await_count,2)
                    self.assertEqual(await page.locator('input:checked').count(),1)
            finally:await browser.close()

if __name__=='__main__':unittest.main()
