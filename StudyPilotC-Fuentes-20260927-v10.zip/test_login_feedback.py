import tempfile,time,tkinter as tk,unittest
from pathlib import Path
from unittest.mock import patch
import desktop_ui,account_login

class LoginFeedbackTests(unittest.TestCase):
    def test_active_pending_and_error_are_visible(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(desktop_ui,'ROOT',Path(directory)):
            root=tk.Tk();root.withdraw()
            try:
                app=desktop_ui.StudyPilot(root)
                frame=account_login.build_account(app,app.notebook)
                entries=[w for w in frame.winfo_children() if isinstance(w,tk.Entry)]
                login=next(w for w in frame.winfo_children() if isinstance(w,tk.Button) and w.cget('text')=='Entrar')
                for outcome,expected in [({'active':True},'Acceso activo'),({'active':False},'Acceso pendiente'),(ValueError('Credenciales incorrectas'),'No se pudo iniciar sesión')]:
                    app.notebook.select(frame)
                    for entry,text in zip(entries,['test@example.com','temporary-password']):entry.delete(0,'end');entry.insert(0,text)
                    kwargs={'side_effect':outcome} if isinstance(outcome,Exception) else {'return_value':outcome}
                    with patch.object(account_login,'sign_in',**kwargs):
                        login.invoke();deadline=time.monotonic()+3
                        while str(login['state'])=='disabled' and time.monotonic()<deadline:root.update();time.sleep(.01)
                    self.assertEqual(app.status.get(),expected)
                    self.assertEqual(entries[1].get(),'')
                    if outcome=={'active':True}:self.assertEqual(app.notebook.index('current'),0)
                    else:self.assertEqual(app.notebook.select(),str(frame))
                    self.assertTrue(app.detail.get())
                    labels=[w for w in frame.winfo_children() if isinstance(w,tk.Label) and w.cget('textvariable')]
                    self.assertEqual(len(labels),1)
                    self.assertLess(frame.winfo_children().index(labels[0]),frame.winfo_children().index(entries[0]))
            finally:root.destroy()

if __name__=='__main__':unittest.main()
